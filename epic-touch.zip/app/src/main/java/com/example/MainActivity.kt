package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainViewModel
import com.example.ui.screens.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppFrame()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppFrame() {
    val viewModel: MainViewModel = viewModel()
    
    // Collecting states from MainViewModel
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val currentUserRole by viewModel.currentUserRole.collectAsStateWithLifecycle()
    
    val isLoggedIn by viewModel.isLoggedIn.collectAsStateWithLifecycle()
    val loggedUserName by viewModel.loggedUserName.collectAsStateWithLifecycle()
    val loggedUserLogin by viewModel.loggedUserLogin.collectAsStateWithLifecycle()
    val technicalAssistanceName by viewModel.technicalAssistanceName.collectAsStateWithLifecycle()
    val loggedUserPlan by viewModel.loggedUserPlan.collectAsStateWithLifecycle()
    
    val customers by viewModel.customers.collectAsStateWithLifecycle()
    val devices by viewModel.devices.collectAsStateWithLifecycle()
    val serviceOrders by viewModel.serviceOrders.collectAsStateWithLifecycle()
    val inventory by viewModel.inventory.collectAsStateWithLifecycle()
    val employees by viewModel.employees.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val assinaturas by viewModel.assinaturas.collectAsStateWithLifecycle()
    
    val trackedOrder by viewModel.trackedOrder.collectAsStateWithLifecycle()
    val trackingSearchError by viewModel.trackingSearchError.collectAsStateWithLifecycle()

    val pixKey by viewModel.pixKey.collectAsStateWithLifecycle()
    val pixKeyType by viewModel.pixKeyType.collectAsStateWithLifecycle()
    val pixMerchantName by viewModel.pixMerchantName.collectAsStateWithLifecycle()
    val pixMerchantCity by viewModel.pixMerchantCity.collectAsStateWithLifecycle()
    val pendingActivationUser by viewModel.pendingActivationUser.collectAsStateWithLifecycle()

    if (!isLoggedIn) {
        LoginScreen(
            onLogin = { login, pwd -> viewModel.login(login, pwd) },
            onRegister = { login, name, role, assistance, pwd, plan -> viewModel.register(login, name, role, assistance, pwd, plan) },
            pendingActivationUser = pendingActivationUser,
            onActivateUser = { viewModel.activateAndLogin(it) },
            onCancelActivation = { viewModel.clearPendingActivation() },
            pixKey = pixKey,
            pixMerchantName = pixMerchantName,
            pixMerchantCity = pixMerchantCity
        )
        return
    }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    // Screen responsive width detection
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isTablet = maxWidth >= 768.dp

        ModalNavigationDrawer(
            drawerState = drawerState,
            gesturesEnabled = !isTablet,
            drawerContent = {
                ModalDrawerSheet(
                    drawerContainerColor = DarkSurface,
                    drawerContentColor = TextPrimary,
                    modifier = Modifier.width(280.dp)
                ) {
                    DrawerSidebarContent(
                        currentScreen = currentScreen,
                        currentUserRole = currentUserRole,
                        assistanceName = technicalAssistanceName,
                        userName = loggedUserName,
                        onScreenSelect = {
                            viewModel.navigateTo(it)
                            // Close drawer on mobile
                            if (!isTablet) {
                                scope.launch { drawerState.close() }
                            }
                        },
                        onRoleChange = { viewModel.setUserRole(it) }
                    )
                }
            }
        ) {
            Scaffold(
                modifier = Modifier.fillMaxSize(),
                topBar = {
                    TopAppBar(
                        title = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .background(Color.Black, RoundedCornerShape(6.dp))
                                        .border(BorderStroke(1.dp, NeonGreen), RoundedCornerShape(6.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("ET", color = NeonGreen, fontSize = 12.sp, fontWeight = FontWeight.Black)
                                }
                                Text(
                                    text = getScreenTitle(currentScreen),
                                    fontWeight = FontWeight.Black,
                                    fontSize = 16.sp,
                                    letterSpacing = 1.sp
                                )
                            }
                        },
                        navigationIcon = {
                            if (!isTablet) {
                                IconButton(onClick = {
                                    scope.launch {
                                        if (drawerState.isClosed) drawerState.open() else drawerState.close()
                                    }
                                }) {
                                    Icon(Icons.Default.Menu, contentDescription = "Menu", tint = NeonGreen)
                                }
                            }
                        },
                        actions = {
                            // User role quick badge
                            Box(
                                modifier = Modifier
                                    .padding(end = 12.dp)
                                    .background(NeonGreen.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                                    .border(BorderStroke(1.dp, NeonGreen.copy(alpha = 0.3f)), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = currentUserRole,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NeonGreen
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = DarkSurface,
                            titleContentColor = TextPrimary
                        )
                    )
                },
                bottomBar = {
                    if (!isTablet) {
                        BottomAppBar(
                            containerColor = DarkSurface,
                            contentColor = TextSecondary,
                            modifier = Modifier.height(72.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceAround,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                BottomTabItem(
                                    label = "Painel",
                                    icon = Icons.Default.Dashboard,
                                    isActive = currentScreen == "dashboard",
                                    onClick = { viewModel.navigateTo("dashboard") }
                                )
                                BottomTabItem(
                                    label = "Reparos",
                                    icon = Icons.Default.Construction,
                                    isActive = currentScreen == "ordens",
                                    onClick = { viewModel.navigateTo("ordens") }
                                )
                                BottomTabItem(
                                    label = "Clientes",
                                    icon = Icons.Default.People,
                                    isActive = currentScreen == "clientes",
                                    onClick = { viewModel.navigateTo("clientes") }
                                )
                                BottomTabItem(
                                    label = "Perfil",
                                    icon = Icons.Default.AccountCircle,
                                    isActive = currentScreen == "perfil",
                                    onClick = { viewModel.navigateTo("perfil") }
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    // Permanently show navigation sidebar on wider devices (tablet view)
                    if (isTablet) {
                        Box(
                            modifier = Modifier
                                .width(260.dp)
                                .fillMaxHeight()
                                .background(DarkSurface)
                                .border(BorderStroke(0.5.dp, DarkBorder))
                        ) {
                            DrawerSidebarContent(
                                currentScreen = currentScreen,
                                currentUserRole = currentUserRole,
                                assistanceName = technicalAssistanceName,
                                userName = loggedUserName,
                                onScreenSelect = { viewModel.navigateTo(it) },
                                onRoleChange = { viewModel.setUserRole(it) }
                            )
                        }
                    }

                    // Content Area
                    Box(modifier = Modifier.weight(1f)) {
                        when (currentScreen) {
                            "dashboard" -> DashboardScreen(
                                customers = customers,
                                serviceOrders = serviceOrders,
                                transactions = transactions,
                                inventory = inventory,
                                onNavigate = { viewModel.navigateTo(it) }
                            )
                            "ordens" -> ServiceOrdersScreen(
                                serviceOrders = serviceOrders,
                                customers = customers,
                                employees = employees,
                                onCreateOS = { custId, custName, custPhone, b, m, im, col, pass, cond, def, tech, valT, ent, disc, warr ->
                                    viewModel.createServiceOrder(custId, custName, custPhone, b, m, im, col, pass, cond, def, tech, valT, ent, disc, warr)
                                },
                                onUpdateOSStatus = { id, status ->
                                    viewModel.updateServiceOrderStatus(id, status)
                                },
                                onUpdateOSTechnical = { id, diag, rep, parts, tech, valT, disc, warr, sign ->
                                    viewModel.updateServiceOrderTechnical(id, diag, rep, parts, tech, valT, disc, warr, sign)
                                },
                                onDeleteOS = { viewModel.deleteServiceOrder(it) },
                                currentUserRole = currentUserRole
                            )
                            "clientes" -> CustomersScreen(
                                customers = customers,
                                devices = devices,
                                onAddCustomer = { n, cpf, ph, wa, em, ad ->
                                    viewModel.addCustomer(n, cpf, ph, wa, em, ad)
                                },
                                onAddDevice = { custId, b, m, im, col, pass, cond ->
                                    viewModel.addDevice(custId, b, m, im, col, pass, cond)
                                },
                                onDeleteCustomer = { viewModel.deleteCustomer(it) },
                                currentUserRole = currentUserRole
                            )
                            "estoque" -> InventoryScreen(
                                inventory = inventory,
                                onAddPart = { n, q, cp, sp, sup, b, th ->
                                    viewModel.addInventoryPart(n, q, cp, sp, sup, b, th)
                                },
                                onUpdatePart = { viewModel.updateInventoryPart(it) },
                                onDeletePart = { viewModel.deleteInventoryPart(it) },
                                currentUserRole = currentUserRole
                            )
                            "equipe" -> {
                                if (loggedUserPlan == "Básico") {
                                    SubscriptionScreen(
                                        currentPlan = loggedUserPlan,
                                        onUpgradeToPro = { viewModel.upgradeToPro() },
                                        blockedFeatureName = "Gestão de Funcionários & Equipe",
                                        pixKey = pixKey,
                                        pixKeyType = pixKeyType,
                                        pixMerchantName = pixMerchantName,
                                        pixMerchantCity = pixMerchantCity,
                                        assinaturas = assinaturas
                                    )
                                } else {
                                    EmployeesScreen(
                                        employees = employees,
                                        onAddEmployee = { n, l, r, comm ->
                                            viewModel.addEmployee(n, l, r, comm)
                                        },
                                        onDeleteEmployee = { viewModel.deleteEmployee(it) },
                                        platformUsers = viewModel.platformUsers.collectAsStateWithLifecycle().value,
                                        onAlterUserPlan = { login, newPlan ->
                                            viewModel.alterUserPlan(login, newPlan)
                                        },
                                        currentUserRole = currentUserRole
                                    )
                                }
                            }
                            "financeiro" -> {
                                if (loggedUserPlan == "Básico") {
                                    SubscriptionScreen(
                                        currentPlan = loggedUserPlan,
                                        onUpgradeToPro = { viewModel.upgradeToPro() },
                                        blockedFeatureName = "Controle Financeiro Ledger",
                                        pixKey = pixKey,
                                        pixKeyType = pixKeyType,
                                        pixMerchantName = pixMerchantName,
                                        pixMerchantCity = pixMerchantCity
                                    )
                                } else {
                                    FinancialScreen(
                                        transactions = transactions,
                                        onAddTransaction = { desc, amt, t, isP, cat ->
                                            viewModel.addTransaction(desc, amt, t, isP, cat)
                                        },
                                        onTogglePaid = { viewModel.toggleTransactionPaid(it) },
                                        onDelete = { viewModel.deleteTransaction(it) },
                                        currentUserRole = currentUserRole
                                    )
                                }
                            }
                            "documentos" -> {
                                if (loggedUserPlan == "Básico") {
                                    SubscriptionScreen(
                                        currentPlan = loggedUserPlan,
                                        onUpgradeToPro = { viewModel.upgradeToPro() },
                                        blockedFeatureName = "Laudos Técnicos & Documentos",
                                        pixKey = pixKey,
                                        pixKeyType = pixKeyType,
                                        pixMerchantName = pixMerchantName,
                                        pixMerchantCity = pixMerchantCity,
                                        assinaturas = assinaturas
                                    )
                                } else {
                                    DocumentsScreen(
                                        serviceOrders = serviceOrders,
                                        assistanceName = technicalAssistanceName
                                    )
                                }
                            }
                            "assinatura" -> SubscriptionScreen(
                                currentPlan = loggedUserPlan,
                                onUpgradeToPro = { viewModel.upgradeToPro() },
                                pixKey = pixKey,
                                pixKeyType = pixKeyType,
                                pixMerchantName = pixMerchantName,
                                pixMerchantCity = pixMerchantCity,
                                assinaturas = assinaturas
                            )
                            "perfil" -> ProfileScreen(
                                currentName = loggedUserName,
                                currentLogin = loggedUserLogin,
                                currentRole = currentUserRole,
                                assistanceName = technicalAssistanceName,
                                onUpdateProfile = { name, role, assistance, pwd ->
                                    viewModel.updateProfile(name, role, assistance, pwd)
                                },
                                onLogout = { viewModel.logout() },
                                pixKey = pixKey,
                                pixKeyType = pixKeyType,
                                pixMerchantName = pixMerchantName,
                                pixMerchantCity = pixMerchantCity,
                                onUpdatePixConfig = { key, type, name, city ->
                                    viewModel.updatePixConfig(key, type, name, city)
                                }
                            )
                            "rastreio" -> TrackingScreen(
                                trackedOrder = trackedOrder,
                                searchError = trackingSearchError,
                                onSearch = { viewModel.searchTrackedOrder(it) },
                                onClear = { viewModel.clearTracking() },
                                assistanceName = technicalAssistanceName,
                                pixKey = pixKey,
                                pixKeyType = pixKeyType,
                                pixMerchantName = pixMerchantName,
                                pixMerchantCity = pixMerchantCity,
                                onSimulatePayment = { id, amount -> viewModel.simulateTrackedOrderPayment(id, amount) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DrawerSidebarContent(
    currentScreen: String,
    currentUserRole: String,
    assistanceName: String,
    userName: String,
    onScreenSelect: (String) -> Unit,
    onRoleChange: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(bottom = 16.dp, top = 8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(Color.Black, RoundedCornerShape(8.dp))
                        .border(BorderStroke(1.5.dp, NeonGreen), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("ET", color = NeonGreen, fontSize = 16.sp, fontWeight = FontWeight.Black)
                }

                Column {
                    Text("EPIC TOUCH", fontWeight = FontWeight.Black, color = TextPrimary, fontSize = 16.sp, letterSpacing = 1.sp)
                    Text(assistanceName, fontSize = 10.sp, color = NeonGreen, fontWeight = FontWeight.Bold)
                }
            }

            Divider(color = DarkBorder, modifier = Modifier.padding(bottom = 8.dp))

            // Sidebar navigation items
            SidebarItem(label = "Dashboard", icon = Icons.Default.Dashboard, isActive = currentScreen == "dashboard", onClick = { onScreenSelect("dashboard") })
            SidebarItem(label = "Ordens de Serviço", icon = Icons.Default.Construction, isActive = currentScreen == "ordens", onClick = { onScreenSelect("ordens") })
            SidebarItem(label = "Clientes & Aparelhos", icon = Icons.Default.People, isActive = currentScreen == "clientes", onClick = { onScreenSelect("clientes") })
            SidebarItem(label = "Controle de Estoque", icon = Icons.Default.Inventory, isActive = currentScreen == "estoque", onClick = { onScreenSelect("estoque") })
            SidebarItem(label = "Controle Financeiro", icon = Icons.Default.AccountBalanceWallet, isActive = currentScreen == "financeiro", onClick = { onScreenSelect("financeiro") })
            SidebarItem(label = "Funcionários", icon = Icons.Default.Badge, isActive = currentScreen == "equipe", onClick = { onScreenSelect("equipe") })
            SidebarItem(label = "Laudos & Documentos", icon = Icons.Default.Description, isActive = currentScreen == "documentos", onClick = { onScreenSelect("documentos") })
            SidebarItem(label = "Portal do Cliente", icon = Icons.Default.Search, isActive = currentScreen == "rastreio", onClick = { onScreenSelect("rastreio") })
            SidebarItem(label = "Minha Assinatura", icon = Icons.Default.CardMembership, isActive = currentScreen == "assinatura", onClick = { onScreenSelect("assinatura") })
            SidebarItem(label = "Configurações de Perfil", icon = Icons.Default.AccountCircle, isActive = currentScreen == "perfil", onClick = { onScreenSelect("perfil") })
        }

        // Bottom - Profile role authorization simulated switcher
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Divider(color = DarkBorder)
            
            Text("Simulação de Nível de Acesso", fontSize = 9.sp, color = TextSecondary)
            
            var roleSwitcherExpanded by remember { mutableStateOf(false) }
            Box(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .background(DarkBackground, RoundedCornerShape(6.dp))
                        .border(BorderStroke(1.dp, NeonGreenDim), RoundedCornerShape(6.dp))
                        .clickable { roleSwitcherExpanded = true }
                        .padding(horizontal = 10.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.LockOpen, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(14.dp))
                            Text(currentUserRole, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                        Icon(Icons.Default.SwapHoriz, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(14.dp))
                    }
                }

                DropdownMenu(
                    expanded = roleSwitcherExpanded,
                    onDismissRequest = { roleSwitcherExpanded = false },
                    modifier = Modifier.background(DarkSurface)
                ) {
                    val roles = listOf("Administrador", "Técnico", "Atendente", "Caixa")
                    roles.forEach { r ->
                        DropdownMenuItem(
                            text = { Text(r, color = TextPrimary, fontSize = 12.sp) },
                            onClick = {
                                onRoleChange(r)
                                roleSwitcherExpanded = false
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SidebarItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isActive: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                if (isActive) NeonGreen.copy(alpha = 0.08f) else Color.Transparent,
                RoundedCornerShape(6.dp)
            )
            .border(
                BorderStroke(
                    0.5.dp,
                    if (isActive) NeonGreen.copy(alpha = 0.3f) else Color.Transparent
                ),
                RoundedCornerShape(6.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isActive) NeonGreen else TextSecondary,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = label,
                fontSize = 13.sp,
                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                color = if (isActive) NeonGreen else TextPrimary
            )
        }
    }
}

@Composable
fun BottomTabItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isActive: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clickable { onClick() }
            .padding(vertical = 4.dp, horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(
                        if (isActive) NeonGreen.copy(alpha = 0.1f) else Color.Transparent,
                        RoundedCornerShape(8.dp)
                    )
                    .border(
                        BorderStroke(
                            1.dp,
                            if (isActive) NeonGreen.copy(alpha = 0.2f) else Color.Transparent
                        ),
                        RoundedCornerShape(8.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isActive) NeonGreen else TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
            Text(
                text = label.uppercase(),
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = if (isActive) NeonGreen else TextSecondary,
                letterSpacing = 0.5.sp
            )
        }
    }
}

fun getScreenTitle(screen: String): String {
    return when(screen) {
        "dashboard" -> "Dashboard EPIC TOUCH"
        "ordens" -> "Ordens de Serviço"
        "clientes" -> "Clientes & Aparelhos"
        "estoque" -> "Controle de Estoque"
        "financeiro" -> "Financeiro Ledger"
        "equipe" -> "Funcionários & Equipe"
        "documentos" -> "Documentos & Laudos"
        "rastreio" -> "Acompanhamento do Reparo"
        "perfil" -> "Configurações de Perfil"
        "assinatura" -> "Minha Assinatura ⚡"
        else -> "EPIC TOUCH"
    }
}
