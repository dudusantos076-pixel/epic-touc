package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*

@Composable
fun DocumentsScreen(
    serviceOrders: List<ServiceOrder>,
    assistanceName: String,
    modifier: Modifier = Modifier
) {
    var activeDocType by remember { mutableStateOf("OXIDACAO") } // "OXIDACAO", "PLACA", "CHECKLIST", "GARANTIA"
    var selectedOSId by remember { mutableStateOf<Int?>(null) }
    var osDropdownExpanded by remember { mutableStateOf(false) }

    val context = LocalContext.current

    // Find active OS
    val selectedOS = serviceOrders.find { it.id == selectedOSId } ?: serviceOrders.firstOrNull()

    // Checklist states
    var wifiChecked by remember { mutableStateOf(true) }
    var bluetoothChecked by remember { mutableStateOf(true) }
    var screenChecked by remember { mutableStateOf(false) }
    var touchChecked by remember { mutableStateOf(false) }
    var audioChecked by remember { mutableStateOf(true) }
    var chargingChecked by remember { mutableStateOf(true) }
    var camerasChecked by remember { mutableStateOf(true) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Column {
            Text(
                text = "Documentos & Laudos",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Black,
                color = NeonGreen
            )
            Text(
                text = "Emissão de laudos de oxidação, placa, checklists e garantias",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
        }

        // Selected OS Reference bar
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = BorderStroke(1.dp, DarkBorder),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Vincular Dados da OS ao Documento", fontSize = 11.sp, color = TextSecondary)
                
                Box(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .background(DarkBackground, RoundedCornerShape(8.dp))
                            .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(8.dp))
                            .clickable { osDropdownExpanded = true }
                            .padding(horizontal = 12.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = selectedOS?.let { "${it.orderNumber} - ${it.customerName} (${it.deviceModel})" } ?: "Nenhuma OS cadastrada",
                                color = if (selectedOS != null) TextPrimary else TextSecondary,
                                fontSize = 13.sp
                            )
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = NeonGreen)
                        }
                    }

                    DropdownMenu(
                        expanded = osDropdownExpanded,
                        onDismissRequest = { osDropdownExpanded = false },
                        modifier = Modifier.background(DarkSurface)
                    ) {
                        serviceOrders.forEach { os ->
                            DropdownMenuItem(
                                text = { Text("${os.orderNumber} - ${os.customerName} (${os.deviceModel})", color = TextPrimary) },
                                onClick = {
                                    selectedOSId = os.id
                                    osDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // Tab Selector for Doc type
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            DocTab(label = "Oxidação", isActive = activeDocType == "OXIDACAO", onClick = { activeDocType = "OXIDACAO" }, modifier = Modifier.weight(1f))
            DocTab(label = "Placa", isActive = activeDocType == "PLACA", onClick = { activeDocType = "PLACA" }, modifier = Modifier.weight(1f))
            DocTab(label = "Checklist", isActive = activeDocType == "CHECKLIST", onClick = { activeDocType = "CHECKLIST" }, modifier = Modifier.weight(1f))
            DocTab(label = "Garantia", isActive = activeDocType == "GARANTIA", onClick = { activeDocType = "GARANTIA" }, modifier = Modifier.weight(1f))
        }

        // Document Canvas Preview
        if (selectedOS == null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Adicione uma Ordem de Serviço primeiro para gerar laudos.", color = TextSecondary)
            }
        } else {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = BorderStroke(1.dp, NeonGreen.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Assistance Header template
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(assistanceName.uppercase(), fontSize = 14.sp, fontWeight = FontWeight.Black, color = NeonGreen, letterSpacing = 1.sp)
                            Text("Laudos Técnicos Automatizados", fontSize = 9.sp, color = TextSecondary)
                        }
                        Box(
                            modifier = Modifier
                                .background(NeonGreen.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("OS REF: ${selectedOS.orderNumber}", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = NeonGreen)
                        }
                    }

                    Divider(color = DarkBorder)

                    // Client snapshot line
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Cliente", fontSize = 8.sp, color = TextSecondary)
                            Text(selectedOS.customerName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Aparelho", fontSize = 8.sp, color = TextSecondary)
                            Text("${selectedOS.deviceBrand} ${selectedOS.deviceModel}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                    }

                    Divider(color = DarkBorder)

                    // Specific Document bodies
                    when (activeDocType) {
                        "OXIDACAO" -> {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("LAUDO TÉCNICO DE OXIDAÇÃO (LIQUID DAMAGE)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AccentBlue)
                                Text(
                                    text = "Declaramos para os devidos fins que o aparelho citado foi submetido a análise química de oxidação sob microscópio. Foram localizados pontos de sulfatação e corrosão severa nas malhas de alimentação secundárias.\n\n" +
                                           "Procedimento efetuado: Banho químico ultrassônico com álcool isopropílico 99% e secagem em estufa térmica controlada.\n\n" +
                                           "Chances de recuperação: Moderadas (Aparelho necessita de troca de conectores adicionais).",
                                    fontSize = 11.sp,
                                    color = TextPrimary,
                                    lineHeight = 16.sp
                                )
                            }
                        }

                        "PLACA" -> {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("LAUDO DE REPARO AVANÇADO DE PLACA (IC MICRO-SOLDERING)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AccentPurple)
                                Text(
                                    text = "Laudo Técnico de microsoldagem de placa-mãe de celular.\n\n" +
                                           "Defeito Diagnosticado: Curto-circuito localizado na linha principal de alimentação PP_VCC_MAIN. Aparelho apresentava consumo total na fonte de bancada (bloqueio térmico).\n\n" +
                                           "Reparo Efetuado: Remoção de blindagens metálicas protetoras, mapeamento térmico via breu, substituição do CI PMIC correspondente e capacitores cerâmicos em curto na linha periférica. Placa reestabelecida com consumo normal de inicialização.",
                                    fontSize = 11.sp,
                                    color = TextPrimary,
                                    lineHeight = 16.sp
                                )
                            }
                        }

                        "CHECKLIST" -> {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("CHECKLIST DE COMPONENTES E PERIFÉRICOS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NeonGreen)
                                Text("Marque os testes validados antes da entrega do aparelho:", fontSize = 10.sp, color = TextSecondary)
                                
                                val checklists = listOf(
                                    "Wi-Fi & Bluetooth" to wifiChecked,
                                    "Tela / Brilho" to screenChecked,
                                    "Touchscreen / Sensibilidade" to touchChecked,
                                    "Áudio Alto-falante & Microfone" to audioChecked,
                                    "Conector de Carga / USB" to chargingChecked,
                                    "Câmeras Frontal & Traseira" to camerasChecked
                                )

                                checklists.forEach { item ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(DarkBackground, RoundedCornerShape(4.dp))
                                            .clickable {
                                                when(item.first) {
                                                    "Wi-Fi & Bluetooth" -> wifiChecked = !wifiChecked
                                                    "Tela / Brilho" -> screenChecked = !screenChecked
                                                    "Touchscreen / Sensibilidade" -> touchChecked = !touchChecked
                                                    "Áudio Alto-falante & Microfone" -> audioChecked = !audioChecked
                                                    "Conector de Carga / USB" -> chargingChecked = !chargingChecked
                                                    "Câmeras Frontal & Traseira" -> camerasChecked = !camerasChecked
                                                }
                                            }
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(item.first, fontSize = 11.sp, color = TextPrimary)
                                        Icon(
                                            imageVector = if (item.second) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                            contentDescription = null,
                                            tint = if (item.second) NeonGreen else TextSecondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }

                        "GARANTIA" -> {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("CERTIFICADO E TERMO DE GARANTIA LEGAL", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AccentOrange)
                                Text(
                                    text = "A $assistanceName assegura garantia de ${selectedOS.warrantyDays} dias para o serviço de reparo executado sob este código de ordem de serviço, contados a partir da data de retirada.\n\n" +
                                           "A garantia limita-se única e exclusivamente às peças substituídas e descritas no orçamento. Rompimento de lacres de segurança internos, indícios de quedas, lentes trincadas, sobrecarga elétrica ou contato com umidade invalidam automaticamente a garantia legal.",
                                    fontSize = 11.sp,
                                    color = TextPrimary,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Footer actions inside preview
                    Button(
                        onClick = {
                            Toast.makeText(context, "Emissão de PDF e Compartilhamento acionado!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Exportar e Compartilhar Laudo", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun DocTab(label: String, isActive: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(
                if (isActive) NeonGreen.copy(alpha = 0.08f) else Color.Transparent,
                RoundedCornerShape(6.dp)
            )
            .border(
                BorderStroke(
                    1.dp,
                    if (isActive) NeonGreen else DarkBorder
                ),
                RoundedCornerShape(6.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = if (isActive) NeonGreen else TextSecondary
        )
    }
}
