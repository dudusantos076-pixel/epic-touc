package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.*

@Composable
fun ServiceOrdersScreen(
    serviceOrders: List<ServiceOrder>,
    customers: List<Customer>,
    employees: List<Employee>,
    onCreateOS: (customerId: Int, customerName: String, customerPhone: String, brand: String, model: String, imei: String, color: String, password: String, condition: String, defect: String, techName: String, value: Double, entry: Double, discount: Double, warranty: Int) -> Unit,
    onUpdateOSStatus: (Int, String) -> Unit,
    onUpdateOSTechnical: (Int, String, String, String, String, Double, Double, Int, Boolean) -> Unit,
    onDeleteOS: (ServiceOrder) -> Unit,
    currentUserRole: String,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedTechFilter by remember { mutableStateOf("Todos") }
    
    // Status filters tabs
    val statuses = listOf("Todos", "Recebido", "Em análise", "Aguardando peça", "Em reparo", "Testes", "Pronto para retirada")
    var activeTab by remember { mutableStateOf("Todos") }

    // Dialog state
    var showCreateDialog by remember { mutableStateOf(false) }
    var selectedOSForDetail by remember { mutableStateOf<ServiceOrder?>(null) }

    // Context for Toast
    val context = LocalContext.current

    // Filtered list
    val filteredOrders = serviceOrders.filter { order ->
        val matchesSearch = order.orderNumber.contains(searchQuery, ignoreCase = true) ||
                order.customerName.contains(searchQuery, ignoreCase = true) ||
                order.deviceModel.contains(searchQuery, ignoreCase = true)
        
        val matchesTech = selectedTechFilter == "Todos" || order.technicianName.equals(selectedTechFilter, ignoreCase = true)
        
        val matchesTab = activeTab == "Todos" || order.status.equals(activeTab, ignoreCase = true)

        matchesSearch && matchesTech && matchesTab
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Ordens de Serviço",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Black,
                        color = NeonGreen
                    )
                    Text(
                        text = "Gerenciamento de reparos de eletrônicos",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
                
                if (currentUserRole != "Técnico") {
                    Button(
                        onClick = { showCreateDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("add_os_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Nova OS", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            // Search and Filters Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Buscar OS, Cliente, Aparelho...", color = TextSecondary, fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp)) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGreen,
                        unfocusedBorderColor = DarkBorder,
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1.5f)
                )

                // Technician Filter Dropdown Sim
                Box(modifier = Modifier.weight(1f)) {
                    var dropdownExpanded by remember { mutableStateOf(false) }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .background(DarkSurface, RoundedCornerShape(8.dp))
                            .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(8.dp))
                            .clickable { dropdownExpanded = true }
                            .padding(horizontal = 12.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Téc: $selectedTechFilter",
                                fontSize = 12.sp,
                                color = TextPrimary,
                                maxLines = 1
                            )
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = TextSecondary)
                        }
                    }

                    DropdownMenu(
                        expanded = dropdownExpanded,
                        onDismissRequest = { dropdownExpanded = false },
                        modifier = Modifier.background(DarkSurface)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Todos os Técnicos", color = TextPrimary) },
                            onClick = {
                                selectedTechFilter = "Todos"
                                dropdownExpanded = false
                            }
                        )
                        employees.filter { it.role == "Técnico" || it.role == "Administrador" }.forEach { emp ->
                            DropdownMenuItem(
                                text = { Text(emp.name, color = TextPrimary) },
                                onClick = {
                                    selectedTechFilter = emp.name
                                    dropdownExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            // Scrollable Status Tab bar (Notion style filter)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                statuses.forEach { tabName ->
                    val isSelected = activeTab == tabName
                    Box(
                        modifier = Modifier
                            .background(
                                if (isSelected) NeonGreen.copy(alpha = 0.15f) else Color.Transparent,
                                RoundedCornerShape(20.dp)
                            )
                            .border(
                                BorderStroke(
                                    1.dp,
                                    if (isSelected) NeonGreen else DarkBorder
                                ),
                                RoundedCornerShape(20.dp)
                            )
                            .clickable { activeTab = tabName }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = tabName,
                            color = if (isSelected) NeonGreen else TextSecondary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // Orders list or Kanban columns
            if (filteredOrders.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Inventory,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Nenhuma Ordem de Serviço encontrada.",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredOrders) { order ->
                        OSCard(
                            order = order,
                            onClick = { selectedOSForDetail = order },
                            onAdvanceStatus = {
                                val next = getNextStatus(order.status)
                                if (next != null) {
                                    onUpdateOSStatus(order.id, next)
                                    Toast.makeText(context, "OS avançada para: $next", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "OS já concluída!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        )
                    }
                }
            }
        }

        // Create Dialog
        if (showCreateDialog) {
            OSCreateDialog(
                customers = customers,
                employees = employees,
                onDismiss = { showCreateDialog = false },
                onSave = { custId, custName, custPhone, b, m, im, col, pass, cond, def, tech, valT, ent, disc, warr ->
                    onCreateOS(custId, custName, custPhone, b, m, im, col, pass, cond, def, tech, valT, ent, disc, warr)
                    showCreateDialog = false
                    Toast.makeText(context, "Ordem de Serviço registrada com sucesso!", Toast.LENGTH_SHORT).show()
                }
            )
        }

        // Details / Edit Dialog
        val activeOSDetail = selectedOSForDetail
        if (activeOSDetail != null) {
            OSDetailDialog(
                order = activeOSDetail,
                employees = employees,
                currentUserRole = currentUserRole,
                onDismiss = { selectedOSForDetail = null },
                onUpdateTechnical = { diag, rep, parts, tech, valT, disc, warr, sign ->
                    onUpdateOSTechnical(activeOSDetail.id, diag, rep, parts, tech, valT, disc, warr, sign)
                    selectedOSForDetail = null
                    Toast.makeText(context, "Laudo Técnico e orçamento salvos!", Toast.LENGTH_SHORT).show()
                },
                onDelete = {
                    onDeleteOS(activeOSDetail)
                    selectedOSForDetail = null
                    Toast.makeText(context, "Ordem de Serviço excluída.", Toast.LENGTH_SHORT).show()
                },
                onUpdateStatus = { status ->
                    onUpdateOSStatus(activeOSDetail.id, status)
                    // Refresh dialog view by updating local variable
                    selectedOSForDetail = activeOSDetail.copy(status = status)
                }
            )
        }
    }
}

// OSCard
@Composable
fun OSCard(
    order: ServiceOrder,
    onClick: () -> Unit,
    onAdvanceStatus: () -> Unit
) {
    val statusColor = when (order.status) {
        "Recebido" -> TextSecondary
        "Em análise" -> AccentBlue
        "Aguardando peça" -> AccentOrange
        "Em reparo" -> NeonGreen
        "Testes" -> AccentOrange
        "Finalizado", "Pronto para retirada" -> AccentPurple
        else -> TextPrimary
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
        shape = RoundedCornerShape(topStart = 0.dp, bottomStart = 0.dp, topEnd = 16.dp, bottomEnd = 16.dp),
        border = BorderStroke(1.dp, DarkBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(IntrinsicSize.Min)
        ) {
            // Left stripe with status color
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .fillMaxHeight()
                    .background(statusColor)
            )
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Header line
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = order.orderNumber,
                            fontWeight = FontWeight.Black,
                            color = NeonGreen,
                            fontSize = 14.sp
                        )
                        Box(
                            modifier = Modifier
                                .background(statusColor.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                .border(BorderStroke(1.dp, statusColor.copy(alpha = 0.3f)), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = order.status,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = statusColor
                            )
                        }
                    }

                    // Advance status action helper
                    val next = getNextStatus(order.status)
                    if (next != null) {
                        Box(
                            modifier = Modifier
                                .background(NeonGreen.copy(alpha = 0.08f), RoundedCornerShape(4.dp))
                                .border(BorderStroke(1.dp, NeonGreen.copy(alpha = 0.2f)), RoundedCornerShape(4.dp))
                                .clickable { onAdvanceStatus() }
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Avançar", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NeonGreen)
                                Spacer(modifier = Modifier.width(2.dp))
                                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(10.dp))
                            }
                        }
                    }
                }

                // Customer and device
                Column {
                    Text(
                        text = "${order.deviceBrand} ${order.deviceModel}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.Person, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(12.dp))
                        Text(
                            text = order.customerName,
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                }

                Divider(color = DarkBorder)

                // Defect and Tech responsible
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column(modifier = Modifier.weight(1.2f)) {
                        Text("Defeito Relatado", fontSize = 9.sp, color = TextSecondary)
                        Text(
                            text = order.defect,
                            fontSize = 12.sp,
                            color = Color.White,
                            maxLines = 1
                        )
                    }

                    Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(0.8f)) {
                        Text("Técnico", fontSize = 9.sp, color = TextSecondary)
                        Text(
                            text = if (order.technicianName.isEmpty()) "Não designado" else order.technicianName,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (order.technicianName.isEmpty()) AccentOrange else Color.White,
                            maxLines = 1
                        )
                    }
                }

                // Value summary
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val rem = order.totalValue - order.entryPayment - order.discount
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        LabelValueCompact(label = "Total", value = formatCurrency(order.totalValue), color = Color.White)
                        if (order.entryPayment > 0) {
                            LabelValueCompact(label = "Entrada", value = formatCurrency(order.entryPayment), color = Color.White)
                        }
                        if (rem > 0 && order.status != "Finalizado") {
                            LabelValueCompact(label = "Saldo", value = formatCurrency(rem), color = AccentOrange)
                        }
                    }
                    
                    if (order.hasSignature) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            Icon(Icons.Default.Draw, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(12.dp))
                            Text("Assinada", fontSize = 10.sp, color = NeonGreen, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LabelValueCompact(label: String, value: String, color: Color = TextPrimary) {
    Column {
        Text(label, fontSize = 8.sp, color = TextSecondary)
        Text(value, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

// OS Create Dialog
@Composable
fun OSCreateDialog(
    customers: List<Customer>,
    employees: List<Employee>,
    onDismiss: () -> Unit,
    onSave: (Int, String, String, String, String, String, String, String, String, String, String, Double, Double, Double, Int) -> Unit
) {
    // Selection state
    var selectedCustomer by remember { mutableStateOf<Customer?>(null) }
    var customerDropdownExpanded by remember { mutableStateOf(false) }

    // Form attributes
    var brand by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var imei by remember { mutableStateOf("") }
    var color by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var condition by remember { mutableStateOf("") }
    var defect by remember { mutableStateOf("") }
    var totalVal by remember { mutableStateOf("0.0") }
    var entryVal by remember { mutableStateOf("0.0") }
    var discountVal by remember { mutableStateOf("0.0") }
    var warrantyDays by remember { mutableStateOf("90") }
    var technicianName by remember { mutableStateOf("") }
    var techDropdownExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Registrar Ordem de Serviço", color = NeonGreen, fontWeight = FontWeight.Black) },
        containerColor = DarkSurface,
        confirmButton = {
            Button(
                onClick = {
                    val activeCust = selectedCustomer
                    if (activeCust != null) {
                        onSave(
                            activeCust.id,
                            activeCust.name,
                            activeCust.phone,
                            brand.trim(),
                            model.trim(),
                            imei.trim(),
                            color.trim(),
                            password.trim(),
                            condition.trim(),
                            defect.trim(),
                            technicianName,
                            totalVal.toDoubleOrNull() ?: 0.0,
                            entryVal.toDoubleOrNull() ?: 0.0,
                            discountVal.toDoubleOrNull() ?: 0.0,
                            warrantyDays.toIntOrNull() ?: 90
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                enabled = selectedCustomer != null && model.isNotEmpty() && defect.isNotEmpty()
            ) {
                Text("Registrar", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar", color = TextSecondary) }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Customer Selector
                Text("Cliente Responsável", fontSize = 11.sp, color = TextSecondary)
                Box(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .background(DarkBackground, RoundedCornerShape(8.dp))
                            .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(8.dp))
                            .clickable { customerDropdownExpanded = true }
                            .padding(horizontal = 12.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            text = selectedCustomer?.name ?: "Selecionar Cliente...",
                            color = if (selectedCustomer != null) TextPrimary else TextSecondary,
                            fontSize = 14.sp
                        )
                    }

                    DropdownMenu(
                        expanded = customerDropdownExpanded,
                        onDismissRequest = { customerDropdownExpanded = false },
                        modifier = Modifier
                            .fillMaxWidth(0.9f)
                            .background(DarkSurface)
                    ) {
                        if (customers.isEmpty()) {
                            DropdownMenuItem(text = { Text("Nenhum cliente cadastrado", color = AccentOrange) }, onClick = {})
                        }
                        customers.forEach { cust ->
                            DropdownMenuItem(
                                text = { Text("${cust.name} (${cust.phone})", color = TextPrimary) },
                                onClick = {
                                    selectedCustomer = cust
                                    customerDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Device info
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = brand,
                        onValueChange = { brand = it },
                        label = { Text("Marca (ex: Apple)") },
                        modifier = Modifier.weight(1f),
                        colors = dialogTextFieldColors()
                    )
                    OutlinedTextField(
                        value = model,
                        onValueChange = { model = it },
                        label = { Text("Modelo (ex: iPhone 13)") },
                        modifier = Modifier.weight(1.2f),
                        colors = dialogTextFieldColors()
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = imei,
                        onValueChange = { imei = it },
                        label = { Text("IMEI / Serial") },
                        modifier = Modifier.weight(1f),
                        colors = dialogTextFieldColors()
                    )
                    OutlinedTextField(
                        value = color,
                        onValueChange = { color = it },
                        label = { Text("Cor") },
                        modifier = Modifier.weight(0.8f),
                        colors = dialogTextFieldColors()
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Senha / Padrão") },
                        modifier = Modifier.weight(1f),
                        colors = dialogTextFieldColors()
                    )
                    OutlinedTextField(
                        value = warrantyDays,
                        onValueChange = { warrantyDays = it },
                        label = { Text("Garantia (Dias)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = dialogTextFieldColors()
                    )
                }

                OutlinedTextField(
                    value = condition,
                    onValueChange = { condition = it },
                    label = { Text("Estado de Entrada do Aparelho") },
                    placeholder = { Text("Riscos, amassados, sem película...") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = dialogTextFieldColors()
                )

                OutlinedTextField(
                    value = defect,
                    onValueChange = { defect = it },
                    label = { Text("Defeito Reclamado pelo Cliente") },
                    placeholder = { Text("Tela piscando, não carrega...") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = dialogTextFieldColors()
                )

                // Financial values
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = totalVal,
                        onValueChange = { totalVal = it },
                        label = { Text("Valor Total (R$)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        colors = dialogTextFieldColors()
                    )
                    OutlinedTextField(
                        value = entryVal,
                        onValueChange = { entryVal = it },
                        label = { Text("Entrada (R$)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        colors = dialogTextFieldColors()
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = discountVal,
                        onValueChange = { discountVal = it },
                        label = { Text("Desconto (R$)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        colors = dialogTextFieldColors()
                    )
                    
                    // Technician designator
                    Box(modifier = Modifier.weight(1f)) {
                        Column {
                            Text("Técnico", fontSize = 10.sp, color = TextSecondary)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .background(DarkBackground, RoundedCornerShape(4.dp))
                                    .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(4.dp))
                                    .clickable { techDropdownExpanded = true }
                                    .padding(horizontal = 12.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text(
                                    text = if (technicianName.isEmpty()) "Designar..." else technicianName,
                                    color = if (technicianName.isNotEmpty()) TextPrimary else TextSecondary,
                                    fontSize = 13.sp
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = techDropdownExpanded,
                            onDismissRequest = { techDropdownExpanded = false },
                            modifier = Modifier.background(DarkSurface)
                        ) {
                            employees.filter { it.role == "Técnico" || it.role == "Administrador" }.forEach { emp ->
                                DropdownMenuItem(
                                    text = { Text(emp.name, color = TextPrimary) },
                                    onClick = {
                                        technicianName = emp.name
                                        techDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    )
}

// OS Detailed view + edit
@Composable
fun OSDetailDialog(
    order: ServiceOrder,
    employees: List<Employee>,
    currentUserRole: String,
    onDismiss: () -> Unit,
    onUpdateTechnical: (String, String, String, String, Double, Double, Int, Boolean) -> Unit,
    onDelete: () -> Unit,
    onUpdateStatus: (String) -> Unit
) {
    var activeTab by remember { mutableStateOf("LAUDO") } // "LAUDO", "DOCUMENTO", "NOTIFICAR"

    // Technical fields
    var diagnosis by remember { mutableStateOf(order.diagnosis) }
    var report by remember { mutableStateOf(order.technicalReport) }
    var partsUsed by remember { mutableStateOf(order.partsUsed) }
    var technicianName by remember { mutableStateOf(order.technicianName) }
    var techDropdownExpanded by remember { mutableStateOf(false) }

    var totalVal by remember { mutableStateOf(order.totalValue.toString()) }
    var discountVal by remember { mutableStateOf(order.discount.toString()) }
    var warrantyDays by remember { mutableStateOf(order.warrantyDays.toString()) }
    
    // Signature
    var hasSignatureState by remember { mutableStateOf(order.hasSignature) }
    var isSigningPadVisible by remember { mutableStateOf(false) }

    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Gestão OS: ${order.orderNumber}",
                    color = NeonGreen,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp
                )
                
                // Status modifier dropdown inside details
                var statusDropdownExpanded by remember { mutableStateOf(false) }
                Box {
                    Box(
                        modifier = Modifier
                            .background(NeonGreen.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                            .border(BorderStroke(1.dp, NeonGreen.copy(alpha = 0.3f)), RoundedCornerShape(4.dp))
                            .clickable { statusDropdownExpanded = true }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(order.status, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NeonGreen)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(14.dp))
                        }
                    }

                    DropdownMenu(
                        expanded = statusDropdownExpanded,
                        onDismissRequest = { statusDropdownExpanded = false },
                        modifier = Modifier.background(DarkSurface)
                    ) {
                        val statusOpts = listOf("Recebido", "Em análise", "Aguardando peça", "Em reparo", "Testes", "Finalizado", "Pronto para retirada")
                        statusOpts.forEach { st ->
                            DropdownMenuItem(
                                text = { Text(st, color = TextPrimary) },
                                onClick = {
                                    onUpdateStatus(st)
                                    statusDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        },
        containerColor = DarkSurface,
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (currentUserRole == "Administrador") {
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Excluir OS", tint = AccentRed)
                    }
                }
                
                Button(
                    onClick = {
                        onUpdateTechnical(
                            diagnosis.trim(),
                            report.trim(),
                            partsUsed.trim(),
                            technicianName,
                            totalVal.toDoubleOrNull() ?: 0.0,
                            discountVal.toDoubleOrNull() ?: 0.0,
                            warrantyDays.toIntOrNull() ?: 90,
                            hasSignatureState
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black)
                ) {
                    Text("Salvar Alterações", fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Fechar", color = TextSecondary) }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Tab indicator
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    TabItem(label = "Técnico/Orçamento", isActive = activeTab == "LAUDO", onClick = { activeTab = "LAUDO" }, modifier = Modifier.weight(1f))
                    TabItem(label = "Documento", isActive = activeTab == "DOCUMENTO", onClick = { activeTab = "DOCUMENTO" }, modifier = Modifier.weight(0.8f))
                    TabItem(label = "Notificar", isActive = activeTab == "NOTIFICAR", onClick = { activeTab = "NOTIFICAR" }, modifier = Modifier.weight(0.8f))
                }

                Divider(color = DarkBorder)

                // Tab Content
                Box(modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .verticalScroll(rememberScrollState())) {
                    when (activeTab) {
                        "LAUDO" -> {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Aparelho: ${order.deviceBrand} ${order.deviceModel}", fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text("Defeito informado: ${order.defect}", color = TextSecondary, fontSize = 12.sp)
                                if (order.devicePasswordKey.isNotEmpty()) {
                                    Text("Senha do Aparelho: ${order.devicePasswordKey}", color = AccentOrange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                OutlinedTextField(
                                    value = diagnosis,
                                    onValueChange = { diagnosis = it },
                                    label = { Text("Diagnóstico Técnico") },
                                    placeholder = { Text("Placa em curto, circuito de carga oxidado...") },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = dialogTextFieldColors()
                                )

                                OutlinedTextField(
                                    value = report,
                                    onValueChange = { report = it },
                                    label = { Text("Laudo Técnico / Descrição do Serviço") },
                                    placeholder = { Text("Realizada a desoxidação e reballing do chip...") },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = dialogTextFieldColors()
                                )

                                OutlinedTextField(
                                    value = partsUsed,
                                    onValueChange = { partsUsed = it },
                                    label = { Text("Peças Utilizadas") },
                                    placeholder = { Text("Conector G60, Solda em pasta (separar por vírgula)") },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = dialogTextFieldColors()
                                )

                                // Tech Selector
                                Box(modifier = Modifier.fillMaxWidth()) {
                                    Column {
                                        Text("Técnico Responsável", fontSize = 11.sp, color = TextSecondary)
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(56.dp)
                                                .background(DarkBackground, RoundedCornerShape(4.dp))
                                                .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(4.dp))
                                                .clickable { techDropdownExpanded = true }
                                                .padding(horizontal = 12.dp),
                                            contentAlignment = Alignment.CenterStart
                                        ) {
                                            Text(
                                                text = if (technicianName.isEmpty()) "Designar..." else technicianName,
                                                color = if (technicianName.isNotEmpty()) TextPrimary else TextSecondary,
                                                fontSize = 14.sp
                                            )
                                        }
                                    }

                                    DropdownMenu(
                                        expanded = techDropdownExpanded,
                                        onDismissRequest = { techDropdownExpanded = false },
                                        modifier = Modifier.background(DarkSurface)
                                    ) {
                                        employees.filter { it.role == "Técnico" || it.role == "Administrador" }.forEach { emp ->
                                            DropdownMenuItem(
                                                text = { Text(emp.name, color = TextPrimary) },
                                                onClick = {
                                                    technicianName = emp.name
                                                    techDropdownExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = totalVal,
                                        onValueChange = { totalVal = it },
                                        label = { Text("Valor Total (R$)") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                        modifier = Modifier.weight(1f),
                                        colors = dialogTextFieldColors()
                                    )
                                    OutlinedTextField(
                                        value = discountVal,
                                        onValueChange = { discountVal = it },
                                        label = { Text("Desconto (R$)") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                        modifier = Modifier.weight(1f),
                                        colors = dialogTextFieldColors()
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    OutlinedTextField(
                                        value = warrantyDays,
                                        onValueChange = { warrantyDays = it },
                                        label = { Text("Garantia (Dias)") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        modifier = Modifier.weight(1.2f),
                                        colors = dialogTextFieldColors()
                                    )

                                    Column(
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(top = 8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Button(
                                            onClick = { isSigningPadVisible = true },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (hasSignatureState) Color(0xFF1B5E20) else NeonGreen,
                                                contentColor = if (hasSignatureState) Color.White else Color.Black
                                            ),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(Icons.Default.Draw, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(if (hasSignatureState) "Assinada" else "Assinar", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }

                                // Interactive Signature pad popup dialog
                                if (isSigningPadVisible) {
                                    AlertDialog(
                                        onDismissRequest = { isSigningPadVisible = false },
                                        title = { Text("Assinatura Digital", color = NeonGreen) },
                                        containerColor = DarkSurface,
                                        confirmButton = {
                                            Button(
                                                onClick = {
                                                    hasSignatureState = true
                                                    isSigningPadVisible = false
                                                    Toast.makeText(context, "Assinatura vinculada à Ordem de Serviço!", Toast.LENGTH_SHORT).show()
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black)
                                            ) {
                                                Text("Confirmar")
                                            }
                                        },
                                        dismissButton = {
                                            TextButton(onClick = { isSigningPadVisible = false }) { Text("Limpar / Voltar", color = AccentRed) }
                                        },
                                        text = {
                                            Column(verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                                Text("Desenhe a assinatura do cliente ou técnico abaixo:", fontSize = 12.sp, color = TextSecondary)
                                                
                                                // Real touch-drawing Canvas!
                                                var pointsList = remember { mutableStateListOf<Offset>() }
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .height(150.dp)
                                                        .background(Color.Black, RoundedCornerShape(8.dp))
                                                        .border(BorderStroke(1.dp, NeonGreenDim), RoundedCornerShape(8.dp))
                                                        .pointerInput(Unit) {
                                                            detectDragGestures(
                                                                onDragStart = { offset -> pointsList.add(offset) },
                                                                onDrag = { change, dragAmount ->
                                                                    change.consume()
                                                                    pointsList.add(change.position)
                                                                }
                                                            )
                                                        }
                                                ) {
                                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                                        val path = Path()
                                                        if (pointsList.isNotEmpty()) {
                                                            path.moveTo(pointsList[0].x, pointsList[0].y)
                                                            for (i in 1 until pointsList.size) {
                                                                path.lineTo(pointsList[i].x, pointsList[i].y)
                                                            }
                                                            drawPath(
                                                                path = path,
                                                                color = NeonGreen,
                                                                style = Stroke(width = 3.dp.toPx())
                                                            )
                                                        }
                                                    }
                                                    if (pointsList.isEmpty()) {
                                                        Text("Escreva aqui...", color = TextSecondary.copy(alpha = 0.5f), fontSize = 11.sp, modifier = Modifier.align(Alignment.Center))
                                                    }
                                                }
                                            }
                                        }
                                    )
                                }
                            }
                        }

                        "DOCUMENTO" -> {
                            // Document view
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Visualização do Documento Oficial", fontWeight = FontWeight.Bold, color = TextPrimary)
                                
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color.Black, RoundedCornerShape(8.dp))
                                        .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(8.dp))
                                        .padding(16.dp)
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("EPIC TOUCH ASSISTÊNCIA TÉCNICA", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NeonGreen)
                                        Text("Código OS: ${order.orderNumber}", fontSize = 10.sp, color = TextPrimary)
                                        Text("Data: ${formatDate(order.createdAt)}", fontSize = 9.sp, color = TextSecondary)
                                        Divider(color = DarkBorder)
                                        
                                        Text("CLIENTE: ${order.customerName}", fontSize = 10.sp, color = TextPrimary)
                                        Text("APARELHO: ${order.deviceBrand} ${order.deviceModel} (Serial: ${order.deviceImei})", fontSize = 10.sp, color = TextPrimary)
                                        Text("DEFEITO RECLAMADO: ${order.defect}", fontSize = 10.sp, color = TextPrimary)
                                        
                                        if (diagnosis.isNotEmpty()) {
                                            Text("DIAGNÓSTICO TÉCNICO: $diagnosis", fontSize = 10.sp, color = AccentBlue)
                                        }
                                        if (report.isNotEmpty()) {
                                            Text("LAUDO DE REPARO: $report", fontSize = 10.sp, color = NeonGreen)
                                        }
                                        if (partsUsed.isNotEmpty()) {
                                            Text("PEÇAS APLICADAS: $partsUsed", fontSize = 10.sp, color = TextPrimary)
                                        }

                                        Divider(color = DarkBorder)
                                        Text("GARANTIA: ${warrantyDays} DIAS APÓS A RETIRADA", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                        
                                        val remainingVal = (totalVal.toDoubleOrNull() ?: 0.0) - order.entryPayment - (discountVal.toDoubleOrNull() ?: 0.0)
                                        Text("VALOR TOTAL: ${formatCurrency(totalVal.toDoubleOrNull() ?: 0.0)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NeonGreen)
                                        Text("ENTRADA: ${formatCurrency(order.entryPayment)}", fontSize = 9.sp, color = TextSecondary)
                                        Text("DESCONTO: ${formatCurrency(discountVal.toDoubleOrNull() ?: 0.0)}", fontSize = 9.sp, color = TextSecondary)
                                        Text("SALDO PENDENTE: ${formatCurrency(remainingVal)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AccentOrange)

                                        Spacer(modifier = Modifier.height(10.dp))
                                        if (hasSignatureState) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                                                Box(
                                                    modifier = Modifier
                                                        .width(120.dp)
                                                        .height(2.dp)
                                                        .background(TextSecondary)
                                                )
                                                Text("Documento Assinado Digitalmente", fontSize = 8.sp, color = NeonGreen)
                                            }
                                        } else {
                                            Text("DOCUMENTO PENDENTE DE ASSINATURA", fontSize = 8.sp, color = AccentOrange, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                                        }
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = { Toast.makeText(context, "Documento exportado para PDF (salvo na pasta de downloads)", Toast.LENGTH_SHORT).show() },
                                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceCard, contentColor = TextPrimary),
                                        border = BorderStroke(1.dp, DarkBorder),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Exportar PDF", fontSize = 11.sp)
                                    }

                                    Button(
                                        onClick = { Toast.makeText(context, "OS impressa na impressora térmica Bluetooth vinculada", Toast.LENGTH_SHORT).show() },
                                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceCard, contentColor = TextPrimary),
                                        border = BorderStroke(1.dp, DarkBorder),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Imprimir Cupom", fontSize = 11.sp)
                                    }
                                }
                            }
                        }

                        "NOTIFICAR" -> {
                            // WhatsApp / SMS / Email trigger sims
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Notificar Cliente Sobre o Reparo", fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text("O cliente ${order.customerName} receberá uma mensagem detalhando o status '${order.status}' do seu aparelho.", fontSize = 11.sp, color = TextSecondary)

                                val messageBody = "Olá ${order.customerName}, aqui é da Epic Touch! O status do reparo do seu ${order.deviceBrand} ${order.deviceModel} foi atualizado para: *${order.status}*.\nVocê pode acompanhar em tempo real usando o código: *${order.orderNumber}* no nosso aplicativo!"

                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color.Black),
                                    border = BorderStroke(1.dp, NeonGreenDim),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("Prévia da Mensagem (Notificação):", fontSize = 8.sp, color = NeonGreen)
                                        Text(messageBody, fontSize = 11.sp, color = TextPrimary)
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            // Launch WhatsApp send intent
                                            try {
                                                val intent = Intent(Intent.ACTION_SEND).apply {
                                                    type = "text/plain"
                                                    putExtra(Intent.EXTRA_TEXT, messageBody)
                                                }
                                                context.startActivity(Intent.createChooser(intent, "Enviar Notificação"))
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "WhatsApp acionado: Notificação Enviada!", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366), contentColor = Color.Black),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Message, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Via WhatsApp", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Button(
                                        onClick = {
                                            Toast.makeText(context, "E-mail enviado para: ${order.customerName.replace(" ", "").lowercase()}@epic.com", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = AccentBlue, contentColor = Color.Black),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Email, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Via E-mail", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    )
}

@Composable
fun TabItem(label: String, isActive: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(
                if (isActive) NeonGreen.copy(alpha = 0.08f) else Color.Transparent,
                RoundedCornerShape(6.dp)
            )
            .border(
                BorderStroke(
                    1.dp,
                    if (isActive) NeonGreen else Color.Transparent
                ),
                RoundedCornerShape(6.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
            color = if (isActive) NeonGreen else TextSecondary,
            textAlign = TextAlign.Center
        )
    }
}

// Helpers
fun getNextStatus(currentStatus: String): String? {
    return when (currentStatus) {
        "Recebido" -> "Em análise"
        "Em análise" -> "Aguardando peça"
        "Aguardando peça" -> "Em reparo"
        "Em reparo" -> "Testes"
        "Testes" -> "Pronto para retirada"
        "Pronto para retirada" -> "Finalizado"
        else -> null
    }
}

fun formatCurrency(value: Double): String {
    return NumberFormat.getCurrencyInstance(Locale("pt", "BR")).format(value)
}

fun formatDate(timestamp: Long): String {
    val sdf = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
    return sdf.format(Date(timestamp))
}

@Composable
fun dialogTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = NeonGreen,
    unfocusedBorderColor = DarkBorder,
    focusedContainerColor = DarkBackground,
    unfocusedContainerColor = DarkBackground,
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    focusedLabelColor = NeonGreen,
    unfocusedLabelColor = TextSecondary
)
