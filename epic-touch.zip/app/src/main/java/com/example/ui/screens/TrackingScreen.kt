package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun TrackingScreen(
    trackedOrder: ServiceOrder?,
    searchError: String?,
    onSearch: (String) -> Unit,
    onClear: () -> Unit,
    assistanceName: String,
    pixKey: String,
    pixKeyType: String,
    pixMerchantName: String,
    pixMerchantCity: String,
    onSimulatePayment: (Int, Double) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchInput by remember { mutableStateOf("") }
    val context = LocalContext.current

    // Stepper statuses list
    val trackingSteps = listOf(
        "Recebido",
        "Em análise",
        "Aguardando peça",
        "Em reparo",
        "Testes",
        "Pronto para retirada",
        "Finalizado"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Welcome Header
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(NeonGreen.copy(alpha = 0.08f), RoundedCornerShape(24.dp))
                    .border(BorderStroke(1.dp, NeonGreen), RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.QueryStats, contentDescription = null, tint = NeonGreen)
            }
            Text(
                text = "Portal de Rastreamento",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                color = TextPrimary,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Acompanhe o status do seu reparo em tempo real, sem filas ou mensagens",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp)
            )
        }

        // Search Input Card
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            border = BorderStroke(1.dp, DarkBorder),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Consulte seu Reparo",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonGreen
                )

                OutlinedTextField(
                    value = searchInput,
                    onValueChange = { searchInput = it },
                    placeholder = { Text("Código OS (ex: OS-2026-0001) ou celular...", color = TextSecondary, fontSize = 12.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGreen,
                        unfocusedBorderColor = DarkBorder,
                        focusedContainerColor = DarkBackground,
                        unfocusedContainerColor = DarkBackground,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (trackedOrder != null) {
                        Button(
                            onClick = {
                                onClear()
                                searchInput = ""
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceCard, contentColor = TextPrimary),
                            border = BorderStroke(1.dp, DarkBorder),
                            modifier = Modifier.weight(0.8f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Limpar")
                        }
                    }

                    Button(
                        onClick = { onSearch(searchInput) },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                        modifier = Modifier.weight(1.2f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Acompanhar", fontWeight = FontWeight.Bold)
                    }
                }

                // Error feedback
                if (searchError != null) {
                    Text(
                        text = searchError,
                        color = AccentRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Stepper Visual Progress Details
        if (trackedOrder != null) {
            val activeStatusIndex = trackingSteps.indexOf(trackedOrder.status).coerceAtLeast(0)

            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = BorderStroke(1.dp, NeonGreen.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Device info line
                    Column {
                        Text(
                            text = "${trackedOrder.deviceBrand} ${trackedOrder.deviceModel}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = TextPrimary
                        )
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Código: ${trackedOrder.orderNumber}",
                                fontSize = 11.sp,
                                color = NeonGreen,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Responsável: ${trackedOrder.technicianName.ifEmpty { "Triagem" }}",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    Divider(color = DarkBorder)

                    // Vertical Stepper Timeline
                    Column(
                        verticalArrangement = Arrangement.spacedBy(0.dp)
                    ) {
                        trackingSteps.forEachIndexed { index, stepName ->
                            val isCompleted = index < activeStatusIndex
                            val isActive = index == activeStatusIndex
                            val isPending = index > activeStatusIndex

                            val stepColor = when {
                                isActive -> NeonGreen
                                isCompleted -> NeonGreenDim
                                else -> TextSecondary
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                // Left indicator dot & line
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.width(36.dp)
                                ) {
                                    // Dot
                                    Box(
                                        modifier = Modifier
                                            .size(20.dp)
                                            .background(
                                                if (isActive) NeonGreen.copy(alpha = 0.15f) else Color.Transparent,
                                                RoundedCornerShape(10.dp)
                                            )
                                            .border(
                                                BorderStroke(
                                                    if (isActive) 2.dp else 1.dp,
                                                    stepColor
                                                ),
                                                RoundedCornerShape(10.dp)
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (isCompleted) {
                                            Icon(Icons.Default.Check, contentDescription = null, tint = NeonGreenDim, modifier = Modifier.size(12.dp))
                                        } else if (isActive) {
                                            Box(modifier = Modifier.size(8.dp).background(NeonGreen, RoundedCornerShape(4.dp)))
                                        }
                                    }

                                    // Line (not drawn for last item)
                                    if (index < trackingSteps.size - 1) {
                                        Box(
                                            modifier = Modifier
                                                .width(2.dp)
                                                .height(28.dp)
                                                .background(if (isCompleted) NeonGreenDim else DarkBorder)
                                        )
                                    }
                                }

                                // Step details text
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(start = 8.dp)
                                ) {
                                    Text(
                                        text = stepName,
                                        fontSize = 13.sp,
                                        fontWeight = if (isActive) FontWeight.Black else FontWeight.Bold,
                                        color = if (isActive) NeonGreen else if (isCompleted) TextPrimary else TextSecondary
                                    )
                                    Text(
                                        text = when(stepName) {
                                            "Recebido" -> "Aparelho recebido na $assistanceName e fila de triagem iniciada."
                                            "Em análise" -> "Técnico especializado testando hardware e diagnosticando o defeito."
                                            "Aguardando peça" -> "Peça de reposição solicitada ao nosso estoque ou fornecedor parceiro."
                                            "Em reparo" -> "Mesa de solda/bancada ativa. Substituição de componentes em andamento."
                                            "Testes" -> "Protocolo de testes de estresse: touch, carga, câmeras e sensores."
                                            "Pronto para retirada" -> "Dispositivo higienizado e pronto! Traga um documento com foto."
                                            "Finalizado" -> "Reparo entregue e certificado de garantia de ${trackedOrder.warrantyDays} dias emitido."
                                            else -> ""
                                        },
                                        fontSize = 10.sp,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }

                    // Done success message & Pix payment option
                    if (trackedOrder.status == "Pronto para retirada" || trackedOrder.status == "Finalizado") {
                        val remaining = trackedOrder.totalValue - trackedOrder.entryPayment - trackedOrder.discount

                        Divider(color = DarkBorder)

                        if (remaining > 0) {
                            var showPixDetails by remember { mutableStateOf(false) }
                            var isConfirmingPayment by remember { mutableStateOf(false) }
                            val coroutineScope = rememberCoroutineScope()

                            val pixPayload = remember(pixKey, remaining, trackedOrder.orderNumber) {
                                com.example.ui.PixHelper.generatePixQrCode(
                                    pixKey = pixKey,
                                    merchantName = pixMerchantName,
                                    merchantCity = pixMerchantCity,
                                    amount = remaining,
                                    txid = trackedOrder.orderNumber.replace("-", "")
                                )
                            }

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(DarkSurfaceCard, RoundedCornerShape(12.dp))
                                    .border(BorderStroke(1.dp, NeonGreen.copy(alpha = 0.4f)), RoundedCornerShape(12.dp))
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Bolt, contentDescription = null, tint = NeonGreen)
                                    Text("Pagar com Pix Online", fontSize = 14.sp, fontWeight = FontWeight.Black, color = Color.White)
                                }

                                Text(
                                    text = "Seu aparelho está PRONTO! O saldo final de R$ ${String.format(Locale.US, "%.2f", remaining)} pode ser pago via Pix agora mesmo para agilizar a entrega na retirada.",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )

                                if (!showPixDetails) {
                                    Button(
                                        onClick = { showPixDetails = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Gerar QR Code Pix", fontWeight = FontWeight.Bold)
                                    }
                                } else {
                                    // Expand details
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(12.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(180.dp)
                                                .background(DarkBackground, RoundedCornerShape(8.dp))
                                                .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(8.dp))
                                                .padding(10.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            com.example.ui.PixQRCodeCanvas(
                                                payload = pixPayload,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                        }

                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(DarkBackground, RoundedCornerShape(6.dp))
                                                .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(6.dp))
                                                .padding(8.dp)
                                        ) {
                                            Row(
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Text("CHAVE: $pixKey ($pixKeyType)", fontSize = 8.sp, color = TextSecondary)
                                                Text("Cópia e Cola", fontSize = 8.sp, color = NeonGreen, fontWeight = FontWeight.Bold)
                                            }
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = pixPayload,
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                maxLines = 2,
                                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                            )
                                        }

                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Button(
                                                onClick = {
                                                    val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                                    val clip = android.content.ClipData.newPlainText("Código Pix", pixPayload)
                                                    clipboard.setPrimaryClip(clip)
                                                    Toast.makeText(context, "Código Pix copiado!", Toast.LENGTH_SHORT).show()
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = DarkSurface, contentColor = Color.White),
                                                border = BorderStroke(1.dp, DarkBorder),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Copiar", fontSize = 11.sp)
                                            }

                                            Button(
                                                onClick = {
                                                    isConfirmingPayment = true
                                                    onSimulatePayment(trackedOrder.id, remaining)
                                                    Toast.makeText(context, "Pagamento recebido com sucesso!", Toast.LENGTH_LONG).show()
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.weight(1.2f)
                                            ) {
                                                if (isConfirmingPayment) {
                                                    CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(16.dp))
                                                } else {
                                                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(14.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Simular Pago", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            // Paid Success Feedback
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(NeonGreen.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                                    .border(BorderStroke(1.dp, NeonGreen), RoundedCornerShape(12.dp))
                                    .padding(16.dp)
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NeonGreen, modifier = Modifier.size(24.dp))
                                        Text("PAGAMENTO CONFIRMADO!", fontSize = 14.sp, fontWeight = FontWeight.Black, color = NeonGreen)
                                    }
                                    Text(
                                        text = "O valor total deste reparo foi totalmente liquidado. Seu dispositivo está liberado e pronto para retirada na bancada da $assistanceName.",
                                        fontSize = 11.sp,
                                        color = TextPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
