package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*

@Composable
fun InventoryScreen(
    inventory: List<InventoryPart>,
    onAddPart: (String, Int, Double, Double, String, String, Int) -> Unit,
    onUpdatePart: (InventoryPart) -> Unit,
    onDeletePart: (InventoryPart) -> Unit,
    currentUserRole: String,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var filterLowStockOnly by remember { mutableStateOf(false) }

    var showAddDialog by remember { mutableStateOf(false) }
    var showScanDialog by remember { mutableStateOf(false) }
    var scanQueryCode by remember { mutableStateOf("") }

    val context = LocalContext.current

    // Filtered inventory
    val filteredInventory = inventory.filter { part ->
        val matchesSearch = part.name.contains(searchQuery, ignoreCase = true) ||
                part.barcode.contains(searchQuery) ||
                part.supplier.contains(searchQuery, ignoreCase = true)
        
        val matchesAlert = !filterLowStockOnly || (part.quantity <= part.lowStockThreshold)

        matchesSearch && matchesAlert
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Controle de Estoque",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Black,
                        color = NeonGreen
                    )
                    Text(
                        text = "Peças de reposição e componentes",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Barcode reader simulation button
                    IconButton(
                        onClick = { showScanDialog = true },
                        modifier = Modifier
                            .background(DarkSurface, RoundedCornerShape(8.dp))
                            .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(8.dp))
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = "Simular Leitor", tint = NeonGreen)
                    }

                    if (currentUserRole != "Técnico") {
                        Button(
                            onClick = { showAddDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("add_part_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Adicionar", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }

            // Search Bar + Quick low stock alert toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Buscar peça ou código de barras...", color = TextSecondary, fontSize = 12.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp)) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGreen,
                        unfocusedBorderColor = DarkBorder,
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                )

                // Alert toggle
                Box(
                    modifier = Modifier
                        .height(56.dp)
                        .background(
                            if (filterLowStockOnly) AccentRed.copy(alpha = 0.15f) else DarkSurface,
                            RoundedCornerShape(8.dp)
                        )
                        .border(
                            BorderStroke(1.dp, if (filterLowStockOnly) AccentRed else DarkBorder),
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { filterLowStockOnly = !filterLowStockOnly }
                        .padding(horizontal = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (filterLowStockOnly) AccentRed else TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Estoque Baixo",
                            color = if (filterLowStockOnly) AccentRed else TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Pieces list
            if (filteredInventory.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Nenhuma peça correspondente em estoque.", color = TextSecondary, fontSize = 13.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredInventory) { part ->
                        PartItemRow(
                            part = part,
                            onUpdateQty = { newQty ->
                                onUpdatePart(part.copy(quantity = newQty))
                                Toast.makeText(context, "Estoque de ${part.name} atualizado!", Toast.LENGTH_SHORT).show()
                            },
                            onDelete = {
                                onDeletePart(part)
                                Toast.makeText(context, "Peça removida do estoque.", Toast.LENGTH_SHORT).show()
                            },
                            currentUserRole = currentUserRole
                        )
                    }
                }
            }
        }

        // Add Part Dialog
        if (showAddDialog) {
            PartAddDialog(
                onDismiss = { showAddDialog = false },
                onSave = { n, q, cp, sp, sup, b, th ->
                    onAddPart(n, q, cp, sp, sup, b, th)
                    showAddDialog = false
                    Toast.makeText(context, "Peça adicionada ao estoque!", Toast.LENGTH_SHORT).show()
                }
            )
        }

        // Simulated Barcode Scanner Dialog
        if (showScanDialog) {
            AlertDialog(
                onDismissRequest = { showScanDialog = false },
                title = { Text("Simular Leitor de Código", color = NeonGreen, fontWeight = FontWeight.Black) },
                containerColor = DarkSurface,
                confirmButton = {
                    Button(
                        onClick = {
                            val match = inventory.find { it.barcode == scanQueryCode.trim() }
                            if (match != null) {
                                Toast.makeText(context, "Sucesso: ${match.name} localizado!", Toast.LENGTH_LONG).show()
                                searchQuery = match.barcode
                                showScanDialog = false
                            } else {
                                Toast.makeText(context, "Código de barras não localizado no estoque!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black)
                    ) {
                        Text("Escanear")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showScanDialog = false }) { Text("Voltar", color = TextSecondary) }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Digite ou simule a leitura do código de barras da etiqueta:", fontSize = 12.sp, color = TextSecondary)
                        OutlinedTextField(
                            value = scanQueryCode,
                            onValueChange = { scanQueryCode = it },
                            placeholder = { Text("Ex: 789101114") },
                            colors = dialogTextFieldColors(),
                            modifier = Modifier.fillMaxWidth(),
                            trailingIcon = {
                                IconButton(onClick = {
                                    // pick a random existing barcode to simulate instantly
                                    val randomCode = inventory.randomOrNull()?.barcode ?: "789101112"
                                    scanQueryCode = randomCode
                                    Toast.makeText(context, "Código lido via gatilho laser!", Toast.LENGTH_SHORT).show()
                                }) {
                                    Icon(Icons.Default.FlashOn, contentDescription = "Gatilho Laser", tint = NeonGreen)
                                }
                            }
                        )
                        Text("Dica: Toque no raio ⚡ para simular leitura física instantânea do leitor EPIC TOUCH.", fontSize = 10.sp, color = TextSecondary)
                    }
                }
            )
        }
    }
}

@Composable
fun PartItemRow(
    part: InventoryPart,
    onUpdateQty: (Int) -> Unit,
    onDelete: () -> Unit,
    currentUserRole: String
) {
    val isLowStock = part.quantity <= part.lowStockThreshold

    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.dp, if (isLowStock) AccentRed.copy(alpha = 0.5f) else DarkBorder),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1.5f)) {
                    Text(
                        text = part.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "Fornecedor: ${part.supplier} • Cód: ${part.barcode}",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Low stock alarm badge
                if (isLowStock) {
                    Box(
                        modifier = Modifier
                            .background(AccentRed.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                            .border(BorderStroke(1.dp, AccentRed.copy(alpha = 0.3f)), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (part.quantity == 0) "ESGOTADO" else "ALERTA BAIXO",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentRed
                        )
                    }
                }
            }

            Divider(color = DarkBorder)

            // Price indicators and Adjusters
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Financial Info
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column {
                        Text("Preço Compra", fontSize = 8.sp, color = TextSecondary)
                        Text(formatCurrency(part.purchasePrice), fontSize = 12.sp, color = TextPrimary)
                    }

                    Column {
                        Text("Preço Venda", fontSize = 8.sp, color = TextSecondary)
                        Text(formatCurrency(part.salePrice), fontSize = 12.sp, color = NeonGreen, fontWeight = FontWeight.Bold)
                    }
                }

                // Adjust Quantity (If Admin/Atendente/Caixa)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Qtd: ${part.quantity}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isLowStock) AccentRed else TextPrimary
                    )

                    if (currentUserRole != "Técnico") {
                        Row(
                            modifier = Modifier
                                .background(DarkBackground, RoundedCornerShape(4.dp))
                                .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(4.dp))
                        ) {
                            IconButton(
                                onClick = { if (part.quantity > 0) onUpdateQty(part.quantity - 1) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = "Diminuir", tint = TextPrimary, modifier = Modifier.size(14.dp))
                            }
                            Divider(modifier = Modifier.width(1.dp).height(20.dp).align(Alignment.CenterVertically), color = DarkBorder)
                            IconButton(
                                onClick = { onUpdateQty(part.quantity + 1) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Aumentar", tint = TextPrimary, modifier = Modifier.size(14.dp))
                            }
                        }

                        if (currentUserRole == "Administrador") {
                            IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Excluir Peça", tint = AccentRed, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PartAddDialog(
    onDismiss: () -> Unit,
    onSave: (String, Int, Double, Double, String, String, Int) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("10") }
    var buyPrice by remember { mutableStateOf("0.0") }
    var sellPrice by remember { mutableStateOf("0.0") }
    var supplier by remember { mutableStateOf("") }
    var barcode by remember { mutableStateOf("") }
    var threshold by remember { mutableStateOf("3") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Adicionar Item ao Estoque", color = NeonGreen, fontWeight = FontWeight.Black) },
        containerColor = DarkSurface,
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        name.trim(),
                        quantity.toIntOrNull() ?: 10,
                        buyPrice.toDoubleOrNull() ?: 0.0,
                        sellPrice.toDoubleOrNull() ?: 0.0,
                        supplier.trim(),
                        barcode.trim(),
                        threshold.toIntOrNull() ?: 3
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                enabled = name.isNotEmpty() && sellPrice.isNotEmpty()
            ) {
                Text("Cadastrar Peça", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar", color = TextSecondary) }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nome da Peça") },
                    colors = dialogTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = quantity,
                        onValueChange = { quantity = it },
                        label = { Text("Quantidade") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = dialogTextFieldColors(),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = threshold,
                        onValueChange = { threshold = it },
                        label = { Text("Alerta Estoque Baixo") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = dialogTextFieldColors(),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = buyPrice,
                        onValueChange = { buyPrice = it },
                        label = { Text("Preço Compra (R$)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        colors = dialogTextFieldColors(),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = sellPrice,
                        onValueChange = { sellPrice = it },
                        label = { Text("Preço Venda (R$)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        colors = dialogTextFieldColors(),
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = supplier,
                    onValueChange = { supplier = it },
                    label = { Text("Fornecedor") },
                    colors = dialogTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = barcode,
                    onValueChange = { barcode = it },
                    label = { Text("Código de Barras") },
                    placeholder = { Text("Ler ou digite o código") },
                    colors = dialogTextFieldColors(),
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        IconButton(onClick = {
                            // auto generate random EAN style barcode
                            barcode = (100000000..999999999).random().toString()
                        }) {
                            Icon(Icons.Default.Autorenew, contentDescription = "Gerar Automático", tint = NeonGreen)
                        }
                    }
                )
            }
        }
    )
}
