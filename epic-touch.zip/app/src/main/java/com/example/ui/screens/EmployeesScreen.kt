package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*

@Composable
fun EmployeesScreen(
    employees: List<Employee>,
    onAddEmployee: (String, String, String, Double) -> Unit,
    onDeleteEmployee: (Employee) -> Unit,
    platformUsers: List<PlatformUser>,
    onAlterUserPlan: (String, String) -> Unit,
    currentUserRole: String,
    modifier: Modifier = Modifier
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var activeTab by remember { mutableStateOf(0) } // 0: Equipe Interna, 1: Assinaturas (Clientes)
    val context = LocalContext.current

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (activeTab == 0) "Funcionários e Técnicos" else "Clientes & Assinaturas",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Black,
                        color = NeonGreen
                    )
                    Text(
                        text = if (activeTab == 0) 
                            "Gestão de equipe e produtividade (Até 30 técnicos)" 
                        else 
                            "Painel administrativo para alteração de planos SaaS",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }

                if (activeTab == 0 && currentUserRole == "Administrador") {
                    Button(
                        onClick = {
                            if (employees.size >= 30) {
                                Toast.makeText(context, "Limite de 30 técnicos atingido no plano atual!", Toast.LENGTH_LONG).show()
                            } else {
                                showAddDialog = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("add_employee_button")
                    ) {
                        Icon(Icons.Default.PersonAddAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Contratar", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            // Custom Tab Selector for Administrators
            if (currentUserRole == "Administrador") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurface, RoundedCornerShape(8.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Button(
                        onClick = { activeTab = 0 },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (activeTab == 0) NeonGreen else Color.Transparent,
                            contentColor = if (activeTab == 0) Color.Black else TextSecondary
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Equipe Interna", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    Button(
                        onClick = { activeTab = 1 },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (activeTab == 1) NeonGreen else Color.Transparent,
                            contentColor = if (activeTab == 1) Color.Black else TextSecondary
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("SaaS Clientes (Planos)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            if (activeTab == 0 || currentUserRole != "Administrador") {
                // Quick Stats Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurface, RoundedCornerShape(8.dp))
                        .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    QuickStatItem(label = "Técnicos Ativos", value = "${employees.count { it.role == "Técnico" }}/30")
                    QuickStatItem(label = "Admin/Outros", value = "${employees.count { it.role != "Técnico" }}")
                    QuickStatItem(label = "Eficiência Média", value = "91.3%")
                }

                // Employees list
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(employees) { emp ->
                        EmployeeItemCard(
                            employee = emp,
                            onDelete = {
                                onDeleteEmployee(emp)
                                Toast.makeText(context, "Funcionário desligado do sistema.", Toast.LENGTH_SHORT).show()
                            },
                            currentUserRole = currentUserRole
                        )
                    }
                }
            } else {
                // SaaS Clientes List (Assinaturas)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurface, RoundedCornerShape(8.dp))
                        .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    QuickStatItem(label = "Clientes Cadastrados", value = "${platformUsers.size}")
                    QuickStatItem(label = "Usuários Pro ⚡", value = "${platformUsers.count { it.plan == "Pro" }}")
                    QuickStatItem(label = "Usuários Básicos", value = "${platformUsers.count { it.plan == "Básico" }}")
                }

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(platformUsers) { user ->
                        PlatformUserItemCard(
                            user = user,
                            onAlterPlan = { login, newPlan ->
                                onAlterUserPlan(login, newPlan)
                                Toast.makeText(context, "Plano de $login alterado para $newPlan!", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }
        }

        // Add Employee Dialog
        if (showAddDialog) {
            EmployeeAddDialog(
                onDismiss = { showAddDialog = false },
                onSave = { n, l, r, comm ->
                    onAddEmployee(n, l, r, comm)
                    showAddDialog = false
                    Toast.makeText(context, "Colaborador cadastrado com sucesso!", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

@Composable
fun PlatformUserItemCard(
    user: PlatformUser,
    onAlterPlan: (String, String) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.dp, DarkBorder),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(NeonGreen.copy(alpha = 0.08f), RoundedCornerShape(20.dp))
                            .border(BorderStroke(1.dp, NeonGreen), RoundedCornerShape(20.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Business,
                            contentDescription = null,
                            tint = NeonGreen,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Column {
                        Text(user.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextPrimary)
                        Text("Login: ${user.login} • Assistência: ${user.assistanceName}", fontSize = 11.sp, color = TextSecondary)
                    }
                }

                // Plan Status Badge
                Box(
                    modifier = Modifier
                        .background(
                            if (user.plan == "Pro") NeonGreen.copy(alpha = 0.1f) else Color.White.copy(alpha = 0.05f),
                            RoundedCornerShape(6.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (user.plan == "Pro") "PRO ⚡" else "BÁSICO",
                        color = if (user.plan == "Pro") NeonGreen else Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Divider(color = DarkBorder)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Controle de Plano do Cliente:",
                    fontSize = 11.sp,
                    color = TextSecondary
                )

                // Alter Plan action buttons
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onAlterPlan(user.login, "Básico") },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (user.plan == "Básico") DarkBorder else Color.Black,
                            contentColor = if (user.plan == "Básico") Color.White else TextSecondary
                        ),
                        border = BorderStroke(1.dp, DarkBorder),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text("Básico", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { onAlterPlan(user.login, "Pro") },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (user.plan == "Pro") NeonGreen.copy(alpha = 0.1f) else Color.Black,
                            contentColor = if (user.plan == "Pro") NeonGreen else TextSecondary
                        ),
                        border = BorderStroke(1.dp, if (user.plan == "Pro") NeonGreen else DarkBorder),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text("Pro ⚡", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun QuickStatItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, fontSize = 9.sp, color = TextSecondary)
        Text(value, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = NeonGreen)
    }
}

@Composable
fun EmployeeItemCard(
    employee: Employee,
    onDelete: () -> Unit,
    currentUserRole: String
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.dp, DarkBorder),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Avatar placeholder
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(NeonGreen.copy(alpha = 0.08f), RoundedCornerShape(20.dp))
                            .border(BorderStroke(1.dp, NeonGreen), RoundedCornerShape(20.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when(employee.role) {
                                "Administrador" -> Icons.Default.AdminPanelSettings
                                "Técnico" -> Icons.Default.Engineering
                                "Atendente" -> Icons.Default.SupportAgent
                                "Caixa" -> Icons.Default.LocalActivity
                                else -> Icons.Default.Person
                            },
                            contentDescription = null,
                            tint = NeonGreen,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Column {
                        Text(employee.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextPrimary)
                        Text("Acesso: ${employee.login} • Cargo: ${employee.role}", fontSize = 11.sp, color = TextSecondary)
                    }
                }

                if (currentUserRole == "Administrador" && employee.login != "dudus") {
                    IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Demitir", tint = AccentRed)
                    }
                }
            }

            Divider(color = DarkBorder)

            // Commissions and Productivity progress bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Comissão Técnica", fontSize = 8.sp, color = TextSecondary)
                    Text(
                        text = if (employee.commissionRate > 0) "${employee.commissionRate}% por OS" else "Salário Fixo",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (employee.commissionRate > 0) NeonGreen else TextPrimary
                    )
                }

                // Productivity progress visual
                Column(horizontalAlignment = Alignment.End, modifier = Modifier.width(130.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Produtividade", fontSize = 8.sp, color = TextSecondary)
                        Text("${employee.productivityScore}%", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = NeonGreen)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { (employee.productivityScore / 100f).toFloat() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp),
                        color = NeonGreen,
                        trackColor = DarkBackground,
                        strokeCap = androidx.compose.ui.graphics.StrokeCap.Round
                    )
                }
            }
        }
    }
}

@Composable
fun EmployeeAddDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, String, Double) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var login by remember { mutableStateOf("") }
    var commission by remember { mutableStateOf("10.0") }
    var role by remember { mutableStateOf("Técnico") }
    var roleExpanded by remember { mutableStateOf(false) }

    val roles = listOf("Administrador", "Técnico", "Atendente", "Caixa")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Contratar Colaborador", color = NeonGreen, fontWeight = FontWeight.Black) },
        containerColor = DarkSurface,
        confirmButton = {
            Button(
                onClick = {
                    onSave(name.trim(), login.trim().lowercase(), role, commission.toDoubleOrNull() ?: 0.0)
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                enabled = name.isNotEmpty() && login.isNotEmpty()
            ) {
                Text("Adicionar", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar", color = TextSecondary) }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nome do Funcionário") },
                    colors = dialogTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = login,
                    onValueChange = { login = it },
                    label = { Text("Nome de Login Único") },
                    colors = dialogTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    // Role Dropdown Selector
                    Box(modifier = Modifier.weight(1f)) {
                        Column {
                            Text("Cargo", fontSize = 10.sp, color = TextSecondary)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .background(DarkBackground, RoundedCornerShape(4.dp))
                                    .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(4.dp))
                                    .clickable { roleExpanded = true }
                                    .padding(horizontal = 12.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text(role, color = TextPrimary, fontSize = 13.sp)
                            }
                        }

                        DropdownMenu(
                            expanded = roleExpanded,
                            onDismissRequest = { roleExpanded = false },
                            modifier = Modifier.background(DarkSurface)
                        ) {
                            roles.forEach { r ->
                                DropdownMenuItem(
                                    text = { Text(r, color = TextPrimary) },
                                    onClick = {
                                        role = r
                                        roleExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Commission Input
                    OutlinedTextField(
                        value = commission,
                        onValueChange = { commission = it },
                        label = { Text("Comissão (%)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        colors = dialogTextFieldColors(),
                        modifier = Modifier.weight(0.8f),
                        enabled = role == "Técnico" || role == "Administrador"
                    )
                }
            }
        }
    )
}
