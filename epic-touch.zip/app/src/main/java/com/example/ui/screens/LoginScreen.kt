package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PlatformUser
import com.example.ui.PixHelper
import com.example.ui.PixQRCodeCanvas
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    onLogin: (String, String) -> Boolean,
    onRegister: (String, String, String, String, String, String) -> Boolean,
    pendingActivationUser: PlatformUser?,
    onActivateUser: (String) -> Unit,
    onCancelActivation: () -> Unit,
    pixKey: String,
    pixMerchantName: String,
    pixMerchantCity: String,
    modifier: Modifier = Modifier
) {
    var isRegistering by remember { mutableStateOf(false) }

    // Login Fields
    var loginInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }

    // Register Fields
    var regLogin by remember { mutableStateOf("") }
    var regName by remember { mutableStateOf("") }
    var regRole by remember { mutableStateOf("Administrador") }
    var regAssistance by remember { mutableStateOf("") }
    var regPassword by remember { mutableStateOf("") }
    var regPlan by remember { mutableStateOf("Básico") }
    
    var roleDropdownExpanded by remember { mutableStateOf(false) }
    var planDropdownExpanded by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // EPIC TOUCH logo
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .background(Color.Black, RoundedCornerShape(16.dp))
                        .border(BorderStroke(2.dp, NeonGreen), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "ET",
                        color = NeonGreen,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = (-1).sp
                    )
                }

                Text(
                    text = "EPIC TOUCH",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 2.sp
                )

                Text(
                    text = "SISTEMA DE GESTÃO PARA ASSISTÊNCIA TÉCNICA",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonGreen,
                    letterSpacing = 1.sp,
                    textAlign = TextAlign.Center
                )
            }

            if (pendingActivationUser != null) {
                // Pending Account Activation Layout (Direct Pix Payment)
                val planPrice = if (pendingActivationUser.plan == "Pro") 49.99 else 19.99
                val pixPayload = remember(pixKey, pixMerchantName, pixMerchantCity, planPrice) {
                    PixHelper.generatePixQrCode(
                        pixKey = pixKey,
                        merchantName = pixMerchantName,
                        merchantCity = pixMerchantCity,
                        amount = planPrice
                    )
                }
                val context = LocalContext.current

                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                    border = BorderStroke(1.5.dp, NeonGreen),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ATIVAR SUA CONTA",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = NeonGreen,
                                letterSpacing = 1.5.sp
                            )
                            IconButton(onClick = onCancelActivation) {
                                Icon(Icons.Default.Close, contentDescription = "Cancelar", tint = TextSecondary)
                            }
                        }

                        Divider(color = DarkBorder)

                        Text(
                            text = "Olá, ${pendingActivationUser.name}!\nSua conta está quase pronta. Ative seu plano para acessar o painel completo.",
                            fontSize = 13.sp,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp
                        )

                        Box(
                            modifier = Modifier
                                .background(NeonGreen.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                                .border(BorderStroke(1.dp, NeonGreen.copy(alpha = 0.2f)), RoundedCornerShape(8.dp))
                                .padding(12.dp)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "PLANO SELECIONADO",
                                    fontSize = 10.sp,
                                    color = TextSecondary,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = if (pendingActivationUser.plan == "Pro") "PLANO PRO ⚡" else "PLANO BÁSICO",
                                    fontSize = 16.sp,
                                    color = NeonGreen,
                                    fontWeight = FontWeight.Black
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (pendingActivationUser.plan == "Pro") "R$ 49,99/mês" else "R$ 19,99/mês",
                                    fontSize = 18.sp,
                                    color = Color.White,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }

                        Text(
                            text = "Efetue o pagamento direto no Pix do administrador:",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )

                        // Beneficiary Details Box
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkBackground, RoundedCornerShape(8.dp))
                                .border(BorderStroke(0.5.dp, DarkBorder), RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Beneficiário:", fontSize = 11.sp, color = TextSecondary)
                                Text(pixMerchantName, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Banco:", fontSize = 11.sp, color = TextSecondary)
                                Text("Clowd Bank", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Chave Pix (Celular):", fontSize = 11.sp, color = TextSecondary)
                                Text(pixKey, fontSize = 11.sp, color = NeonGreen, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Real Dynamic QR Code representation
                        Box(
                            modifier = Modifier
                                .size(140.dp)
                                .background(Color.White, RoundedCornerShape(12.dp))
                                .padding(10.dp)
                                .align(Alignment.CenterHorizontally),
                            contentAlignment = Alignment.Center
                        ) {
                            PixQRCodeCanvas(
                                payload = pixPayload,
                                modifier = Modifier.size(120.dp)
                            )
                        }

                        Text(
                            text = "Código Pix Copia e Cola:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            modifier = Modifier.align(Alignment.Start)
                        )

                        // Copia e Cola Box
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkBackground, RoundedCornerShape(6.dp))
                                .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(6.dp))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = pixPayload,
                                color = NeonGreen,
                                fontSize = 9.sp,
                                maxLines = 2,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = {
                                    val clipboardManager = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                    val clip = android.content.ClipData.newPlainText("Pix Copia e Cola", pixPayload)
                                    clipboardManager.setPrimaryClip(clip)
                                    Toast.makeText(context, "Código Pix copiado!", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DarkSurface, contentColor = Color.White),
                                border = BorderStroke(1.dp, DarkBorder),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1.1f)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Copiar Pix", fontSize = 11.sp)
                            }

                            Button(
                                onClick = {
                                    onActivateUser(pendingActivationUser.login)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1.3f)
                            ) {
                                Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Confirmar e Ativar", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }
            } else {
                // Regular Authentication Form Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                    border = BorderStroke(1.dp, DarkBorder),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = if (isRegistering) "CRIAR NOVA CONTA" else "Acessar o Painel".uppercase(),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            letterSpacing = 1.5.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )

                        if (!isRegistering) {
                            // Username Login
                            OutlinedTextField(
                                value = loginInput,
                                onValueChange = { loginInput = it },
                                label = { Text("Usuário", color = TextSecondary) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonGreen,
                                    unfocusedBorderColor = DarkBorder,
                                    focusedLabelColor = NeonGreen,
                                    unfocusedLabelColor = TextSecondary,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                leadingIcon = {
                                    Icon(Icons.Default.Person, contentDescription = null, tint = NeonGreen)
                                }
                            )

                            // Password Login
                            OutlinedTextField(
                                value = passwordInput,
                                onValueChange = { passwordInput = it },
                                label = { Text("Senha", color = TextSecondary) },
                                visualTransformation = PasswordVisualTransformation(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonGreen,
                                    unfocusedBorderColor = DarkBorder,
                                    focusedLabelColor = NeonGreen,
                                    unfocusedLabelColor = TextSecondary,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                leadingIcon = {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = NeonGreen)
                                }
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Submit Button
                            Button(
                                onClick = {
                                    if (onLogin(loginInput, passwordInput)) {
                                        loginInput = ""
                                        passwordInput = ""
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                            ) {
                                Text("ENTRAR", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            }
                        } else {
                            // Registration mode
                            OutlinedTextField(
                                value = regLogin,
                                onValueChange = { regLogin = it },
                                label = { Text("Nome de Usuário (login)", color = TextSecondary) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonGreen,
                                    unfocusedBorderColor = DarkBorder,
                                    focusedLabelColor = NeonGreen,
                                    unfocusedLabelColor = TextSecondary,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                leadingIcon = {
                                    Icon(Icons.Default.Person, contentDescription = null, tint = NeonGreen)
                                }
                            )

                            OutlinedTextField(
                                value = regName,
                                onValueChange = { regName = it },
                                label = { Text("Seu Nome de Exibição", color = TextSecondary) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonGreen,
                                    unfocusedBorderColor = DarkBorder,
                                    focusedLabelColor = NeonGreen,
                                    unfocusedLabelColor = TextSecondary,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                leadingIcon = {
                                    Icon(Icons.Default.Badge, contentDescription = null, tint = NeonGreen)
                                }
                            )

                            OutlinedTextField(
                                value = regAssistance,
                                onValueChange = { regAssistance = it },
                                label = { Text("Nome da sua Assistência Técnica", color = TextSecondary) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonGreen,
                                    unfocusedBorderColor = DarkBorder,
                                    focusedLabelColor = NeonGreen,
                                    unfocusedLabelColor = TextSecondary,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                leadingIcon = {
                                    Icon(Icons.Default.Storefront, contentDescription = null, tint = NeonGreen)
                                }
                            )

                            // Role Selection Dropdown
                            Box(modifier = Modifier.fillMaxWidth()) {
                                OutlinedTextField(
                                    value = regRole,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Nível de Acesso", color = TextSecondary) },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = NeonGreen,
                                        unfocusedBorderColor = DarkBorder,
                                        focusedLabelColor = NeonGreen,
                                        unfocusedLabelColor = TextSecondary,
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                    leadingIcon = {
                                        Icon(Icons.Default.LockOpen, contentDescription = null, tint = NeonGreen)
                                    },
                                    trailingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.ArrowDropDown,
                                            contentDescription = null,
                                            tint = TextSecondary,
                                            modifier = Modifier.clickable { roleDropdownExpanded = true }
                                        )
                                    }
                                )
                                Box(
                                    modifier = Modifier
                                        .matchParentSize()
                                        .clickable { roleDropdownExpanded = true }
                                )

                                DropdownMenu(
                                    expanded = roleDropdownExpanded,
                                    onDismissRequest = { roleDropdownExpanded = false },
                                    modifier = Modifier.background(DarkSurface)
                                ) {
                                    val roles = listOf("Administrador", "Técnico", "Atendente", "Caixa")
                                    roles.forEach { r ->
                                        DropdownMenuItem(
                                            text = { Text(r, color = Color.White) },
                                            onClick = {
                                                regRole = r
                                                roleDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = regPassword,
                                onValueChange = { regPassword = it },
                                label = { Text("Senha", color = TextSecondary) },
                                visualTransformation = PasswordVisualTransformation(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonGreen,
                                    unfocusedBorderColor = DarkBorder,
                                    focusedLabelColor = NeonGreen,
                                    unfocusedLabelColor = TextSecondary,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                leadingIcon = {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = NeonGreen)
                                }
                            )

                            // Plan Selection Dropdown
                            Box(modifier = Modifier.fillMaxWidth()) {
                                OutlinedTextField(
                                    value = if (regPlan == "Pro") "Plano Pro ⚡" else "Plano Básico",
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Plano de Assinatura", color = TextSecondary) },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = NeonGreen,
                                        unfocusedBorderColor = DarkBorder,
                                        focusedLabelColor = NeonGreen,
                                        unfocusedLabelColor = TextSecondary,
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                    leadingIcon = {
                                        Icon(Icons.Default.CardMembership, contentDescription = null, tint = NeonGreen)
                                    },
                                    trailingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.ArrowDropDown,
                                            contentDescription = null,
                                            tint = TextSecondary,
                                            modifier = Modifier.clickable { planDropdownExpanded = true }
                                        )
                                    }
                                )
                                Box(
                                    modifier = Modifier
                                        .matchParentSize()
                                        .clickable { planDropdownExpanded = true }
                                )

                                DropdownMenu(
                                    expanded = planDropdownExpanded,
                                    onDismissRequest = { planDropdownExpanded = false },
                                    modifier = Modifier.background(DarkSurface)
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("Plano Básico (Recursos essenciais)", color = Color.White) },
                                        onClick = {
                                            regPlan = "Básico"
                                            planDropdownExpanded = false
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Plano Pro ⚡ (Financeiro, Equipe e Laudos)", color = Color.White) },
                                        onClick = {
                                            regPlan = "Pro"
                                            planDropdownExpanded = false
                                        }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Submit Button
                            Button(
                                onClick = {
                                    if (onRegister(regLogin, regName, regRole, regAssistance, regPassword, regPlan)) {
                                        // Reset registration fields and switch back to login
                                        regLogin = ""
                                        regName = ""
                                        regRole = "Administrador"
                                        regAssistance = ""
                                        regPassword = ""
                                        regPlan = "Básico"
                                        isRegistering = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                            ) {
                                Text("CADASTRAR", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            }
                        }
                    }
                }

                // Quick Info & Switch Button
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = if (isRegistering) "Já tem uma conta?" else "Não tem cadastro ainda?",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    Text(
                        text = if (isRegistering) "ACESSAR CONTA" else "CADASTRAR MINHA ASSISTÊNCIA",
                        color = NeonGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp,
                        modifier = Modifier
                            .clickable { isRegistering = !isRegistering }
                            .padding(8.dp)
                    )


                }
            }
        }
    }
}
