package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    currentName: String,
    currentLogin: String,
    currentRole: String,
    assistanceName: String,
    onUpdateProfile: (String, String, String, String) -> Unit,
    onLogout: () -> Unit,
    pixKey: String,
    pixKeyType: String,
    pixMerchantName: String,
    pixMerchantCity: String,
    onUpdatePixConfig: (String, String, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var nameState by remember { mutableStateOf(currentName) }
    var roleState by remember { mutableStateOf(currentRole) }
    var assistanceState by remember { mutableStateOf(assistanceName) }
    var passwordState by remember { mutableStateOf("") }
    
    var roleDropdownExpanded by remember { mutableStateOf(false) }

    var pixKeyInput by remember { mutableStateOf(pixKey) }
    var pixKeyTypeInput by remember { mutableStateOf(pixKeyType) }
    var pixMerchantNameInput by remember { mutableStateOf(pixMerchantName) }
    var pixMerchantCityInput by remember { mutableStateOf(pixMerchantCity) }
    var keyTypeExpanded by remember { mutableStateOf(false) }
    var showQrCodePreview by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(20.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Geometric Profile Card
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            border = BorderStroke(1.dp, DarkBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Neon User Initial Circle
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .background(NeonGreen.copy(alpha = 0.1f), RoundedCornerShape(32.dp))
                        .border(BorderStroke(1.5.dp, NeonGreen), RoundedCornerShape(32.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = currentName.take(2).uppercase(),
                        color = NeonGreen,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Column {
                    Text(
                        text = currentName,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Text(
                        text = "Acesso: @$currentLogin",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .background(NeonGreen.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = currentRole.uppercase(),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonGreen,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }

        // Section header
        Text(
            text = "CONFIGURAÇÕES DA CONTA",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextSecondary,
            letterSpacing = 2.sp
        )

        // Fields Container
        Column(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            // Assistance Name (Critical requirement: "editar o nome assistência técnica dentro do recibo")
            OutlinedTextField(
                value = assistanceState,
                onValueChange = { assistanceState = it },
                label = { Text("Nome da Assistência Técnica", color = TextSecondary) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonGreen,
                    unfocusedBorderColor = DarkBorder,
                    focusedLabelColor = NeonGreen,
                    unfocusedLabelColor = TextSecondary,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = {
                    Icon(Icons.Default.Storefront, contentDescription = null, tint = NeonGreen)
                }
            )

            // User Name
            OutlinedTextField(
                value = nameState,
                onValueChange = { nameState = it },
                label = { Text("Seu Nome / Nome de Exibição", color = TextSecondary) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonGreen,
                    unfocusedBorderColor = DarkBorder,
                    focusedLabelColor = NeonGreen,
                    unfocusedLabelColor = TextSecondary,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = {
                    Icon(Icons.Default.Person, contentDescription = null, tint = NeonGreen)
                }
            )

            // Role selection
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = roleState,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Nível de Acesso", color = TextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGreen,
                        unfocusedBorderColor = DarkBorder,
                        focusedLabelColor = NeonGreen,
                        unfocusedLabelColor = TextSecondary,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth(),
                    leadingIcon = {
                        Icon(Icons.Default.Badge, contentDescription = null, tint = NeonGreen)
                    },
                    trailingIcon = {
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.clickable { roleDropdownExpanded = true }
                        )
                    }
                )
                // Transparent click layer over the textfield
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .clickable { roleDropdownExpanded = true }
                )

                DropdownMenu(
                    expanded = roleDropdownExpanded,
                    onDismissRequest = { roleDropdownExpanded = false },
                    modifier = Modifier.background(DarkSurface)
                ) {
                    val roles = listOf("Administrador", "Técnico", "Atendente", "Caixa")
                    roles.forEach { r ->
                        DropdownMenuItem(
                            text = { Text(r, color = Color.White) },
                            onClick = {
                                roleState = r
                                roleDropdownExpanded = false
                            }
                        )
                    }
                }
            }

            // Change Password
            OutlinedTextField(
                value = passwordState,
                onValueChange = { passwordState = it },
                label = { Text("Alterar Senha (deixe em branco para manter)", color = TextSecondary) },
                visualTransformation = PasswordVisualTransformation(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonGreen,
                    unfocusedBorderColor = DarkBorder,
                    focusedLabelColor = NeonGreen,
                    unfocusedLabelColor = TextSecondary,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = NeonGreen)
                }
            )
        }

        // Section header - Pix Integration
        Text(
            text = "INTEGRAÇÃO DE RECEBIMENTO (PIX)",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextSecondary,
            letterSpacing = 2.sp
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
            border = BorderStroke(1.dp, DarkBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Payments,
                        contentDescription = null,
                        tint = NeonGreen,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "Configuração do Pix",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }

                Text(
                    text = "Defina sua chave Pix para gerar códigos de pagamento Pix Copia e Cola e QR Codes dinâmicos automaticamente para seus clientes no Portal de Rastreamento.",
                    fontSize = 11.sp,
                    color = TextSecondary
                )

                // Select key type dropdown
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = pixKeyTypeInput,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Tipo de Chave", color = TextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonGreen,
                            unfocusedBorderColor = DarkBorder,
                            focusedLabelColor = NeonGreen,
                            unfocusedLabelColor = TextSecondary,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth(),
                        leadingIcon = {
                            Icon(Icons.Default.VpnKey, contentDescription = null, tint = NeonGreen)
                        },
                        trailingIcon = {
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null,
                                tint = TextSecondary,
                                modifier = Modifier.clickable { keyTypeExpanded = true }
                            )
                        }
                    )
                    // Click layer
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .clickable { keyTypeExpanded = true }
                    )

                    DropdownMenu(
                        expanded = keyTypeExpanded,
                        onDismissRequest = { keyTypeExpanded = false },
                        modifier = Modifier.background(DarkSurface)
                    ) {
                        listOf("E-mail", "CPF", "CNPJ", "Celular", "Chave Aleatória").forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type, color = Color.White) },
                                onClick = {
                                    pixKeyTypeInput = type
                                    keyTypeExpanded = false
                                }
                            )
                        }
                    }
                }

                // Pix Key value input
                OutlinedTextField(
                    value = pixKeyInput,
                    onValueChange = { pixKeyInput = it },
                    label = { Text("Sua Chave Pix", color = TextSecondary) },
                    placeholder = {
                        Text(
                            text = when (pixKeyTypeInput) {
                                "E-mail" -> "exemplo@dominio.com"
                                "CPF" -> "123.456.789-00"
                                "CNPJ" -> "12.345.678/0001-99"
                                "Celular" -> "+5511999999999"
                                else -> "12345678-abcd-1234-efgh-1234567890ab"
                            },
                            color = TextSecondary.copy(alpha = 0.5f)
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGreen,
                        unfocusedBorderColor = DarkBorder,
                        focusedLabelColor = NeonGreen,
                        unfocusedLabelColor = TextSecondary,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    leadingIcon = {
                        Icon(Icons.Default.AlternateEmail, contentDescription = null, tint = NeonGreen)
                    }
                )

                // Merchant Name
                OutlinedTextField(
                    value = pixMerchantNameInput,
                    onValueChange = { pixMerchantNameInput = it },
                    label = { Text("Nome do Beneficiário (ex: Nome Fantasia)", color = TextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGreen,
                        unfocusedBorderColor = DarkBorder,
                        focusedLabelColor = NeonGreen,
                        unfocusedLabelColor = TextSecondary,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    leadingIcon = {
                        Icon(Icons.Default.Business, contentDescription = null, tint = NeonGreen)
                    }
                )

                // Merchant City
                OutlinedTextField(
                    value = pixMerchantCityInput,
                    onValueChange = { pixMerchantCityInput = it },
                    label = { Text("Cidade", color = TextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGreen,
                        unfocusedBorderColor = DarkBorder,
                        focusedLabelColor = NeonGreen,
                        unfocusedLabelColor = TextSecondary,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    leadingIcon = {
                        Icon(Icons.Default.LocationCity, contentDescription = null, tint = NeonGreen)
                    }
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = {
                            onUpdatePixConfig(pixKeyInput, pixKeyTypeInput, pixMerchantNameInput, pixMerchantCityInput)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1.2f)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Salvar Pix", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            showQrCodePreview = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurface, contentColor = Color.White),
                        border = BorderStroke(1.dp, DarkBorder),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Testar QR", fontSize = 12.sp)
                    }
                }
            }
        }

        // Real-time QR Code Preview Dialog
        if (showQrCodePreview) {
            val samplePayload = remember(pixKeyInput, pixMerchantNameInput, pixMerchantCityInput) {
                com.example.ui.PixHelper.generatePixQrCode(
                    pixKey = pixKeyInput,
                    merchantName = pixMerchantNameInput,
                    merchantCity = pixMerchantCityInput,
                    amount = 150.00,
                    txid = "TESTE150"
                )
            }

            AlertDialog(
                onDismissRequest = { showQrCodePreview = false },
                containerColor = DarkSurfaceCard,
                titleContentColor = Color.White,
                textContentColor = TextSecondary,
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.QrCode, contentDescription = null, tint = NeonGreen)
                        Text("Visualização em Tempo Real")
                    }
                },
                text = {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Este QR Code simula um pagamento de teste no valor de R$ 150,00 utilizando os dados da sua chave Pix cadastrada acima.",
                            fontSize = 11.sp,
                            color = TextSecondary,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )

                        Box(
                            modifier = Modifier
                                .size(200.dp)
                                .background(DarkBackground, RoundedCornerShape(12.dp))
                                .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            com.example.ui.PixQRCodeCanvas(
                                payload = samplePayload,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkBackground, RoundedCornerShape(6.dp))
                                .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(6.dp))
                                .padding(8.dp)
                        ) {
                            Text("CÓDIGO PIX COPIA E COLA:", fontSize = 8.sp, color = NeonGreen, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = samplePayload,
                                color = Color.White,
                                fontSize = 8.sp,
                                maxLines = 2,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showQrCodePreview = false },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black)
                    ) {
                        Text("Fechar Teste")
                    }
                }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Save Changes Button
        Button(
            onClick = {
                onUpdateProfile(nameState, roleState, assistanceState, passwordState)
                passwordState = "" // Clear password field after saving
            },
            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Icon(Icons.Default.Save, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Salvar Alterações", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }

        // Logout Button
        OutlinedButton(
            onClick = onLogout,
            border = BorderStroke(1.dp, Color(0xFFEF4444)),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Icon(Icons.Default.Logout, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Sair da Conta", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}
