package com.example.ui

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.*

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val database = AppDatabase.getDatabase(application)
    private val repository = AppRepository(database.appDao())

    // --- State Management ---
    private val prefs = application.getSharedPreferences("epic_touc_prefs", android.content.Context.MODE_PRIVATE)

    private val _currentScreen = MutableStateFlow("dashboard")
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    private val _currentUserRole = MutableStateFlow(prefs.getString("current_user_role", "Administrador") ?: "Administrador") // "Administrador", "Técnico", "Atendente", "Caixa"
    val currentUserRole: StateFlow<String> = _currentUserRole.asStateFlow()

    private val _isLoggedIn = MutableStateFlow(prefs.getBoolean("is_logged_in", false))
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _loggedUserName = MutableStateFlow(prefs.getString("logged_user_name", "Administrador") ?: "Administrador")
    val loggedUserName: StateFlow<String> = _loggedUserName.asStateFlow()

    private val _loggedUserLogin = MutableStateFlow(prefs.getString("logged_user_login", "admin") ?: "admin")
    val loggedUserLogin: StateFlow<String> = _loggedUserLogin.asStateFlow()

    private val _technicalAssistanceName = MutableStateFlow(prefs.getString("tech_assistance_name", "EPIC TOUCH") ?: "EPIC TOUCH")
    val technicalAssistanceName: StateFlow<String> = _technicalAssistanceName.asStateFlow()

    private val _loggedUserPlan = MutableStateFlow(prefs.getString("logged_user_plan", "Pro") ?: "Pro") // Default admin to Pro
    val loggedUserPlan: StateFlow<String> = _loggedUserPlan.asStateFlow()

    private val _pixKey = MutableStateFlow(prefs.getString("pix_key", "71982595064") ?: "71982595064")
    val pixKey: StateFlow<String> = _pixKey.asStateFlow()

    private val _pixKeyType = MutableStateFlow(prefs.getString("pix_key_type", "Celular") ?: "Celular")
    val pixKeyType: StateFlow<String> = _pixKeyType.asStateFlow()

    private val _pixMerchantName = MutableStateFlow(prefs.getString("pix_merchant_name", "EDUARDO DOS SANTOS LOPES") ?: "EDUARDO DOS SANTOS LOPES")
    val pixMerchantName: StateFlow<String> = _pixMerchantName.asStateFlow()

    private val _pixMerchantCity = MutableStateFlow(prefs.getString("pix_merchant_city", "SALVADOR") ?: "SALVADOR")
    val pixMerchantCity: StateFlow<String> = _pixMerchantCity.asStateFlow()

    private val _pendingActivationUser = MutableStateFlow<PlatformUser?>(null)
    val pendingActivationUser: StateFlow<PlatformUser?> = _pendingActivationUser.asStateFlow()

    fun clearPendingActivation() {
        _pendingActivationUser.value = null
    }

    fun activateAndLogin(loginVal: String) {
        prefs.edit().putBoolean("user_activated_$loginVal", true).apply()
        val userPlan = prefs.getString("user_plan_$loginVal", "Básico") ?: "Básico"
        val price = if (userPlan == "Pro") 49.99 else 19.99
        _pendingActivationUser.value = null
        
        viewModelScope.launch(Dispatchers.IO) {
            val companyId = Math.abs(loginVal.hashCode() % 10000)
            val format = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
            val todayStr = format.format(java.util.Date())
            val calendar = java.util.Calendar.getInstance()
            calendar.add(java.util.Calendar.MONTH, 1)
            val nextMonthStr = format.format(calendar.time)

            val subscription = Assinatura(
                empresa_id = companyId,
                plano = userPlan,
                valor = price,
                status = "ativa",
                gateway = "PIX_MANUAL",
                gateway_customer_id = "cust_$loginVal",
                gateway_subscription_id = "sub_${System.currentTimeMillis()}",
                inicio = todayStr,
                vencimento = nextMonthStr
            )
            repository.insertAssinatura(subscription)
        }

        Toast.makeText(context, "Sua conta foi ativada com sucesso!", Toast.LENGTH_LONG).show()
    }

    private val _platformUsers = MutableStateFlow<List<PlatformUser>>(emptyList())
    val platformUsers: StateFlow<List<PlatformUser>> = _platformUsers.asStateFlow()

    // Pre-defined users for quick testing
    private val defaultUsers = listOf(
        Triple("admin", "admin", "Administrador" to "EPIC TOUCH"),
        Triple("tecnico", "123", "Técnico" to "EPIC TOUCH - REPAROS"),
        Triple("novo", "senha", "Administrador" to "Minha Assistência")
    )

    init {
        // Ensure registered_logins contains default users
        if (!prefs.contains("registered_logins")) {
            prefs.edit().putString("registered_logins", "admin,tecnico,novo").apply()
        }
        loadPlatformUsers()
    }

    private fun loadPlatformUsers() {
        val loginsStr = prefs.getString("registered_logins", "admin,tecnico,novo") ?: "admin,tecnico,novo"
        val logins = loginsStr.split(",").map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        
        val list = logins.map { login ->
            val defaultUser = defaultUsers.find { it.first.equals(login, ignoreCase = true) }
            val name = defaultUser?.third?.first ?: (prefs.getString("user_name_$login", "Usuário") ?: "Usuário")
            val role = if (defaultUser != null) {
                if (login.equals("tecnico", ignoreCase = true)) "Técnico" else "Administrador"
            } else {
                prefs.getString("user_role_$login", "Administrador") ?: "Administrador"
            }
            val assistance = defaultUser?.third?.second ?: (prefs.getString("user_assistance_$login", "EPIC TOUCH") ?: "EPIC TOUCH")
            
            // admin gets Pro by default, others Básico unless saved
            val plan = if (login.equals("admin", ignoreCase = true)) "Pro" else (prefs.getString("user_plan_$login", "Básico") ?: "Básico")
            
            PlatformUser(login, name, role, assistance, plan)
        }
        _platformUsers.value = list
    }

    fun login(loginVal: String, passwordVal: String): Boolean {
        val trimmedLogin = loginVal.trim()
        val defaultUser = defaultUsers.find { it.first.equals(trimmedLogin, ignoreCase = true) }
        val isValid = if (defaultUser != null) {
            defaultUser.second == passwordVal
        } else {
            val savedPassword = prefs.getString("user_pwd_$trimmedLogin", null)
            savedPassword != null && savedPassword == passwordVal
        }

        if (isValid) {
            val name = defaultUser?.third?.first ?: (prefs.getString("user_name_$trimmedLogin", "Usuário") ?: "Usuário")
            val role = if (defaultUser != null) {
                if (trimmedLogin.equals("tecnico", ignoreCase = true)) "Técnico" else "Administrador"
            } else {
                prefs.getString("user_role_$trimmedLogin", "Administrador") ?: "Administrador"
            }
            val assistance = defaultUser?.third?.second ?: (prefs.getString("user_assistance_$trimmedLogin", "EPIC TOUCH") ?: "EPIC TOUCH")
            val plan = if (trimmedLogin.equals("admin", ignoreCase = true)) "Pro" else (prefs.getString("user_plan_$trimmedLogin", "Básico") ?: "Básico")

            // Activation Check
            val isActivated = if (trimmedLogin.equals("admin", ignoreCase = true) ||
                                 trimmedLogin.equals("tecnico", ignoreCase = true) ||
                                 trimmedLogin.equals("novo", ignoreCase = true)) {
                true
            } else {
                prefs.getBoolean("user_activated_$trimmedLogin", false)
            }

            if (!isActivated) {
                _pendingActivationUser.value = PlatformUser(trimmedLogin, name, role, assistance, plan)
                Toast.makeText(context, "Por favor, ative seu plano para continuar!", Toast.LENGTH_SHORT).show()
                return false
            }

            prefs.edit()
                .putBoolean("is_logged_in", true)
                .putString("logged_user_login", trimmedLogin)
                .putString("logged_user_name", name)
                .putString("current_user_role", role)
                .putString("tech_assistance_name", assistance)
                .putString("logged_user_plan", plan)
                .apply()

            _isLoggedIn.value = true
            _loggedUserLogin.value = trimmedLogin
            _loggedUserName.value = name
            _currentUserRole.value = role
            _technicalAssistanceName.value = assistance
            _loggedUserPlan.value = plan

            loadPlatformUsers()

            _currentScreen.value = "dashboard"
            Toast.makeText(context, "Bem-vindo, $name!", Toast.LENGTH_SHORT).show()
            return true
        } else {
            Toast.makeText(context, "Usuário ou senha incorretos!", Toast.LENGTH_SHORT).show()
            return false
        }
    }

    fun register(loginVal: String, nameVal: String, roleVal: String, assistanceNameVal: String, passwordVal: String, planVal: String): Boolean {
        val trimmedLogin = loginVal.trim()
        val trimmedName = nameVal.trim()
        val trimmedAssistance = assistanceNameVal.trim()
        if (trimmedLogin.isEmpty() || trimmedName.isEmpty() || passwordVal.isEmpty() || trimmedAssistance.isEmpty()) {
            Toast.makeText(context, "Preencha todos os campos!", Toast.LENGTH_SHORT).show()
            return false
        }

        val isDefault = defaultUsers.any { it.first.equals(trimmedLogin, ignoreCase = true) }
        val isSaved = prefs.contains("user_pwd_$trimmedLogin")
        if (isDefault || isSaved) {
            Toast.makeText(context, "Usuário já cadastrado!", Toast.LENGTH_SHORT).show()
            return false
        }

        val loginsStr = prefs.getString("registered_logins", "admin,tecnico,novo") ?: "admin,tecnico,novo"
        val updatedLogins = "$loginsStr,$trimmedLogin"

        prefs.edit()
            .putString("user_pwd_$trimmedLogin", passwordVal)
            .putString("user_name_$trimmedLogin", trimmedName)
            .putString("user_role_$trimmedLogin", roleVal)
            .putString("user_assistance_$trimmedLogin", trimmedAssistance)
            .putString("user_plan_$trimmedLogin", planVal)
            .putBoolean("user_activated_$trimmedLogin", false) // Mark non-activated
            .putString("registered_logins", updatedLogins)
            .apply()

        loadPlatformUsers()

        Toast.makeText(context, "Cadastro realizado com sucesso! Efetue login para ativar sua conta.", Toast.LENGTH_LONG).show()
        return true
    }

    fun updateProfile(nameVal: String, roleVal: String, assistanceNameVal: String, passwordVal: String) {
        val trimmedName = nameVal.trim()
        val trimmedAssistance = assistanceNameVal.trim()
        val loginVal = _loggedUserLogin.value
        
        prefs.edit()
            .putString("logged_user_name", trimmedName)
            .putString("current_user_role", roleVal)
            .putString("tech_assistance_name", trimmedAssistance)
            .apply()

        val defaultUser = defaultUsers.find { it.first.equals(loginVal, ignoreCase = true) }
        if (defaultUser == null) {
            val editor = prefs.edit()
            if (passwordVal.isNotEmpty()) {
                editor.putString("user_pwd_$loginVal", passwordVal)
            }
            editor.putString("user_name_$loginVal", trimmedName)
            editor.putString("user_role_$loginVal", roleVal)
            editor.putString("user_assistance_$loginVal", trimmedAssistance)
            editor.apply()
        } else {
            prefs.edit()
                .putString("user_pwd_$loginVal", if (passwordVal.isNotEmpty()) passwordVal else defaultUser.second)
                .putString("user_name_$loginVal", trimmedName)
                .putString("user_role_$loginVal", roleVal)
                .putString("user_assistance_$loginVal", trimmedAssistance)
                .apply()
        }

        _loggedUserName.value = trimmedName
        _currentUserRole.value = roleVal
        _technicalAssistanceName.value = trimmedAssistance
        
        loadPlatformUsers()
        Toast.makeText(context, "Perfil atualizado com sucesso!", Toast.LENGTH_SHORT).show()
    }

    fun alterUserPlan(userLogin: String, newPlan: String) {
        prefs.edit().putString("user_plan_$userLogin", newPlan).apply()
        
        // If the altered user is the currently logged-in user, update that as well!
        if (userLogin.equals(_loggedUserLogin.value, ignoreCase = true)) {
            prefs.edit().putString("logged_user_plan", newPlan).apply()
            _loggedUserPlan.value = newPlan
        }
        
        loadPlatformUsers()
    }

    fun upgradeToPro() {
        val currentLogin = _loggedUserLogin.value
        prefs.edit()
            .putString("user_plan_$currentLogin", "Pro")
            .putString("logged_user_plan", "Pro")
            .apply()
        _loggedUserPlan.value = "Pro"
        loadPlatformUsers()

        viewModelScope.launch(Dispatchers.IO) {
            val companyId = Math.abs(currentLogin.hashCode() % 10000)
            val format = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault())
            val todayStr = format.format(java.util.Date())
            val calendar = java.util.Calendar.getInstance()
            calendar.add(java.util.Calendar.MONTH, 1)
            val nextMonthStr = format.format(calendar.time)

            val subscription = Assinatura(
                empresa_id = companyId,
                plano = "Pro",
                valor = 49.99,
                status = "ativa",
                gateway = "MERCADO_PAGO_PIX",
                gateway_customer_id = "cust_$currentLogin",
                gateway_subscription_id = "sub_${System.currentTimeMillis()}",
                inicio = todayStr,
                vencimento = nextMonthStr
            )
            repository.insertAssinatura(subscription)
        }
    }

    fun updatePixConfig(key: String, type: String, name: String, city: String) {
        prefs.edit()
            .putString("pix_key", key)
            .putString("pix_key_type", type)
            .putString("pix_merchant_name", name)
            .putString("pix_merchant_city", city)
            .apply()
        _pixKey.value = key
        _pixKeyType.value = type
        _pixMerchantName.value = name
        _pixMerchantCity.value = city
        Toast.makeText(context, "Configuração Pix atualizada com sucesso!", Toast.LENGTH_SHORT).show()
    }

    fun logout() {
        prefs.edit()
            .putBoolean("is_logged_in", false)
            .putString("logged_user_login", "")
            .putString("logged_user_name", "Administrador")
            .putString("current_user_role", "Administrador")
            .putString("tech_assistance_name", "EPIC TOUCH")
            .putString("logged_user_plan", "Básico")
            .apply()

        _isLoggedIn.value = false
        _loggedUserLogin.value = ""
        _loggedUserName.value = "Administrador"
        _currentUserRole.value = "Administrador"
        _technicalAssistanceName.value = "EPIC TOUCH"
        _loggedUserPlan.value = "Básico"
        _currentScreen.value = "dashboard"
        Toast.makeText(context, "Sessão encerrada!", Toast.LENGTH_SHORT).show()
    }

    // --- Database Flows ---
    val customers: StateFlow<List<Customer>> = repository.allCustomers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val devices: StateFlow<List<Device>> = repository.allDevices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val serviceOrders: StateFlow<List<ServiceOrder>> = repository.allServiceOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val inventory: StateFlow<List<InventoryPart>> = repository.allInventory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val employees: StateFlow<List<Employee>> = repository.allEmployees
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactions: StateFlow<List<Transaction>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val assinaturas: StateFlow<List<Assinatura>> = repository.allAssinaturas
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Customer tracking Portal ---
    private val _trackedOrder = MutableStateFlow<ServiceOrder?>(null)
    val trackedOrder: StateFlow<ServiceOrder?> = _trackedOrder.asStateFlow()

    private val _trackingSearchError = MutableStateFlow<String?>(null)
    val trackingSearchError: StateFlow<String?> = _trackingSearchError.asStateFlow()

    init {
        // Pre-populate database with high-quality mock data if empty
        viewModelScope.launch(Dispatchers.IO) {
            customers.first() // wait for first emission
            val currentCustomers = database.appDao().getAllCustomers().first()
            if (currentCustomers.isEmpty()) {
                populateSampleData()
            }
        }
    }

    fun navigateTo(screen: String) {
        _currentScreen.value = screen
    }

    fun setUserRole(role: String) {
        _currentUserRole.value = role
        Toast.makeText(context, "Modo de acesso: $role", Toast.LENGTH_SHORT).show()
    }

    // --- DB Operations ---

    // Customers
    fun addCustomer(name: String, cpf: String, phone: String, whatsapp: String, email: String, address: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val customer = Customer(
                name = name,
                cpf = cpf,
                phone = phone,
                whatsapp = whatsapp,
                email = email,
                address = address,
                history = "Cliente cadastrado em ${getCurrentDateString()}."
            )
            repository.insertCustomer(customer)
        }
    }

    fun updateCustomer(customer: Customer) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateCustomer(customer)
        }
    }

    fun deleteCustomer(customer: Customer) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteCustomer(customer)
        }
    }

    // Devices
    fun addDevice(customerId: Int, brand: String, model: String, imei: String, color: String, passwordKey: String, condition: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val device = Device(
                customerId = customerId,
                brand = brand,
                model = model,
                imei = imei,
                color = color,
                passwordKey = passwordKey,
                condition = condition
            )
            repository.insertDevice(device)
            
            // Append to Customer History
            val customer = repository.getCustomerById(customerId)
            if (customer != null) {
                val updatedHistory = customer.history + "\nAparelho cadastrado: $brand $model (IMEI: $imei) em ${getCurrentDateString()}."
                repository.updateCustomer(customer.copy(history = updatedHistory))
            }
        }
    }

    fun deleteDevice(device: Device) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteDevice(device)
        }
    }

    // Service Orders
    fun createServiceOrder(
        customerId: Int,
        customerName: String,
        customerPhone: String,
        deviceBrand: String,
        deviceModel: String,
        deviceImei: String,
        deviceColor: String,
        devicePasswordKey: String,
        deviceCondition: String,
        defect: String,
        technicianName: String,
        totalValue: Double,
        entryPayment: Double,
        discount: Double,
        warrantyDays: Int
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val randomNum = (1000..9999).random()
            val orderNumber = "OS-${Calendar.getInstance().get(Calendar.YEAR)}-$randomNum"
            
            val order = ServiceOrder(
                orderNumber = orderNumber,
                customerId = customerId,
                customerName = customerName,
                customerPhone = customerPhone,
                deviceBrand = deviceBrand,
                deviceModel = deviceModel,
                deviceImei = deviceImei,
                deviceColor = deviceColor,
                devicePasswordKey = devicePasswordKey,
                deviceCondition = deviceCondition,
                defect = defect,
                technicianName = technicianName,
                totalValue = totalValue,
                entryPayment = entryPayment,
                discount = discount,
                warrantyDays = warrantyDays,
                status = "Recebido"
            )
            repository.insertServiceOrder(order)

            // Add transaction for entry payment if greater than 0
            if (entryPayment > 0.0) {
                val transaction = Transaction(
                    description = "Entrada da $orderNumber - Cliente $customerName",
                    amount = entryPayment,
                    type = "INCOME",
                    isPaid = true,
                    category = "Serviço",
                    referenceId = orderNumber
                )
                repository.insertTransaction(transaction)
            }

            // Append to customer history
            val customer = repository.getCustomerById(customerId)
            if (customer != null) {
                val updatedHistory = customer.history + "\nOrdem de serviço $orderNumber criada em ${getCurrentDateString()} para $deviceBrand $deviceModel. Defeito: $defect."
                repository.updateCustomer(customer.copy(history = updatedHistory))
            }
        }
    }

    fun updateServiceOrderStatus(orderId: Int, newStatus: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val order = repository.getServiceOrderById(orderId)
            if (order != null) {
                val updatedOrder = order.copy(
                    status = newStatus,
                    updatedAt = System.currentTimeMillis()
                )
                repository.updateServiceOrder(updatedOrder)

                // Append status change to customer history
                val customer = repository.getCustomerById(order.customerId)
                if (customer != null) {
                    val updatedHistory = customer.history + "\n$newStatus: OS ${order.orderNumber} atualizada para '$newStatus' em ${getCurrentDateString()}."
                    repository.updateCustomer(customer.copy(history = updatedHistory))
                }

                // If updated to "Finalizado" or "Pronto para retirada", record full pending payment as INCOME
                if (newStatus == "Pronto para retirada") {
                    val remaining = order.totalValue - order.entryPayment - order.discount
                    if (remaining > 0) {
                        val transaction = Transaction(
                            description = "Saldo final da ${order.orderNumber} - $newStatus",
                            amount = remaining,
                            type = "INCOME",
                            isPaid = true,
                            category = "Serviço",
                            referenceId = order.orderNumber
                        )
                        repository.insertTransaction(transaction)
                    }
                }
            }
        }
    }

    fun updateServiceOrderTechnical(
        orderId: Int,
        diagnosis: String,
        report: String,
        partsUsed: String,
        technicianName: String,
        totalValue: Double,
        discount: Double,
        warrantyDays: Int,
        hasSignature: Boolean
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val order = repository.getServiceOrderById(orderId)
            if (order != null) {
                val updatedOrder = order.copy(
                    diagnosis = diagnosis,
                    technicalReport = report,
                    partsUsed = partsUsed,
                    technicianName = technicianName,
                    totalValue = totalValue,
                    discount = discount,
                    warrantyDays = warrantyDays,
                    hasSignature = hasSignature,
                    updatedAt = System.currentTimeMillis()
                )
                repository.updateServiceOrder(updatedOrder)
                
                // Deduct stock if parts were specified and exist
                if (partsUsed.isNotEmpty()) {
                    val partsList = partsUsed.split(",").map { it.trim().lowercase() }
                    val currentStock = repository.allInventory.first()
                    partsList.forEach { partName ->
                        val matchingPart = currentStock.find { it.name.lowercase().contains(partName) || partName.contains(it.name.lowercase()) }
                        if (matchingPart != null && matchingPart.quantity > 0) {
                            repository.updateInventory(matchingPart.copy(quantity = matchingPart.quantity - 1))
                        }
                    }
                }
            }
        }
    }

    fun deleteServiceOrder(order: ServiceOrder) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteServiceOrder(order)
        }
    }

    // Inventory
    fun addInventoryPart(name: String, quantity: Int, purchasePrice: Double, salePrice: Double, supplier: String, barcode: String, lowStockThreshold: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val part = InventoryPart(
                name = name,
                quantity = quantity,
                purchasePrice = purchasePrice,
                salePrice = salePrice,
                supplier = supplier,
                barcode = barcode,
                lowStockThreshold = lowStockThreshold
            )
            repository.insertInventory(part)

            // Register transaction for expense
            val cost = purchasePrice * quantity
            if (cost > 0.0) {
                repository.insertTransaction(
                    Transaction(
                        description = "Compra de estoque: $name (x$quantity)",
                        amount = cost,
                        type = "EXPENSE",
                        isPaid = true,
                        category = "Compra de Peça"
                    )
                )
            }
        }
    }

    fun updateInventoryPart(part: InventoryPart) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateInventory(part)
        }
    }

    fun deleteInventoryPart(part: InventoryPart) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteInventory(part)
        }
    }

    // Employees
    fun addEmployee(name: String, login: String, role: String, commissionRate: Double) {
        viewModelScope.launch(Dispatchers.IO) {
            val emp = Employee(
                name = name,
                login = login,
                role = role,
                commissionRate = commissionRate
            )
            repository.insertEmployee(emp)
        }
    }

    fun deleteEmployee(employee: Employee) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteEmployee(employee)
        }
    }

    // Financial Transactions
    fun addTransaction(description: String, amount: Double, type: String, isPaid: Boolean, category: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val t = Transaction(
                description = description,
                amount = amount,
                type = type,
                isPaid = isPaid,
                category = category
            )
            repository.insertTransaction(t)
        }
    }

    fun toggleTransactionPaid(transaction: Transaction) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateTransaction(transaction.copy(isPaid = !transaction.isPaid))
        }
    }

    fun deleteTransaction(transaction: Transaction) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteTransaction(transaction)
        }
    }

    // Tracking Portal Search
    fun searchTrackedOrder(codeOrPhone: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val cleanInput = codeOrPhone.trim()
            if (cleanInput.isEmpty()) {
                _trackedOrder.value = null
                _trackingSearchError.value = "Digite o código da OS (ex: OS-2026-1001) ou celular."
                return@launch
            }

            val orders = repository.allServiceOrders.first()
            val match = orders.find {
                it.orderNumber.equals(cleanInput, ignoreCase = true) ||
                it.customerPhone.replace("[^0-9]".toRegex(), "").contains(cleanInput.replace("[^0-9]".toRegex(), ""))
            }

            if (match != null) {
                _trackedOrder.value = match
                _trackingSearchError.value = null
            } else {
                _trackedOrder.value = null
                _trackingSearchError.value = "Ordem de serviço ou cliente não encontrado. Verifique os dados."
            }
        }
    }

    fun clearTracking() {
        _trackedOrder.value = null
        _trackingSearchError.value = null
    }

    fun simulateTrackedOrderPayment(orderId: Int, paymentAmount: Double) {
        viewModelScope.launch(Dispatchers.IO) {
            val order = repository.getServiceOrderById(orderId)
            if (order != null) {
                val newStatus = "Finalizado"
                val updatedOrder = order.copy(
                    status = newStatus,
                    entryPayment = order.entryPayment + paymentAmount,
                    updatedAt = System.currentTimeMillis()
                )
                repository.updateServiceOrder(updatedOrder)
                _trackedOrder.value = updatedOrder

                val transaction = Transaction(
                    description = "Pagamento Pix OS ${order.orderNumber} - Cliente ${order.customerName}",
                    amount = paymentAmount,
                    type = "INCOME",
                    isPaid = true,
                    category = "Serviço",
                    referenceId = order.orderNumber
                )
                repository.insertTransaction(transaction)

                val customer = repository.getCustomerById(order.customerId)
                if (customer != null) {
                    val updatedHistory = customer.history + "\nPagamento: OS ${order.orderNumber} paga via Pix no valor de R$ ${String.format(Locale.US, "%.2f", paymentAmount)} em ${getCurrentDateString()}."
                    repository.updateCustomer(customer.copy(history = updatedHistory))
                }
            }
        }
    }

    // --- Helper Utilities ---
    private fun getCurrentDateString(): String {
        val sdf = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        return sdf.format(Date())
    }

    private suspend fun populateSampleData() {
        // 1. Populate Customers
        val c1Id = repository.insertCustomer(Customer(name = "Dudu Santos", cpf = "123.456.789-00", phone = "(11) 99999-8888", whatsapp = "11999998888", email = "dudu@epic.com", address = "Rua das Palmeiras, 123 - Centro", history = "Cadastro inicial feito pelo sistema."))
        val c2Id = repository.insertCustomer(Customer(name = "Mariana Lima", cpf = "987.654.321-11", phone = "(11) 98888-7777", whatsapp = "11988887777", email = "mariana@gmail.com", address = "Av Paulista, 1000 - Bela Vista", history = "Cadastro inicial feito pelo sistema."))
        val c3Id = repository.insertCustomer(Customer(name = "Roberto Carlos", cpf = "456.789.123-22", phone = "(21) 97777-6666", whatsapp = "21977776666", email = "roberto@carlos.com", address = "Av Copacabana, 500 - Rio de Janeiro", history = "Cadastro inicial feito pelo sistema."))
        val c4Id = repository.insertCustomer(Customer(name = "Ana Júlia Santos", cpf = "321.654.987-33", phone = "(31) 96666-5555", whatsapp = "31966665555", email = "anajulia@gmail.com", address = "Rua Savassi, 240 - Belo Horizonte", history = "Cadastro inicial feito pelo sistema."))

        // 2. Populate Devices
        repository.insertDevice(Device(customerId = c1Id.toInt(), brand = "Apple", model = "iPhone 13", imei = "358911002233445", color = "Preto", passwordKey = "Padrão: L", condition = "Tela trincada, marcas de uso nas bordas, sem arranhões traseiros."))
        repository.insertDevice(Device(customerId = c2Id.toInt(), brand = "Samsung", model = "Galaxy S22 Ultra", imei = "359122003344556", color = "Vinho", passwordKey = "Senha: 1234", condition = "Bateria estufada de leve, traseira intacta, conector firme."))
        repository.insertDevice(Device(customerId = c3Id.toInt(), brand = "Xiaomi", model = "Redmi Note 11", imei = "357111004455667", color = "Azul", passwordKey = "Sem senha", condition = "Vidro da câmera traseira estilhaçado, sensores de câmera normais."))
        repository.insertDevice(Device(customerId = c4Id.toInt(), brand = "Motorola", model = "Moto G60", imei = "354122005566778", color = "Cinza", passwordKey = "Padrão: Z", condition = "Não liga. Entrada de conector com oxidação visível."))

        // 3. Populate Inventory Parts
        repository.insertInventory(InventoryPart(name = "Tela iPhone 13", quantity = 4, purchasePrice = 400.0, salePrice = 850.0, supplier = "ImportTech SP", barcode = "789101112", lowStockThreshold = 5)) // low stock warning (4 < 5)
        repository.insertInventory(InventoryPart(name = "Bateria S22 Ultra", quantity = 12, purchasePrice = 120.0, salePrice = 350.0, supplier = "GlobalParts BR", barcode = "789101113", lowStockThreshold = 3))
        repository.insertInventory(InventoryPart(name = "Vidro de Câmera Redmi 11", quantity = 2, purchasePrice = 20.0, salePrice = 120.0, supplier = "ChinaImport", barcode = "789101114", lowStockThreshold = 5)) // low stock warning (2 < 5)
        repository.insertInventory(InventoryPart(name = "PMIC MT6358 Power IC", quantity = 1, purchasePrice = 55.0, salePrice = 180.0, supplier = "ChipMaster", barcode = "789101115", lowStockThreshold = 2)) // low stock warning (1 < 2)
        repository.insertInventory(InventoryPart(name = "Conector Moto G60", quantity = 0, purchasePrice = 15.0, salePrice = 90.0, supplier = "GlobalParts BR", barcode = "789101116", lowStockThreshold = 3)) // Out of stock warning!

        // 4. Populate Employees (Technicians)
        repository.insertEmployee(Employee(name = "Dudus Santos", login = "dudus", role = "Administrador", commissionRate = 15.0, productivityScore = 98.5))
        repository.insertEmployee(Employee(name = "João Técnico", login = "joao", role = "Técnico", commissionRate = 10.0, productivityScore = 85.0))
        repository.insertEmployee(Employee(name = "Carlos Reparo", login = "carlos", role = "Técnico", commissionRate = 12.0, productivityScore = 92.0))
        repository.insertEmployee(Employee(name = "Maria Atendente", login = "maria", role = "Atendente", commissionRate = 0.0, productivityScore = 95.0))

        // 5. Populate Service Orders
        repository.insertServiceOrder(ServiceOrder(
            orderNumber = "OS-2026-0001",
            customerId = c1Id.toInt(),
            customerName = "Dudu Santos",
            customerPhone = "(11) 99999-8888",
            deviceBrand = "Apple",
            deviceModel = "iPhone 13",
            deviceImei = "358911002233445",
            deviceColor = "Preto",
            devicePasswordKey = "Padrão: L",
            deviceCondition = "Tela trincada, marcas de uso",
            defect = "Tela quebrada sem touch",
            diagnosis = "Tela totalmente danificada. Substituição necessária.",
            technicalReport = "Feita a troca do módulo de tela OLED premium por nova tela. Touch e TrueTone restaurados.",
            partsUsed = "Tela iPhone 13",
            technicianName = "Dudus Santos",
            totalValue = 850.0,
            entryPayment = 100.0,
            discount = 50.0,
            warrantyDays = 90,
            hasSignature = true,
            status = "Finalizado",
            createdAt = System.currentTimeMillis() - 10 * 24 * 3600 * 1000L, // 10 days ago
            updatedAt = System.currentTimeMillis() - 9 * 24 * 3600 * 1000L
        ))

        repository.insertServiceOrder(ServiceOrder(
            orderNumber = "OS-2026-0002",
            customerId = c2Id.toInt(),
            customerName = "Mariana Lima",
            customerPhone = "(11) 98888-7777",
            deviceBrand = "Samsung",
            deviceModel = "Galaxy S22 Ultra",
            deviceImei = "359122003344556",
            deviceColor = "Vinho",
            devicePasswordKey = "Senha: 1234",
            deviceCondition = "Traseira intacta, bateria estufada",
            defect = "Bateria estufada e descarregando rápido",
            diagnosis = "Bateria com degradação química severa. Necessária a troca.",
            technicalReport = "Removida bateria antiga com perigo de combustão. Instalada bateria original nova.",
            partsUsed = "Bateria S22 Ultra",
            technicianName = "João Técnico",
            totalValue = 350.0,
            entryPayment = 0.0,
            discount = 0.0,
            warrantyDays = 180,
            hasSignature = true,
            status = "Em reparo",
            createdAt = System.currentTimeMillis() - 3 * 24 * 3600 * 1000L, // 3 days ago
            updatedAt = System.currentTimeMillis() - 2 * 24 * 3600 * 1000L
        ))

        repository.insertServiceOrder(ServiceOrder(
            orderNumber = "OS-2026-0003",
            customerId = c3Id.toInt(),
            customerName = "Roberto Carlos",
            customerPhone = "(21) 97777-6666",
            deviceBrand = "Xiaomi",
            deviceModel = "Redmi Note 11",
            deviceImei = "357111004455667",
            deviceColor = "Azul",
            devicePasswordKey = "Sem senha",
            deviceCondition = "Vidro traseiro quebrado na lente",
            defect = "Vidro da câmera quebrado",
            diagnosis = "Apenas o vidro externo quebrado, lente de foco limpa.",
            partsUsed = "Vidro de Câmera Redmi 11",
            technicianName = "João Técnico",
            totalValue = 120.0,
            entryPayment = 0.0,
            discount = 10.0,
            warrantyDays = 90,
            status = "Aguardando peça",
            createdAt = System.currentTimeMillis() - 1 * 24 * 3600 * 1000L, // 1 day ago
            updatedAt = System.currentTimeMillis()
        ))

        repository.insertServiceOrder(ServiceOrder(
            orderNumber = "OS-2026-0004",
            customerId = c4Id.toInt(),
            customerName = "Ana Júlia Santos",
            customerPhone = "(31) 96666-5555",
            deviceBrand = "Motorola",
            deviceModel = "Moto G60",
            deviceImei = "354122005566778",
            deviceColor = "Cinza",
            devicePasswordKey = "Padrão: Z",
            deviceCondition = "Não liga, oxidação no conector",
            defect = "Aparelho não liga",
            diagnosis = "Curto-circuito na linha principal de energia (PMIC).",
            partsUsed = "PMIC MT6358 Power IC",
            technicianName = "Carlos Reparo",
            totalValue = 420.0,
            entryPayment = 50.0,
            discount = 20.0,
            warrantyDays = 90,
            status = "Testes",
            createdAt = System.currentTimeMillis() - 1 * 3600 * 1000L, // 1 hour ago
            updatedAt = System.currentTimeMillis()
        ))

        // 6. Populate Transactions
        // Income from completed OS
        repository.insertTransaction(Transaction(description = "Entrada da OS-2026-0001", amount = 100.0, type = "INCOME", isPaid = true, category = "Serviço", referenceId = "OS-2026-0001", date = System.currentTimeMillis() - 10 * 24 * 3600 * 1000L))
        repository.insertTransaction(Transaction(description = "Saldo final da OS-2026-0001", amount = 700.0, type = "INCOME", isPaid = true, category = "Serviço", referenceId = "OS-2026-0001", date = System.currentTimeMillis() - 9 * 24 * 3600 * 1000L))
        repository.insertTransaction(Transaction(description = "Entrada da OS-2026-0004", amount = 50.0, type = "INCOME", isPaid = true, category = "Serviço", referenceId = "OS-2026-0004", date = System.currentTimeMillis() - 1 * 3600 * 1000L))

        // Expenses
        repository.insertTransaction(Transaction(description = "Lote de telas iPhone 13 e baterias S22", amount = 1200.0, type = "EXPENSE", isPaid = true, category = "Compra de Peça", date = System.currentTimeMillis() - 15 * 24 * 3600 * 1000L))
        repository.insertTransaction(Transaction(description = "Aluguel da Loja Epic Touch", amount = 800.0, type = "EXPENSE", isPaid = true, category = "Outros", date = System.currentTimeMillis() - 12 * 24 * 3600 * 1000L))
        repository.insertTransaction(Transaction(description = "Internet Fibra Óptica 400MB", amount = 120.0, type = "EXPENSE", isPaid = true, category = "Outros", date = System.currentTimeMillis() - 5 * 24 * 3600 * 1000L))
    }

    // --- Subscriptions (Assinaturas) Operations ---
    fun addAssinatura(empresaId: Int, plano: String, valor: Double, status: String = "teste", gateway: String? = null, gatewayCustomerId: String? = null, gatewaySubscriptionId: String? = null, inicio: String? = null, vencimento: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            val assinatura = Assinatura(
                empresa_id = empresaId,
                plano = plano,
                valor = valor,
                status = status,
                gateway = gateway,
                gateway_customer_id = gatewayCustomerId,
                gateway_subscription_id = gatewaySubscriptionId,
                inicio = inicio,
                vencimento = vencimento
            )
            repository.insertAssinatura(assinatura)
        }
    }

    fun updateAssinatura(assinatura: Assinatura) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateAssinatura(assinatura)
        }
    }

    fun deleteAssinatura(assinatura: Assinatura) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteAssinatura(assinatura)
        }
    }
}
