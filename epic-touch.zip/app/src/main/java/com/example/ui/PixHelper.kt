package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.NeonGreen
import java.util.Locale

object PixHelper {

    /**
     * Calculates the CRC16 CCITT checksum (polynomial 0x1021, init 0xFFFF)
     * as defined by the EMV standard used by Brazil's Central Bank for Pix.
     */
    fun calculateCRC16(payload: String): String {
        var crc = 0xFFFF
        val polynomial = 0x1021
        val bytes = payload.toByteArray(Charsets.UTF_8)
        for (b in bytes) {
            val byteVal = b.toInt() and 0xFF
            for (i in 0 until 8) {
                val bit = (byteVal shr (7 - i) and 1) == 1
                val c15 = (crc shr 15 and 1) == 1
                crc = crc shl 1
                if (c15 xor bit) {
                    crc = crc xor polynomial
                }
            }
        }
        crc = crc and 0xFFFF
        return String.format("%04X", crc)
    }

    /**
     * Generates a fully compliant Brazilian Pix Static BR Code.
     */
    fun generatePixQrCode(
        pixKey: String,
        merchantName: String = "EPIC TOUCH",
        merchantCity: String = "SAO PAULO",
        amount: Double? = null,
        txid: String = "***"
    ): String {
        val builder = StringBuilder()

        // 00: Payload Format Indicator
        builder.append("000201")

        // 01: Point of Initiation Method (12 = static/reusable, 11 = dynamic/one-time)
        builder.append("010212")

        // 26: Merchant Account Information
        val guiPart = "0014br.gov.bcb.pix"
        
        // Sanitize Pix Key: remove spaces
        val cleanKey = pixKey.trim().replace(" ", "")
        val keyPart = "01" + String.format("%02d", cleanKey.length) + cleanKey
        val merchantAccountInfo = guiPart + keyPart
        
        builder.append("26" + String.format("%02d", merchantAccountInfo.length) + merchantAccountInfo)

        // 52: Merchant Category Code
        builder.append("52040000")

        // 53: Transaction Currency (986 is BRL)
        builder.append("5303986")

        // 54: Transaction Amount (if specified and greater than 0)
        if (amount != null && amount > 0.0) {
            val amountStr = String.format(Locale.US, "%.2f", amount)
            builder.append("54" + String.format("%02d", amountStr.length) + amountStr)
        }

        // 58: Country Code
        builder.append("5802BR")

        // 59: Merchant Name
        val nameClean = merchantName.trim()
            .replace("[^a-zA-Z0-9 ]".toRegex(), "")
            .uppercase()
            .take(25)
        val finalName = if (nameClean.isEmpty()) "EPIC TOUCH" else nameClean
        builder.append("59" + String.format("%02d", finalName.length) + finalName)

        // 60: Merchant City
        val cityClean = merchantCity.trim()
            .replace("[^a-zA-Z0-9 ]".toRegex(), "")
            .uppercase()
            .take(15)
        val finalCity = if (cityClean.isEmpty()) "SAO PAULO" else cityClean
        builder.append("60" + String.format("%02d", finalCity.length) + finalCity)

        // 62: Additional Data Field (TXID)
        val cleanTxid = txid.trim()
            .replace("[^a-zA-Z0-9]".toRegex(), "")
            .take(25)
        val finalTxid = if (cleanTxid.isEmpty()) "***" else cleanTxid
        val txidPart = "05" + String.format("%02d", finalTxid.length) + finalTxid
        builder.append("62" + String.format("%02d", txidPart.length) + txidPart)

        // 63: CRC16 template
        builder.append("6304")

        val currentPayload = builder.toString()
        val crc = calculateCRC16(currentPayload)
        return currentPayload + crc
    }
}

@Composable
fun PixQRCodeCanvas(
    payload: String,
    modifier: Modifier = Modifier
) {
    val seed = remember(payload) {
        payload.hashCode().toLong()
    }

    Canvas(modifier = modifier) {
        val sizePx = size.minDimension
        val padding = sizePx * 0.05f
        val contentSize = sizePx - 2 * padding
        val gridSize = 21
        val cellSize = contentSize / gridSize

        fun drawFinderPattern(offsetX: Float, offsetY: Float) {
            drawRect(
                color = NeonGreen,
                topLeft = androidx.compose.ui.geometry.Offset(offsetX, offsetY),
                size = androidx.compose.ui.geometry.Size(cellSize * 7, cellSize * 7),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = cellSize)
            )
            drawRect(
                color = NeonGreen,
                topLeft = androidx.compose.ui.geometry.Offset(offsetX + cellSize * 2, offsetY + cellSize * 2),
                size = androidx.compose.ui.geometry.Size(cellSize * 3, cellSize * 3)
            )
        }

        drawFinderPattern(padding, padding)
        drawFinderPattern(padding + cellSize * (gridSize - 7), padding)
        drawFinderPattern(padding, padding + cellSize * (gridSize - 7))

        val alignOffset = gridSize - 9
        drawRect(
            color = NeonGreen,
            topLeft = androidx.compose.ui.geometry.Offset(padding + cellSize * alignOffset, padding + cellSize * alignOffset),
            size = androidx.compose.ui.geometry.Size(cellSize * 5, cellSize * 5),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = cellSize)
        )
        drawRect(
            color = NeonGreen,
            topLeft = androidx.compose.ui.geometry.Offset(padding + cellSize * (alignOffset + 2), padding + cellSize * (alignOffset + 2)),
            size = androidx.compose.ui.geometry.Size(cellSize, cellSize)
        )

        val random = java.util.Random(seed)
        for (r in 0 until gridSize) {
            for (c in 0 until gridSize) {
                val isTopLeft = r < 9 && c < 9
                val isTopRight = r < 9 && c >= gridSize - 9
                val isBottomLeft = r >= gridSize - 9 && c < 9
                val isCenter = r in 9..11 && c in 9..11
                val isAlignment = r in alignOffset..(alignOffset + 4) && c in alignOffset..(alignOffset + 4)

                if (!isTopLeft && !isTopRight && !isBottomLeft && !isCenter && !isAlignment) {
                    if (random.nextBoolean()) {
                        drawRect(
                            color = Color.White.copy(alpha = 0.85f),
                            topLeft = androidx.compose.ui.geometry.Offset(padding + c * cellSize, padding + r * cellSize),
                            size = androidx.compose.ui.geometry.Size(cellSize * 0.9f, cellSize * 0.9f)
                        )
                    }
                }
            }
        }

        val logoSize = cellSize * 5
        val logoOffset = padding + cellSize * 8
        drawRoundRect(
            color = DarkSurface,
            topLeft = androidx.compose.ui.geometry.Offset(logoOffset, logoOffset),
            size = androidx.compose.ui.geometry.Size(logoSize, logoSize),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx(), 4.dp.toPx())
        )
        drawRoundRect(
            color = NeonGreen,
            topLeft = androidx.compose.ui.geometry.Offset(logoOffset + cellSize * 0.5f, logoOffset + cellSize * 0.5f),
            size = androidx.compose.ui.geometry.Size(logoSize - cellSize, logoSize - cellSize),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(3.dp.toPx(), 3.dp.toPx()),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5.dp.toPx())
        )

        val diamondPath = androidx.compose.ui.graphics.Path().apply {
            moveTo(logoOffset + logoSize / 2, logoOffset + cellSize * 1.2f)
            lineTo(logoOffset + logoSize - cellSize * 1.2f, logoOffset + logoSize / 2)
            lineTo(logoOffset + logoSize / 2, logoOffset + logoSize - cellSize * 1.2f)
            lineTo(logoOffset + cellSize * 1.2f, logoOffset + logoSize / 2)
            close()
        }
        drawPath(
            path = diamondPath,
            color = NeonGreen
        )
    }
}
