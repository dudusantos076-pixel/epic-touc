package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val EpicDarkColorScheme = darkColorScheme(
    primary = NeonGreen,
    onPrimary = Color(0xFF000000),
    primaryContainer = Color(0xFF003311),
    onPrimaryContainer = NeonGreen,
    secondary = AccentBlue,
    onSecondary = Color(0xFF000000),
    tertiary = AccentPurple,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceCard,
    onSurfaceVariant = TextSecondary,
    outline = DarkBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force dark theme for Epic Touch brand!
    dynamicColor: Boolean = false, // Disable dynamic colors to preserve our beautiful Neon Green branding!
    content: @Composable () -> Unit,
) {
    val colorScheme = EpicDarkColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
