package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.*

@Composable
fun DashboardScreen(
    customers: List<Customer>,
    serviceOrders: List<ServiceOrder>,
    transactions: List<Transaction>,
    inventory: List<InventoryPart>,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val currencyFormatter = remember { NumberFormat.getCurrencyInstance(Locale("pt", "BR")) }

    // Computations
    val totalCustomers = customers.size
    val openOS = serviceOrders.count { it.status != "Finalizado" && it.status != "Pronto para retirada" }
    val completedOS = serviceOrders.count { it.status == "Finalizado" || it.status == "Pronto para retirada" }

    // Faturamento do dia, semana e mês (based on TRANSACTION list)
    val now = System.currentTimeMillis()
    val oneDayMs = 24 * 3600 * 1000L
    val oneWeekMs = 7 * oneDayMs
    val oneMonthMs = 30 * oneDayMs

    val todayBilling = transactions
        .filter { it.type == "INCOME" && it.isPaid && (now - it.date) < oneDayMs }
        .sumOf { it.amount }

    val weekBilling = transactions
        .filter { it.type == "INCOME" && it.isPaid && (now - it.date) < oneWeekMs }
        .sumOf { it.amount }

    val monthBilling = transactions
        .filter { it.type == "INCOME" && it.isPaid && (now - it.date) < oneMonthMs }
        .sumOf { it.amount }

    // Stock alert count
    val lowStockCount = inventory.count { it.quantity <= it.lowStockThreshold }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Header (Epic Touch Brand Banner)
        item {
            EpicBanner()
        }

        // Overview Metric Cards
        item {
            Text(
                text = "Indicadores Principais",
                style = MaterialTheme.typography.titleMedium,
                color = NeonGreen,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 4.dp)
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricCard(
                    title = "Total Clientes",
                    value = totalCustomers.toString(),
                    icon = Icons.Default.People,
                    color = NeonGreen,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "OS Abertas",
                    value = openOS.toString(),
                    icon = Icons.Default.Construction,
                    color = AccentOrange,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Concluídos",
                    value = completedOS.toString(),
                    icon = Icons.Default.CheckCircle,
                    color = AccentPurple,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Faturamento Section (Day, Week, Month)
        item {
            Text(
                text = "Faturamento & Caixa",
                style = MaterialTheme.typography.titleMedium,
                color = NeonGreen,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 4.dp)
            )
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                BillingCard(
                    period = "Hoje",
                    amount = currencyFormatter.format(todayBilling),
                    color = NeonGreen,
                    modifier = Modifier.weight(1f)
                )
                BillingCard(
                    period = "Esta Semana",
                    amount = currencyFormatter.format(weekBilling),
                    color = AccentBlue,
                    modifier = Modifier.weight(1f)
                )
                BillingCard(
                    period = "Este Mês",
                    amount = currencyFormatter.format(monthBilling),
                    color = AccentPurple,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Low Stock Alert Banner (Dynamic)
        if (lowStockCount > 0) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2D0808)),
                    border = BorderStroke(1.dp, AccentRed),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigate("estoque") }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Alerta de Estoque Baixo",
                            tint = AccentRed
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Alerta de Estoque Baixo!",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = AccentRed
                            )
                            Text(
                                text = "Você possui $lowStockCount peças com estoque abaixo do limite. Toque para verificar.",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = "Ir para estoque",
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // Desempenho Performance Chart (Drawing with Canvas)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = BorderStroke(1.dp, DarkBorder),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Desempenho da Assistência",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Fluxo de faturamento diário (10 dias)",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.TrendingUp,
                            contentDescription = null,
                            tint = NeonGreen
                        )
                    }

                    // Visual Chart Component using Canvas
                    PerformanceChart(transactions = transactions)
                }
            }
        }

        // Recent Service Orders
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Ordens de Serviço Recentes",
                    style = MaterialTheme.typography.titleMedium,
                    color = NeonGreen,
                    fontWeight = FontWeight.Bold
                )
                TextButton(onClick = { onNavigate("ordens") }) {
                    Text("Ver todas", color = NeonGreen)
                }
            }
        }

        if (serviceOrders.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Nenhuma ordem de serviço registrada.", color = TextSecondary)
                }
            }
        } else {
            items(serviceOrders.take(3)) { order ->
                DashboardOrderRow(order = order, onNavigate = onNavigate)
            }
        }
    }
}

@Composable
fun EpicBanner() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF111111), Color(0xFF000000))
                ),
                shape = RoundedCornerShape(16.dp)
            )
            .border(BorderStroke(1.dp, DarkBorder), shape = RoundedCornerShape(16.dp))
            .padding(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "PAINEL",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonGreen,
                    letterSpacing = 2.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "EPIC TOUCH",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = (-0.5).sp,
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    )
                )
            }
            // Pulse status light + Avatar ET
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color(0xFF1A1A1A), RoundedCornerShape(20.dp))
                        .border(BorderStroke(1.dp, Color(0xFF2E2E36)), RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(NeonGreen, RoundedCornerShape(4.dp))
                    )
                }
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(NeonGreen, RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "ET",
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
        border = BorderStroke(1.dp, DarkBorder),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title.uppercase(),
                    style = MaterialTheme.typography.labelSmall.copy(
                        letterSpacing = 1.sp
                    ),
                    color = TextSecondary,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(14.dp)
                )
            }
            Text(
                text = value,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                color = if (color == AccentRed) AccentRed else if (color == NeonGreen) NeonGreen else Color.White
            )
        }
    }
}

@Composable
fun BillingCard(
    period: String,
    amount: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
        border = BorderStroke(1.dp, DarkBorder),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = period.uppercase(),
                style = MaterialTheme.typography.labelSmall.copy(
                    letterSpacing = 1.sp
                ),
                color = TextSecondary,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = amount,
                fontSize = 16.sp,
                fontWeight = FontWeight.Black,
                color = color,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun PerformanceChart(transactions: List<Transaction>) {
    // Generate simulated 10-day dataset based on transaction values to draw a neat graph
    val incomes = transactions.filter { it.type == "INCOME" && it.isPaid }
    val dataPoints = remember(transactions) {
        val list = mutableListOf<Float>()
        val calendar = Calendar.getInstance()
        for (i in 9 downTo 0) {
            val dayStart = System.currentTimeMillis() - i * 24 * 3600 * 1000L
            val dayIncome = incomes
                .filter { (dayStart - it.date) in 0 until (24 * 3600 * 1000L) }
                .sumOf { it.amount }
                .toFloat()
            // add some base values so the line is always interesting
            list.add(dayIncome + (i * 20f) + 100f) 
        }
        list
    }

    val maxVal = (dataPoints.maxOrNull() ?: 100f).coerceAtLeast(500f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .padding(top = 8.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val spacing = width / (dataPoints.size - 1)

            // Draw grid lines
            for (i in 0..4) {
                val y = height - (height / 4 * i)
                drawLine(
                    color = Color(0xFF111111),
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = 1f
                )
            }

            // Path for gradient area under line
            val areaPath = Path().apply {
                moveTo(0f, height)
            }

            // Path for the neon line itself
            val linePath = Path()

            dataPoints.forEachIndexed { index, value ->
                val x = index * spacing
                val y = height - (value / maxVal * (height * 0.8f))
                
                if (index == 0) {
                    linePath.moveTo(x, y)
                    areaPath.lineTo(x, y)
                } else {
                    linePath.lineTo(x, y)
                    areaPath.lineTo(x, y)
                }
            }

            areaPath.lineTo(width, height)
            areaPath.close()

            // Draw area gradient
            drawPath(
                path = areaPath,
                brush = Brush.verticalGradient(
                    colors = listOf(NeonGreen.copy(alpha = 0.15f), Color.Transparent)
                )
            )

            // Draw Neon line
            drawPath(
                path = linePath,
                color = NeonGreen,
                style = Stroke(width = 3.dp.toPx())
            )

            // Draw points
            dataPoints.forEachIndexed { index, value ->
                val x = index * spacing
                val y = height - (value / maxVal * (height * 0.8f))
                drawCircle(
                    color = Color.Black,
                    radius = 4.dp.toPx(),
                    center = Offset(x, y)
                )
                drawCircle(
                    color = NeonGreen,
                    radius = 2.dp.toPx(),
                    center = Offset(x, y)
                )
            }
        }
    }
}

@Composable
fun DashboardOrderRow(order: ServiceOrder, onNavigate: (String) -> Unit) {
    val statusColor = when (order.status) {
        "Recebido" -> TextSecondary
        "Em análise" -> AccentBlue
        "Aguardando peça" -> AccentOrange
        "Em reparo" -> NeonGreen
        "Testes" -> AccentOrange
        "Finalizado", "Pronto para retirada" -> AccentPurple
        else -> TextPrimary
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
        shape = RoundedCornerShape(topStart = 0.dp, bottomStart = 0.dp, topEnd = 16.dp, bottomEnd = 16.dp),
        border = BorderStroke(1.dp, DarkBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onNavigate("ordens") }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(IntrinsicSize.Min)
        ) {
            // Left stripe with status color
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .fillMaxHeight()
                    .background(statusColor)
            )
            Row(
                modifier = Modifier
                    .weight(1f)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = order.orderNumber,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = NeonGreen
                        )
                        Box(
                            modifier = Modifier
                                .background(statusColor.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                .border(BorderStroke(1.dp, statusColor.copy(alpha = 0.3f)), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = order.status,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = statusColor
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${order.deviceBrand} ${order.deviceModel} • ${order.customerName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "Defeito: ${order.defect}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = NumberFormat.getCurrencyInstance(Locale("pt", "BR")).format(order.totalValue),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Garantia: ${order.warrantyDays}d",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}
