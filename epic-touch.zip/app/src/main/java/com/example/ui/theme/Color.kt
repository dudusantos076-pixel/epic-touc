package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonGreen = Color(0xFF00FF00)
val NeonGreenDim = Color(0xFF009900)
val DarkBackground = Color(0xFF000000)
val DarkSurface = Color(0xFF0A0A0A)
val DarkSurfaceCard = Color(0xFF111111)
val DarkBorder = Color(0xFF1C1C1E)
val TextPrimary = Color(0xFFE2E8F0)
val TextSecondary = Color(0xFF6B7280)
val AccentOrange = Color(0xFFEAB308) // alert / pending (Yellow-500)
val AccentRed = Color(0xFFEF4444) // low stock / delete (Red-500)
val AccentBlue = Color(0xFF3B82F6) // analysis (Blue-500)
val AccentPurple = Color(0xFF8B5CF6) // completed (Purple-500)

