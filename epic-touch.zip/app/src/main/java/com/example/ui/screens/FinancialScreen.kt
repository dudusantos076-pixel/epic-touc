package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*

@Composable
fun FinancialScreen(
    transactions: List<Transaction>,
    onAddTransaction: (String, Double, String, Boolean, String) -> Unit,
    onTogglePaid: (Transaction) -> Unit,
    onDelete: (Transaction) -> Unit,
    currentUserRole: String,
    modifier: Modifier = Modifier
) {
    var filterType by remember { mutableStateOf("Todos") } // "Todos", "INCOME", "EXPENSE"
    var showAddDialog by remember { mutableStateOf(false) }

    val context = LocalContext.current

    // Financial calculations
    val totalInflow = transactions.filter { it.type == "INCOME" && it.isPaid }.sumOf { it.amount }
    val accountsReceivable = transactions.filter { it.type == "INCOME" && !it.isPaid }.sumOf { it.amount }
    val totalOutflow = transactions.filter { it.type == "EXPENSE" && it.isPaid }.sumOf { it.amount }
    val accountsPaid = transactions.filter { it.type == "EXPENSE" && !it.isPaid }.sumOf { it.amount }

    val cashFlow = totalInflow - totalOutflow // Fluxo de Caixa (liquido realizado)
    val profit = (totalInflow + accountsReceivable) - (totalOutflow + accountsPaid) // Lucro estimado total

    val filteredTransactions = transactions.filter {
        filterType == "Todos" || it.type == filterType
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Controle Financeiro",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Black,
                        color = NeonGreen
                    )
                    Text(
                        text = "Fluxo de caixa, receitas, despesas e faturamento",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }

                if (currentUserRole == "Administrador" || currentUserRole == "Caixa") {
                    Button(
                        onClick = { showAddDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("add_transaction_button")
                    ) {
                        Icon(Icons.Default.AddCard, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Novo Lançamento", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            // Summary grid widget
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface, RoundedCornerShape(10.dp))
                    .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(10.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Fluxo de Caixa (Realizado)", fontSize = 9.sp, color = TextSecondary)
                        Text(formatCurrency(cashFlow), fontSize = 18.sp, fontWeight = FontWeight.Black, color = if (cashFlow >= 0) NeonGreen else AccentRed)
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text("Lucro (Estimado)", fontSize = 9.sp, color = TextSecondary)
                        Text(formatCurrency(profit), fontSize = 18.sp, fontWeight = FontWeight.Black, color = if (profit >= 0) AccentBlue else AccentRed)
                    }
                }

                Divider(color = DarkBorder)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Receitas (Faturamento)", fontSize = 9.sp, color = TextSecondary)
                        Text(formatCurrency(totalInflow), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NeonGreen)
                        Text("Receber: ${formatCurrency(accountsReceivable)}", fontSize = 9.sp, color = TextSecondary)
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text("Despesas (Gastos)", fontSize = 9.sp, color = TextSecondary)
                        Text(formatCurrency(totalOutflow), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AccentRed)
                        Text("Pagar: ${formatCurrency(accountsPaid)}", fontSize = 9.sp, color = TextSecondary)
                    }
                }
            }

            // Tabs Filters
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TabFilterButton(label = "Todos", isActive = filterType == "Todos", onClick = { filterType = "Todos" }, modifier = Modifier.weight(1f))
                TabFilterButton(label = "Receitas", isActive = filterType == "INCOME", onClick = { filterType = "INCOME" }, modifier = Modifier.weight(1f))
                TabFilterButton(label = "Despesas", isActive = filterType == "EXPENSE", onClick = { filterType = "EXPENSE" }, modifier = Modifier.weight(1f))
            }

            // Ledger List
            if (filteredTransactions.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Nenhum lançamento financeiro registrado.", color = TextSecondary)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredTransactions) { transaction ->
                        TransactionRow(
                            transaction = transaction,
                            onTogglePaid = {
                                onTogglePaid(transaction)
                                Toast.makeText(context, "Status de pagamento alterado!", Toast.LENGTH_SHORT).show()
                            },
                            onDelete = {
                                onDelete(transaction)
                                Toast.makeText(context, "Lançamento apagado.", Toast.LENGTH_SHORT).show()
                            },
                            currentUserRole = currentUserRole
                        )
                    }
                }
            }
        }

        // Add Transaction Dialog
        if (showAddDialog) {
            TransactionAddDialog(
                onDismiss = { showAddDialog = false },
                onSave = { desc, amt, t, isP, cat ->
                    onAddTransaction(desc, amt, t, isP, cat)
                    showAddDialog = false
                    Toast.makeText(context, "Lançamento registrado!", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

@Composable
fun TabFilterButton(label: String, isActive: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(
                if (isActive) NeonGreen.copy(alpha = 0.15f) else DarkSurface,
                RoundedCornerShape(8.dp)
            )
            .border(
                BorderStroke(
                    1.dp,
                    if (isActive) NeonGreen else DarkBorder
                ),
                RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = if (isActive) NeonGreen else TextPrimary
        )
    }
}

@Composable
fun TransactionRow(
    transaction: Transaction,
    onTogglePaid: () -> Unit,
    onDelete: () -> Unit,
    currentUserRole: String
) {
    val isIncome = transaction.type == "INCOME"
    val color = if (isIncome) NeonGreen else AccentRed

    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.dp, DarkBorder),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                // Indicator circle
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .background(color.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
                        .border(BorderStroke(1.dp, color.copy(alpha = 0.3f)), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isIncome) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(14.dp)
                    )
                }

                Column(modifier = Modifier.widthIn(max = 180.dp)) {
                    Text(
                        text = transaction.description,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "Cat: ${transaction.category} • ${formatDate(transaction.date)}",
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = (if (isIncome) "+" else "-") + formatCurrency(transaction.amount),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = color
                    )

                    // Paid toggler chip
                    Box(
                        modifier = Modifier
                            .background(
                                if (transaction.isPaid) Color(0xFF1B5E20).copy(alpha = 0.1f) else AccentOrange.copy(alpha = 0.1f),
                                RoundedCornerShape(4.dp)
                            )
                            .border(
                                BorderStroke(
                                    1.dp,
                                    if (transaction.isPaid) Color(0xFF1B5E20).copy(alpha = 0.4f) else AccentOrange.copy(alpha = 0.4f)
                                ),
                                RoundedCornerShape(4.dp)
                            )
                            .clickable(enabled = currentUserRole == "Administrador" || currentUserRole == "Caixa") { onTogglePaid() }
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (transaction.isPaid) "PAGO" else "PENDENTE",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (transaction.isPaid) NeonGreen else AccentOrange
                        )
                    }
                }

                if (currentUserRole == "Administrador" && transaction.referenceId == null) {
                    IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Apagar", tint = AccentRed, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun TransactionAddDialog(
    onDismiss: () -> Unit,
    onSave: (String, Double, String, Boolean, String) -> Unit
) {
    var description by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("INCOME") } // "INCOME" or "EXPENSE"
    var category by remember { mutableStateOf("Serviço") }
    var categoryExpanded by remember { mutableStateOf(false) }
    var isPaid by remember { mutableStateOf(true) }

    val categories = listOf("Serviço", "Compra de Peça", "Salário", "Aluguel", "Infraestrutura", "Imposto", "Outros")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Registrar Lançamento Financeiro", color = NeonGreen, fontWeight = FontWeight.Black) },
        containerColor = DarkSurface,
        confirmButton = {
            Button(
                onClick = {
                    onSave(description.trim(), amount.toDoubleOrNull() ?: 0.0, type, isPaid, category)
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                enabled = description.isNotEmpty() && amount.isNotEmpty()
            ) {
                Text("Confirmar", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar", color = TextSecondary) }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Type selector switcher
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkBackground, RoundedCornerShape(8.dp))
                        .padding(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                if (type == "INCOME") NeonGreen else Color.Transparent,
                                RoundedCornerShape(6.dp)
                            )
                            .clickable { type = "INCOME"; category = "Serviço" }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Receita (+)", fontWeight = FontWeight.Bold, color = if (type == "INCOME") Color.Black else TextSecondary, fontSize = 12.sp)
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                if (type == "EXPENSE") AccentRed else Color.Transparent,
                                RoundedCornerShape(6.dp)
                            )
                            .clickable { type = "EXPENSE"; category = "Compra de Peça" }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Despesa (-)", fontWeight = FontWeight.Bold, color = if (type == "EXPENSE") Color.Black else TextSecondary, fontSize = 12.sp)
                    }
                }

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Descrição do Lançamento") },
                    colors = dialogTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("Valor do Lançamento (R$)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    colors = dialogTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                // Category selector
                Box(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Text("Categoria", fontSize = 10.sp, color = TextSecondary)
                        Box(
                            modifier = Modifier
                                        .fillMaxWidth()
                                        .height(56.dp)
                                        .background(DarkBackground, RoundedCornerShape(4.dp))
                                        .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(4.dp))
                                        .clickable { categoryExpanded = true }
                                        .padding(horizontal = 12.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(category, color = TextPrimary, fontSize = 13.sp)
                        }
                    }

                    DropdownMenu(
                        expanded = categoryExpanded,
                        onDismissRequest = { categoryExpanded = false },
                        modifier = Modifier.background(DarkSurface)
                    ) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat, color = TextPrimary) },
                                onClick = {
                                    category = cat
                                    categoryExpanded = false
                                }
                            )
                        }
                    }
                }

                // IsPaid Checkbox
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Checkbox(
                        checked = isPaid,
                        onCheckedChange = { isPaid = it },
                        colors = CheckboxDefaults.colors(checkedColor = NeonGreen, uncheckedColor = TextSecondary)
                    )
                    Text(
                        text = if (isPaid) "Lançamento PAGO / REALIZADO" else "Lançamento PENDENTE / AGENDADO",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPaid) NeonGreen else AccentOrange
                    )
                }
            }
        }
    )
}
