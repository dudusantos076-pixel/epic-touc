package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.theme.*

@Composable
fun CustomersScreen(
    customers: List<Customer>,
    devices: List<Device>,
    onAddCustomer: (String, String, String, String, String, String) -> Unit,
    onAddDevice: (Int, String, String, String, String, String, String) -> Unit,
    onDeleteCustomer: (Customer) -> Unit,
    currentUserRole: String,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var showCreateCustomerDialog by remember { mutableStateOf(false) }
    var selectedCustomerForDeviceReg by remember { mutableStateOf<Customer?>(null) }
    var expandedCustomerId by remember { mutableStateOf<Int?>(null) }

    val context = LocalContext.current

    val filteredCustomers = customers.filter {
        it.name.contains(searchQuery, ignoreCase = true) ||
                it.cpf.contains(searchQuery) ||
                it.phone.contains(searchQuery)
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Clientes & Aparelhos",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Black,
                        color = NeonGreen
                    )
                    Text(
                        text = "Base de dados e histórico de manutenção",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }

                if (currentUserRole != "Técnico") {
                    Button(
                        onClick = { showCreateCustomerDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("add_customer_button")
                    ) {
                        Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Cadastrar", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            // Search bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Buscar cliente por nome, CPF ou celular...", color = TextSecondary, fontSize = 12.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(18.dp)) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonGreen,
                    unfocusedBorderColor = DarkBorder,
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                singleLine = true,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            )

            // Customer List
            if (filteredCustomers.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Nenhum cliente cadastrado ou encontrado.", color = TextSecondary, fontSize = 13.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredCustomers) { customer ->
                        val isExpanded = expandedCustomerId == customer.id
                        val customerDevices = devices.filter { it.customerId == customer.id }

                        CustomerItemRow(
                            customer = customer,
                            devices = customerDevices,
                            isExpanded = isExpanded,
                            onClick = {
                                expandedCustomerId = if (isExpanded) null else customer.id
                            },
                            onRegisterDevice = { selectedCustomerForDeviceReg = customer },
                            onDelete = {
                                onDeleteCustomer(customer)
                                Toast.makeText(context, "Cliente removido.", Toast.LENGTH_SHORT).show()
                            },
                            currentUserRole = currentUserRole
                        )
                    }
                }
            }
        }

        // Create Customer Dialog
        if (showCreateCustomerDialog) {
            CustomerCreateDialog(
                onDismiss = { showCreateCustomerDialog = false },
                onSave = { n, cpf, ph, wa, em, ad ->
                    onAddCustomer(n, cpf, ph, wa, em, ad)
                    showCreateCustomerDialog = false
                    Toast.makeText(context, "Cliente cadastrado com sucesso!", Toast.LENGTH_SHORT).show()
                }
            )
        }

        // Register Device Dialog
        val activeCustomerReg = selectedCustomerForDeviceReg
        if (activeCustomerReg != null) {
            DeviceRegisterDialog(
                customerName = activeCustomerReg.name,
                onDismiss = { selectedCustomerForDeviceReg = null },
                onSave = { b, m, im, col, pass, cond ->
                    onAddDevice(activeCustomerReg.id, b, m, im, col, pass, cond)
                    selectedCustomerForDeviceReg = null
                    Toast.makeText(context, "Aparelho vinculado ao cliente com sucesso!", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

@Composable
fun CustomerItemRow(
    customer: Customer,
    devices: List<Device>,
    isExpanded: Boolean,
    onClick: () -> Unit,
    onRegisterDevice: () -> Unit,
    onDelete: () -> Unit,
    currentUserRole: String
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.dp, if (isExpanded) NeonGreen.copy(alpha = 0.5f) else DarkBorder),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = NeonGreen)
                    Column {
                        Text(
                            text = customer.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "CPF: ${customer.cpf}",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Quick stats pill
                    Box(
                        modifier = Modifier
                            .background(NeonGreen.copy(alpha = 0.08f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${devices.size} Aparelhos",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonGreen
                        )
                    }
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = TextSecondary
                    )
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Divider(color = DarkBorder)

                    // Contact Details
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Contato", fontSize = 9.sp, color = TextSecondary)
                            Text(customer.phone, fontSize = 12.sp, color = TextPrimary)
                            Text("WhatsApp: ${customer.whatsapp}", fontSize = 11.sp, color = NeonGreen)
                            Text(customer.email, fontSize = 11.sp, color = TextPrimary)
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text("Endereço", fontSize = 9.sp, color = TextSecondary)
                            Text(customer.address, fontSize = 12.sp, color = TextPrimary)
                        }
                    }

                    Divider(color = DarkBorder)

                    // Devices list
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Aparelhos Registrados", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NeonGreen)
                            
                            if (currentUserRole != "Técnico") {
                                TextButton(
                                    onClick = onRegisterDevice,
                                    contentPadding = PaddingValues(0.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Icon(Icons.Default.Smartphone, contentDescription = null, modifier = Modifier.size(12.dp), tint = NeonGreen)
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text("Novo Aparelho", fontSize = 10.sp, color = NeonGreen)
                                }
                            }
                        }

                        if (devices.isEmpty()) {
                            Text("Nenhum aparelho vinculado a este cliente.", fontSize = 11.sp, color = TextSecondary)
                        } else {
                            devices.forEach { dev ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(DarkBackground, RoundedCornerShape(6.dp))
                                        .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(6.dp))
                                        .padding(8.dp)
                                ) {
                                    Column {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("${dev.brand} ${dev.model}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                            Text(dev.color, fontSize = 11.sp, color = TextSecondary)
                                        }
                                        Text("IMEI/Serial: ${dev.imei}", fontSize = 10.sp, color = TextSecondary)
                                        if (dev.passwordKey.isNotEmpty()) {
                                            Text("Acesso: ${dev.passwordKey}", fontSize = 10.sp, color = AccentOrange, fontWeight = FontWeight.Bold)
                                        }
                                        Text("Estado de entrada: ${dev.condition}", fontSize = 10.sp, color = TextPrimary)
                                    }
                                }
                            }
                        }
                    }

                    Divider(color = DarkBorder)

                    // History Timeline (Histórico completo)
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Histórico Completo (Notion Style)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NeonGreen)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black, RoundedCornerShape(6.dp))
                                .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(6.dp))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = customer.history,
                                fontSize = 11.sp,
                                color = TextPrimary,
                                lineHeight = 16.sp
                            )
                        }
                    }

                    if (currentUserRole == "Administrador") {
                        Divider(color = DarkBorder)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            Button(
                                onClick = onDelete,
                                colors = ButtonDefaults.buttonColors(containerColor = AccentRed.copy(alpha = 0.1f), contentColor = AccentRed),
                                border = BorderStroke(1.dp, AccentRed.copy(alpha = 0.3f)),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text("Excluir Cliente", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// Dialog for Customer Creation
@Composable
fun CustomerCreateDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var cpf by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var whatsapp by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cadastrar Cliente", color = NeonGreen, fontWeight = FontWeight.Black) },
        containerColor = DarkSurface,
        confirmButton = {
            Button(
                onClick = {
                    onSave(name.trim(), cpf.trim(), phone.trim(), whatsapp.trim(), email.trim(), address.trim())
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                enabled = name.isNotEmpty() && phone.isNotEmpty()
            ) {
                Text("Salvar", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar", color = TextSecondary) }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nome Completo") },
                    colors = dialogTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = cpf,
                    onValueChange = { cpf = it },
                    label = { Text("CPF") },
                    colors = dialogTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Telefone de Contato") },
                    colors = dialogTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = whatsapp,
                    onValueChange = { whatsapp = it },
                    label = { Text("Número WhatsApp") },
                    placeholder = { Text("Ex: 11999998888") },
                    colors = dialogTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("E-mail") },
                    colors = dialogTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Endereço Completo") },
                    colors = dialogTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    )
}

// Dialog for registering device under a customer
@Composable
fun DeviceRegisterDialog(
    customerName: String,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, String, String) -> Unit
) {
    var brand by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var imei by remember { mutableStateOf("") }
    var color by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var condition by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Vincular Aparelho",
                color = NeonGreen,
                fontWeight = FontWeight.Black
            )
        },
        containerColor = DarkSurface,
        confirmButton = {
            Button(
                onClick = {
                    onSave(brand.trim(), model.trim(), imei.trim(), color.trim(), password.trim(), condition.trim())
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                enabled = brand.isNotEmpty() && model.isNotEmpty()
            ) {
                Text("Vincular", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar", color = TextSecondary) }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Cliente: $customerName", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                OutlinedTextField(
                    value = brand,
                    onValueChange = { brand = it },
                    label = { Text("Marca (ex: Apple, Samsung)") },
                    colors = dialogTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = model,
                    onValueChange = { model = it },
                    label = { Text("Modelo (ex: iPhone 13, Moto G30)") },
                    colors = dialogTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = imei,
                    onValueChange = { imei = it },
                    label = { Text("IMEI ou Número de Série") },
                    colors = dialogTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = color,
                    onValueChange = { color = it },
                    label = { Text("Cor do Aparelho") },
                    colors = dialogTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Senha / Padrão de desbloqueio") },
                    colors = dialogTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = condition,
                    onValueChange = { condition = it },
                    label = { Text("Estado de Entrada do Aparelho") },
                    placeholder = { Text("Riscos, película trincada...") },
                    colors = dialogTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    )
}
