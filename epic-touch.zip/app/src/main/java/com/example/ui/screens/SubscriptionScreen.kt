package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Assinatura
import com.example.ui.theme.*
import com.example.ui.PixHelper
import com.example.ui.PixQRCodeCanvas
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscriptionScreen(
    currentPlan: String,
    onUpgradeToPro: () -> Unit,
    blockedFeatureName: String? = null,
    pixKey: String = "71982595064",
    pixKeyType: String = "Celular",
    pixMerchantName: String = "EDUARDO DOS SANTOS LOPES",
    pixMerchantCity: String = "SALVADOR",
    assinaturas: List<Assinatura> = emptyList(),
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    
    var selectedPaymentMethod by remember { mutableStateOf<String?>(null) } // "STRIPE" or "MERCADO_PAGO"
    var isProcessingPayment by remember { mutableStateOf(false) }
    var paymentStep by remember { mutableStateOf(0) } // 0: input, 1: processing, 2: success
    
    // Stripe Inputs
    var cardNumber by remember { mutableStateOf("") }
    var cardExpiry by remember { mutableStateOf("") }
    var cardCvv by remember { mutableStateOf("") }
    var cardHolder by remember { mutableStateOf("") }

    // Scroll state
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(16.dp)
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // If accessed via a blocked Pro feature, show warning banner
        if (blockedFeatureName != null && paymentStep == 0) {
            Card(
                colors = CardDefaults.cardColors(containerColor = AccentRed.copy(alpha = 0.08f)),
                border = BorderStroke(1.dp, AccentRed),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(AccentRed.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = "Bloqueado", tint = AccentRed)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "RECURSO PRO BLOQUEADO",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = AccentRed,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "O recurso '$blockedFeatureName' está disponível exclusivamente para parceiros do Plano Pro.",
                            fontSize = 13.sp,
                            color = TextPrimary
                        )
                    }
                }
            }
        }

        if (paymentStep == 2) {
            // Success Celebration State
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(96.dp)
                        .background(NeonGreen.copy(alpha = 0.1f), CircleShape)
                        .border(BorderStroke(2.dp, NeonGreen), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Sucesso",
                        tint = NeonGreen,
                        modifier = Modifier.size(48.dp)
                    )
                }

                Text(
                    text = "UPGRADE CONCLUÍDO COM SUCESSO!",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = NeonGreen,
                    letterSpacing = 1.sp,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "Seja bem-vindo ao EPIC TOUCH PRO!\nTodas as funcionalidades premium (Financeiro, Equipe, Laudos e muito mais) foram liberadas para você.",
                    fontSize = 14.sp,
                    color = TextPrimary,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                Button(
                    onClick = {
                        onUpgradeToPro()
                        paymentStep = 0
                        selectedPaymentMethod = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text("ACESSAR FUNCIONALIDADES PRO", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
            }
        } else if (isProcessingPayment) {
            // Processing Payment Loader
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 48.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                CircularProgressIndicator(
                    color = NeonGreen,
                    modifier = Modifier.size(64.dp)
                )

                Text(
                    text = "PROCESSANDO TRANSAÇÃO...",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonGreen,
                    letterSpacing = 2.sp
                )

                Text(
                    text = if (selectedPaymentMethod == "STRIPE") 
                        "Comunicando com servidores seguros do Stripe API..." 
                    else 
                        "Iniciando integração Pix com o Mercado Pago...",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
            }
        } else if (selectedPaymentMethod != null) {
            // Interactive Payment Form (Stripe/Mercado Pago)
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                border = BorderStroke(1.dp, DarkBorder),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (selectedPaymentMethod == "STRIPE") "PAGAMENTO STRIPE" else "PIX MERCADO PAGO",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonGreen,
                            letterSpacing = 1.5.sp
                        )
                        IconButton(onClick = { selectedPaymentMethod = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Voltar", tint = TextSecondary)
                        }
                    }

                    Divider(color = DarkBorder)

                    if (selectedPaymentMethod == "STRIPE") {
                        // Stripe Card UI
                        Text(
                            text = "Insira os dados do seu cartão de crédito:",
                            fontSize = 13.sp,
                            color = TextSecondary
                        )

                        OutlinedTextField(
                            value = cardHolder,
                            onValueChange = { cardHolder = it },
                            label = { Text("Nome do Titular (como no cartão)") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonGreen,
                                unfocusedBorderColor = DarkBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = NeonGreen) }
                        )

                        OutlinedTextField(
                            value = cardNumber,
                            onValueChange = { cardNumber = it.take(16) },
                            label = { Text("Número do Cartão") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonGreen,
                                unfocusedBorderColor = DarkBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            leadingIcon = { Icon(Icons.Default.CreditCard, contentDescription = null, tint = NeonGreen) }
                        )

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = cardExpiry,
                                onValueChange = { cardExpiry = it.take(5) },
                                label = { Text("Validade (MM/AA)") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonGreen,
                                    unfocusedBorderColor = DarkBorder,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                placeholder = { Text("12/29") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = cardCvv,
                                onValueChange = { cardCvv = it.take(4) },
                                label = { Text("CVV") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonGreen,
                                    unfocusedBorderColor = DarkBorder,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                ),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }

                        Button(
                            onClick = {
                                if (cardHolder.isEmpty() || cardNumber.length < 12 || cardExpiry.isEmpty() || cardCvv.length < 3) {
                                    Toast.makeText(context, "Por favor, preencha todos os campos do cartão!", Toast.LENGTH_SHORT).show()
                                } else {
                                    coroutineScope.launch {
                                        isProcessingPayment = true
                                        delay(2000) // Simulate server communication
                                        isProcessingPayment = false
                                        paymentStep = 2 // success
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Text("SIMULAR PAGAMENTO COM STRIPE", fontWeight = FontWeight.Bold)
                        }

                    } else {
                        // Dynamic Pix Payload Generation for Upgrades (Pro Plan = R$ 49.99)
                        val pixPayload = remember(pixKey, pixMerchantName, pixMerchantCity) {
                            PixHelper.generatePixQrCode(
                                pixKey = pixKey,
                                merchantName = pixMerchantName,
                                merchantCity = pixMerchantCity,
                                amount = 49.99
                            )
                        }

                        // Mercado Pago Pix UI
                        Text(
                            text = "Pague via Pix instantâneo para ativação imediata:",
                            fontSize = 13.sp,
                            color = TextSecondary
                        )

                        // Centered mock QR Code Box
                        Box(
                            modifier = Modifier
                                .size(140.dp)
                                .background(Color.White, RoundedCornerShape(8.dp))
                                .padding(8.dp)
                                .align(Alignment.CenterHorizontally),
                            contentAlignment = Alignment.Center
                        ) {
                            PixQRCodeCanvas(
                                payload = pixPayload,
                                modifier = Modifier.size(124.dp)
                            )
                        }

                        // Beneficiary Details Box
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkBackground, RoundedCornerShape(8.dp))
                                .border(BorderStroke(0.5.dp, DarkBorder), RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Beneficiário:", fontSize = 11.sp, color = TextSecondary)
                                Text(pixMerchantName, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Banco:", fontSize = 11.sp, color = TextSecondary)
                                Text("Clowd Bank", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Chave Pix (Celular):", fontSize = 11.sp, color = TextSecondary)
                                Text(pixKey, fontSize = 11.sp, color = NeonGreen, fontWeight = FontWeight.Bold)
                            }
                        }

                        Text(
                            text = "Código Pix Copia e Cola:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            modifier = Modifier.align(Alignment.Start)
                        )

                        // Copia e Cola Code
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkBackground, RoundedCornerShape(6.dp))
                                .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(6.dp))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = pixPayload,
                                color = NeonGreen,
                                fontSize = 9.sp,
                                maxLines = 2,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = {
                                    val clipboardManager = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                    val clip = android.content.ClipData.newPlainText("Pix Copia e Cola", pixPayload)
                                    clipboardManager.setPrimaryClip(clip)
                                    Toast.makeText(context, "Código Pix copiado!", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DarkSurface, contentColor = Color.White),
                                border = BorderStroke(1.dp, DarkBorder),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Copiar Código", fontSize = 11.sp)
                            }

                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        isProcessingPayment = true
                                        delay(2200) // Simulate Pix check
                                        isProcessingPayment = false
                                        paymentStep = 2 // success
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = Color.Black),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1.2f)
                            ) {
                                Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Confirmar Pago", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        } else {
            // Plan Presentation Cards
            Text(
                text = "ESCOLHA O PLANO PERFEITO",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                letterSpacing = 2.sp
            )

            // Dynamic plan status display
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurfaceCard, RoundedCornerShape(12.dp))
                    .border(BorderStroke(1.dp, DarkBorder), RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("SEU PLANO ATUAL", fontSize = 10.sp, color = TextSecondary, fontWeight = FontWeight.Bold)
                        Text(
                            text = if (currentPlan == "Pro") "Plano Pro Ativo ⚡" else "Plano Básico",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = if (currentPlan == "Pro") NeonGreen else Color.White
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(
                                if (currentPlan == "Pro") NeonGreen.copy(alpha = 0.1f) else Color.White.copy(alpha = 0.05f),
                                RoundedCornerShape(6.dp)
                            )
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = currentPlan.uppercase(),
                            color = if (currentPlan == "Pro") NeonGreen else Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Plan 1: Básico Card
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = BorderStroke(1.dp, if (currentPlan == "Básico") NeonGreen.copy(alpha = 0.3f) else DarkBorder),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("PLANO BÁSICO", fontSize = 16.sp, fontWeight = FontWeight.Black, color = Color.White)
                            Text("Para assistências iniciando", fontSize = 11.sp, color = TextSecondary)
                        }
                        Text("R$ 19,99", fontSize = 20.sp, fontWeight = FontWeight.Black, color = TextPrimary)
                    }

                    Divider(color = DarkBorder)

                    // Basic features
                    FeatureRow(text = "Dashboard Principal", enabled = true)
                    FeatureRow(text = "Ordens de Serviço Completas", enabled = true)
                    FeatureRow(text = "Clientes & Aparelhos", enabled = true)
                    FeatureRow(text = "Controle de Estoque (Peças)", enabled = true)
                    FeatureRow(text = "Acompanhamento de OS do Cliente", enabled = true)
                    FeatureRow(text = "Controle Financeiro Avançado", enabled = false)
                    FeatureRow(text = "Gestão de Equipe & Produtividade", enabled = false)
                    FeatureRow(text = "Laudos Técnicos Automatizados", enabled = false)
                }
            }

            // Plan 2: Pro Card (Epic / Cyberpunk Highlighted)
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                border = BorderStroke(1.5.dp, if (currentPlan == "Pro") NeonGreen else NeonGreen.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("PLANO PRO", fontSize = 18.sp, fontWeight = FontWeight.Black, color = NeonGreen)
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .background(NeonGreen, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Text("EPIC", color = Color.Black, fontSize = 8.sp, fontWeight = FontWeight.Black)
                                }
                            }
                            Text("Aceleração máxima para sua assistência", fontSize = 11.sp, color = TextSecondary)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("R$ 49,99", fontSize = 22.sp, fontWeight = FontWeight.Black, color = NeonGreen)
                            Text("/mês", fontSize = 9.sp, color = TextSecondary)
                        }
                    }

                    Divider(color = DarkBorder)

                    // Pro Features list
                    FeatureRow(text = "Todos os recursos do Plano Básico", enabled = true, highlights = true)
                    FeatureRow(text = "Controle Financeiro Avançado (Fluxo de caixa)", enabled = true, highlights = true)
                    FeatureRow(text = "Gestão de Equipe, Produtividade & Comissões", enabled = true, highlights = true)
                    FeatureRow(text = "Laudos Técnicos Automatizados (Oxidação/Garantia)", enabled = true, highlights = true)
                    FeatureRow(text = "Leitura física instantânea de código de barras", enabled = true, highlights = true)
                    FeatureRow(text = "Suporte prioritário 24/7", enabled = true, highlights = true)

                    Spacer(modifier = Modifier.height(8.dp))

                    if (currentPlan == "Básico") {
                        // Payment options header
                        Text(
                            text = "Escolha a forma de pagamento seguro:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            letterSpacing = 1.sp,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            // Stripe selector button
                            Button(
                                onClick = { selectedPaymentMethod = "STRIPE" },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF635BFF), contentColor = Color.White),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                            ) {
                                Icon(Icons.Default.CreditCard, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Stripe", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }

                            // Mercado Pago selector button
                            Button(
                                onClick = { selectedPaymentMethod = "MERCADO_PAGO" },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF009EE3), contentColor = Color.White),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                            ) {
                                Icon(Icons.Default.Pix, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Mercado Pago", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    } else {
                        Button(
                            onClick = {},
                            enabled = false,
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen.copy(alpha = 0.2f), contentColor = Color.White),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = NeonGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("VOCÊ JÁ É PRO", fontWeight = FontWeight.Bold, color = NeonGreen)
                        }
                    }
                }
            }

            if (assinaturas.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(DarkBorder))
                Spacer(modifier = Modifier.height(12.dp))
                
                Text(
                    text = "HISTÓRICO DE ASSINATURAS (DATABASE)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    color = NeonGreen,
                    letterSpacing = 1.5.sp,
                    modifier = Modifier.align(Alignment.Start)
                )
                
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    assinaturas.forEach { ass ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DarkSurface),
                            border = BorderStroke(1.dp, DarkBorder),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "PLANO ${ass.plano.uppercase()}",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (ass.plano.equals("Pro", ignoreCase = true)) NeonGreen else Color.White
                                    )
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                when (ass.status.lowercase()) {
                                                    "ativa" -> NeonGreen.copy(alpha = 0.15f)
                                                    "cancelada" -> AccentRed.copy(alpha = 0.15f)
                                                    else -> TextSecondary.copy(alpha = 0.15f)
                                                },
                                                RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = ass.status.uppercase(),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = when (ass.status.lowercase()) {
                                                "ativa" -> NeonGreen
                                                "cancelada" -> AccentRed
                                                else -> TextSecondary
                                            }
                                        )
                                    }
                                }
                                
                                Spacer(modifier = Modifier.height(4.dp))
                                
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Empresa ID: ${ass.empresa_id}",
                                        fontSize = 11.sp,
                                        color = TextSecondary
                                    )
                                    Text(
                                        text = "R$ ${String.format(java.util.Locale.US, "%.2f", ass.valor)}",
                                        fontSize = 12.sp,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                
                                if (ass.inicio != null && ass.vencimento != null) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Vigência: ${ass.inicio} a ${ass.vencimento}",
                                        fontSize = 10.sp,
                                        color = TextSecondary
                                    )
                                }
                                
                                if (ass.gateway != null) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Gateway: ${ass.gateway} (${ass.gateway_subscription_id ?: ""})",
                                        fontSize = 9.sp,
                                        color = TextSecondary.copy(alpha = 0.7f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FeatureRow(text: String, enabled: Boolean, highlights: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (enabled) Icons.Default.Check else Icons.Default.Close,
            contentDescription = null,
            tint = if (enabled) (if (highlights) NeonGreen else Color.White) else AccentRed,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = text,
            fontSize = 12.sp,
            color = if (enabled) (if (highlights) Color.White else TextPrimary) else TextSecondary,
            textDecoration = if (enabled) TextDecoration.None else TextDecoration.LineThrough,
            fontWeight = if (highlights && enabled) FontWeight.Bold else FontWeight.Normal
        )
    }
}
