package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {

    // --- Customers ---
    @Query("SELECT * FROM customers ORDER BY name ASC")
    fun getAllCustomers(): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun getCustomerById(id: Int): Customer?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: Customer): Long

    @Update
    suspend fun updateCustomer(customer: Customer)

    @Delete
    suspend fun deleteCustomer(customer: Customer)


    // --- Devices ---
    @Query("SELECT * FROM devices ORDER BY model ASC")
    fun getAllDevices(): Flow<List<Device>>

    @Query("SELECT * FROM devices WHERE customerId = :customerId")
    fun getDevicesForCustomer(customerId: Int): Flow<List<Device>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDevice(device: Device): Long

    @Update
    suspend fun updateDevice(device: Device)

    @Delete
    suspend fun deleteDevice(device: Device)


    // --- Service Orders ---
    @Query("SELECT * FROM service_orders ORDER BY createdAt DESC")
    fun getAllServiceOrders(): Flow<List<ServiceOrder>>

    @Query("SELECT * FROM service_orders WHERE id = :id")
    suspend fun getServiceOrderById(id: Int): ServiceOrder?

    @Query("SELECT * FROM service_orders WHERE orderNumber = :orderNumber")
    suspend fun getServiceOrderByNumber(orderNumber: String): ServiceOrder?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertServiceOrder(serviceOrder: ServiceOrder): Long

    @Update
    suspend fun updateServiceOrder(serviceOrder: ServiceOrder)

    @Delete
    suspend fun deleteServiceOrder(serviceOrder: ServiceOrder)


    // --- Inventory ---
    @Query("SELECT * FROM inventory ORDER BY name ASC")
    fun getAllInventory(): Flow<List<InventoryPart>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventory(part: InventoryPart): Long

    @Update
    suspend fun updateInventory(part: InventoryPart)

    @Delete
    suspend fun deleteInventory(part: InventoryPart)


    // --- Employees ---
    @Query("SELECT * FROM employees ORDER BY name ASC")
    fun getAllEmployees(): Flow<List<Employee>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEmployee(employee: Employee): Long

    @Update
    suspend fun updateEmployee(employee: Employee)

    @Delete
    suspend fun deleteEmployee(employee: Employee)


    // --- Transactions (Finance) ---
    @Query("SELECT * FROM transactions ORDER BY date DESC")
    fun getAllTransactions(): Flow<List<Transaction>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: Transaction): Long

    @Update
    suspend fun updateTransaction(transaction: Transaction)

    @Delete
    suspend fun deleteTransaction(transaction: Transaction)

    // --- Subscriptions (Assinaturas) ---
    @Query("SELECT * FROM assinaturas ORDER BY created_at DESC")
    fun getAllAssinaturas(): Flow<List<Assinatura>>

    @Query("SELECT * FROM assinaturas WHERE empresa_id = :empresaId ORDER BY created_at DESC")
    fun getAssinaturasForEmpresa(empresaId: Int): Flow<List<Assinatura>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAssinatura(assinatura: Assinatura): Long

    @Update
    suspend fun updateAssinatura(assinatura: Assinatura)

    @Delete
    suspend fun deleteAssinatura(assinatura: Assinatura)
}
