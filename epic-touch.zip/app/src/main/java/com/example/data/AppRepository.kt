package com.example.data

import kotlinx.coroutines.flow.Flow

class AppRepository(private val appDao: AppDao) {

    // --- Customers ---
    val allCustomers: Flow<List<Customer>> = appDao.getAllCustomers()

    suspend fun getCustomerById(id: Int): Customer? = appDao.getCustomerById(id)

    suspend fun insertCustomer(customer: Customer): Long = appDao.insertCustomer(customer)

    suspend fun updateCustomer(customer: Customer) = appDao.updateCustomer(customer)

    suspend fun deleteCustomer(customer: Customer) = appDao.deleteCustomer(customer)


    // --- Devices ---
    val allDevices: Flow<List<Device>> = appDao.getAllDevices()

    fun getDevicesForCustomer(customerId: Int): Flow<List<Device>> = appDao.getDevicesForCustomer(customerId)

    suspend fun insertDevice(device: Device): Long = appDao.insertDevice(device)

    suspend fun updateDevice(device: Device) = appDao.updateDevice(device)

    suspend fun deleteDevice(device: Device) = appDao.deleteDevice(device)


    // --- Service Orders ---
    val allServiceOrders: Flow<List<ServiceOrder>> = appDao.getAllServiceOrders()

    suspend fun getServiceOrderById(id: Int): ServiceOrder? = appDao.getServiceOrderById(id)

    suspend fun getServiceOrderByNumber(orderNumber: String): ServiceOrder? = appDao.getServiceOrderByNumber(orderNumber)

    suspend fun insertServiceOrder(serviceOrder: ServiceOrder): Long = appDao.insertServiceOrder(serviceOrder)

    suspend fun updateServiceOrder(serviceOrder: ServiceOrder) = appDao.updateServiceOrder(serviceOrder)

    suspend fun deleteServiceOrder(serviceOrder: ServiceOrder) = appDao.deleteServiceOrder(serviceOrder)


    // --- Inventory ---
    val allInventory: Flow<List<InventoryPart>> = appDao.getAllInventory()

    suspend fun insertInventory(part: InventoryPart): Long = appDao.insertInventory(part)

    suspend fun updateInventory(part: InventoryPart) = appDao.updateInventory(part)

    suspend fun deleteInventory(part: InventoryPart) = appDao.deleteInventory(part)


    // --- Employees ---
    val allEmployees: Flow<List<Employee>> = appDao.getAllEmployees()

    suspend fun insertEmployee(employee: Employee): Long = appDao.insertEmployee(employee)

    suspend fun updateEmployee(employee: Employee) = appDao.updateEmployee(employee)

    suspend fun deleteEmployee(employee: Employee) = appDao.deleteEmployee(employee)


    // --- Transactions ---
    val allTransactions: Flow<List<Transaction>> = appDao.getAllTransactions()

    suspend fun insertTransaction(transaction: Transaction): Long = appDao.insertTransaction(transaction)

    suspend fun updateTransaction(transaction: Transaction) = appDao.updateTransaction(transaction)

    suspend fun deleteTransaction(transaction: Transaction) = appDao.deleteTransaction(transaction)

    // --- Subscriptions (Assinaturas) ---
    val allAssinaturas: Flow<List<Assinatura>> = appDao.getAllAssinaturas()

    fun getAssinaturasForEmpresa(empresaId: Int): Flow<List<Assinatura>> = appDao.getAssinaturasForEmpresa(empresaId)

    suspend fun insertAssinatura(assinatura: Assinatura): Long = appDao.insertAssinatura(assinatura)

    suspend fun updateAssinatura(assinatura: Assinatura) = appDao.updateAssinatura(assinatura)

    suspend fun deleteAssinatura(assinatura: Assinatura) = appDao.deleteAssinatura(assinatura)
}
