package com.example.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object SupabaseManager {
    private const val TAG = "SupabaseManager"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    // Retrieve saved configurations (fallback to BuildConfig if empty)
    fun getSavedUrl(context: Context): String {
        val prefs = context.getSharedPreferences("supabase_prefs", Context.MODE_PRIVATE)
        val saved = prefs.getString("supabase_url", "") ?: ""
        if (saved.isNotEmpty()) return saved
        // Return BuildConfig if available and is not the placeholder
        val buildConfigVal = com.example.BuildConfig.SUPABASE_URL
        return if (buildConfigVal.contains("your-project-ref") || buildConfigVal.contains("supabase.co") && buildConfigVal.startsWith("https://your-")) "" else buildConfigVal
    }

    fun getSavedAnonKey(context: Context): String {
        val prefs = context.getSharedPreferences("supabase_prefs", Context.MODE_PRIVATE)
        val saved = prefs.getString("supabase_anon_key", "") ?: ""
        if (saved.isNotEmpty()) return saved
        val buildConfigVal = com.example.BuildConfig.SUPABASE_ANON_KEY
        return if (buildConfigVal.contains("your-anon-key")) "" else buildConfigVal
    }

    fun saveConfig(context: Context, url: String, anonKey: String) {
        val prefs = context.getSharedPreferences("supabase_prefs", Context.MODE_PRIVATE)
        prefs.edit()
            .putString("supabase_url", url.trim())
            .putString("supabase_anon_key", anonKey.trim())
            .apply()
    }

    suspend fun testConnection(url: String, anonKey: String): ConnectionResult = withContext(Dispatchers.IO) {
        if (url.isBlank() || anonKey.isBlank()) {
            return@withContext ConnectionResult(false, "URL ou Anon Key vazia. Por favor, preencha as configurações.")
        }

        val cleanUrl = if (url.endsWith("/")) url.removeSuffix("/") else url
        val requestUrl = "$cleanUrl/rest/v1/"

        val request = Request.Builder()
            .url(requestUrl)
            .addHeader("apikey", anonKey)
            .addHeader("Authorization", "Bearer $anonKey")
            .get()
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    ConnectionResult(true, "Conectado com sucesso! Código HTTP: ${response.code}. Resposta curta da API de Schema obtida.")
                } else {
                    ConnectionResult(false, "Erro HTTP ${response.code}: ${response.message}\nDetalhes: $bodyStr")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error testing connection", e)
            ConnectionResult(false, "Falha de Rede: ${e.localizedMessage ?: e.message}")
        }
    }

    suspend fun syncTable(
        url: String,
        anonKey: String,
        tableName: String,
        data: JSONArray
    ): SyncResult = withContext(Dispatchers.IO) {
        if (url.isBlank() || anonKey.isBlank()) {
            return@withContext SyncResult(false, 0, "Configuração ausente.")
        }
        if (data.length() == 0) {
            return@withContext SyncResult(true, 0, "Sem dados locais para sincronizar.")
        }

        val cleanUrl = if (url.endsWith("/")) url.removeSuffix("/") else url
        val requestUrl = "$cleanUrl/rest/v1/$tableName"

        val mediaType = "application/json; charset=utf-8".toMediaTypeOrNull()
        val requestBody = data.toString().toRequestBody(mediaType)

        // Perform UPSERT using Prefer headers
        val request = Request.Builder()
            .url(requestUrl)
            .addHeader("apikey", anonKey)
            .addHeader("Authorization", "Bearer $anonKey")
            .addHeader("Content-Type", "application/json")
            .addHeader("Prefer", "resolution=merge-of-duplicates")
            .post(requestBody)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    SyncResult(true, data.length(), "Sincronizado com sucesso! ${data.length()} registros enviados. Código HTTP: ${response.code}.")
                } else {
                    SyncResult(false, 0, "Erro HTTP ${response.code} ao sincronizar a tabela $tableName: $bodyStr")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error syncing table $tableName", e)
            SyncResult(false, 0, "Falha na sincronização: ${e.localizedMessage ?: e.message}")
        }
    }

    // JSON Serializers for local Room database tables using standard org.json
    fun serializeCustomers(list: List<Customer>): JSONArray {
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("name", item.name)
            obj.put("cpf", item.cpf)
            obj.put("phone", item.phone)
            obj.put("whatsapp", item.whatsapp)
            obj.put("email", item.email)
            obj.put("address", item.address)
            obj.put("history", item.history)
            obj.put("created_at", item.createdAt)
            array.put(obj)
        }
        return array
    }

    fun serializeDevices(list: List<Device>): JSONArray {
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("customer_id", item.customerId)
            obj.put("brand", item.brand)
            obj.put("model", item.model)
            obj.put("imei", item.imei)
            obj.put("color", item.color)
            obj.put("password_key", item.passwordKey)
            obj.put("condition", item.condition)
            obj.put("photo_url", item.photoUrl)
            obj.put("created_at", item.createdAt)
            array.put(obj)
        }
        return array
    }

    fun serializeServiceOrders(list: List<ServiceOrder>): JSONArray {
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("order_number", item.orderNumber)
            obj.put("customer_id", item.customerId)
            obj.put("customer_name", item.customerName)
            obj.put("customer_phone", item.customerPhone)
            obj.put("device_brand", item.deviceBrand)
            obj.put("device_model", item.deviceModel)
            obj.put("device_imei", item.deviceImei)
            obj.put("device_color", item.deviceColor)
            obj.put("device_password_key", item.devicePasswordKey)
            obj.put("device_condition", item.deviceCondition)
            obj.put("defect", item.defect)
            obj.put("diagnosis", item.diagnosis)
            obj.put("technical_report", item.technicalReport)
            obj.put("parts_used", item.partsUsed)
            obj.put("technician_name", item.technicianName)
            obj.put("total_value", item.totalValue)
            obj.put("entry_payment", item.entryPayment)
            obj.put("discount", item.discount)
            obj.put("warranty_days", item.warrantyDays)
            obj.put("has_signature", item.hasSignature)
            obj.put("status", item.status)
            obj.put("created_at", item.createdAt)
            obj.put("updated_at", item.updatedAt)
            array.put(obj)
        }
        return array
    }

    fun serializeInventory(list: List<InventoryPart>): JSONArray {
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("name", item.name)
            obj.put("quantity", item.quantity)
            obj.put("purchase_price", item.purchasePrice)
            obj.put("sale_price", item.salePrice)
            obj.put("supplier", item.supplier)
            obj.put("barcode", item.barcode)
            obj.put("low_stock_threshold", item.lowStockThreshold)
            obj.put("created_at", item.createdAt)
            array.put(obj)
        }
        return array
    }

    fun serializeEmployees(list: List<Employee>): JSONArray {
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("name", item.name)
            obj.put("login", item.login)
            obj.put("role", item.role)
            obj.put("commission_rate", item.commissionRate)
            obj.put("productivity_score", item.productivityScore)
            obj.put("created_at", item.createdAt)
            array.put(obj)
        }
        return array
    }

    fun serializeTransactions(list: List<Transaction>): JSONArray {
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("description", item.description)
            obj.put("amount", item.amount)
            obj.put("type", item.type)
            obj.put("is_paid", item.isPaid)
            obj.put("date", item.date)
            obj.put("category", item.category)
            obj.put("reference_id", item.referenceId)
            array.put(obj)
        }
        return array
    }

    fun serializeAssinaturas(list: List<Assinatura>): JSONArray {
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("empresa_id", item.empresa_id)
            obj.put("plano", item.plano)
            obj.put("valor", item.valor)
            obj.put("status", item.status)
            obj.put("gateway", item.gateway)
            obj.put("gateway_customer_id", item.gateway_customer_id)
            obj.put("gateway_subscription_id", item.gateway_subscription_id)
            obj.put("inicio", item.inicio)
            obj.put("vencimento", item.vencimento)
            // convert millisecond timestamp to ISO DATE format if needed, but standard timestamp or simple string will work
            obj.put("created_at", item.created_at)
            array.put(obj)
        }
        return array
    }
}

data class ConnectionResult(val success: Boolean, val message: String)
data class SyncResult(val success: Boolean, val count: Int, val message: String)
