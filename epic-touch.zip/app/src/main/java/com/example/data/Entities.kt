package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val cpf: String,
    val phone: String,
    val whatsapp: String,
    val email: String,
    val address: String,
    val history: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "devices")
data class Device(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val customerId: Int,
    val brand: String,
    val model: String,
    val imei: String,
    val color: String,
    val passwordKey: String,
    val condition: String,
    val photoUrl: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "service_orders")
data class ServiceOrder(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val orderNumber: String, // e.g. "OS-2026-0001"
    val customerId: Int,
    val customerName: String,
    val customerPhone: String,
    val deviceBrand: String,
    val deviceModel: String,
    val deviceImei: String,
    val deviceColor: String,
    val devicePasswordKey: String,
    val deviceCondition: String,
    val defect: String,
    val diagnosis: String = "",
    val technicalReport: String = "",
    val partsUsed: String = "", // comma-separated or text
    val technicianName: String = "",
    val totalValue: Double = 0.0,
    val entryPayment: Double = 0.0,
    val discount: Double = 0.0,
    val warrantyDays: Int = 90,
    val hasSignature: Boolean = false,
    val status: String = "Recebido", // "Recebido", "Em análise", "Aguardando peça", "Em reparo", "Testes", "Finalizado", "Pronto para retirada"
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "inventory")
data class InventoryPart(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val quantity: Int,
    val purchasePrice: Double,
    val salePrice: Double,
    val supplier: String,
    val barcode: String,
    val lowStockThreshold: Int,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "employees")
data class Employee(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val login: String,
    val role: String, // "Administrador", "Técnico", "Atendente", "Caixa"
    val commissionRate: Double = 0.0, // e.g. 10.0 for 10%
    val productivityScore: Double = 100.0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val description: String,
    val amount: Double,
    val type: String, // "INCOME" (Contas a receber) or "EXPENSE" (Contas pagas / Despesas)
    val isPaid: Boolean = false,
    val date: Long = System.currentTimeMillis(),
    val category: String, // "Serviço", "Compra de Peça", "Salário", "Aluguel", "Outros"
    val referenceId: String? = null // e.g., "OS-1001"
)

@Entity(tableName = "assinaturas")
data class Assinatura(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val empresa_id: Int,
    val plano: String,
    val valor: Double,
    val status: String = "teste", // 'teste', 'ativa', 'pendente', 'cancelada', 'suspensa'
    val gateway: String? = null,
    val gateway_customer_id: String? = null,
    val gateway_subscription_id: String? = null,
    val inicio: String? = null,
    val vencimento: String? = null,
    val created_at: Long = System.currentTimeMillis()
)

data class PlatformUser(
    val login: String,
    val name: String,
    val role: String,
    val assistanceName: String,
    val plan: String
)
